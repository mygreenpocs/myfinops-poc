# CloudWatch & CIDR — cURL test scenarios and expected results

Hands-on checklist for **`local`** (or any base URL). Replace `BASE` if your host/port differs.

```bash
BASE="http://localhost:8081/api"
```

**Windows CMD / PowerShell:** use `curl.exe` if `curl` is an alias. For JSON bodies in PowerShell, prefer a file or careful quoting.

---

## Prerequisites

| Scenario group | You need |
| -------------- | -------- |
| **CIDR REST** | App running (e.g. `local` profile). **MongoDB** reachable (same as `spring.data.mongodb` for that profile). |
| **Aggregate trigger** | **`cloudwatchanalyzer.enabled=true`**, **`cloudwatchanalyzer.aws.enabled=true`**, **`cloudwatchanalyzer.trigger.enabled=true`**. Valid **AWS** credentials for CloudWatch Logs on configured log groups. **GAIME** URL reachable (or expect GAIME rows with non-2xx `httpStatus`). Log groups: discovery or static list in config — see `application-local.yml` / `application.yml`. |

**Quick config flags (YAML or env):**

| Symptom | Typical fix |
| ------- | ----------- |
| Trigger **503** “trigger is disabled” | `CLOUDWATCH_TRIGGER_ENABLED=true` or `cloudwatchanalyzer.trigger.enabled: true` |
| Trigger **503** “pipeline not available” | `cloudwatchanalyzer.aws.enabled: true` (and master `enabled: true`) |
| Trigger **503** “cloudwatchanalyzer.enabled is false” | Set `cloudwatchanalyzer.enabled: true` |

---

## A. CIDR mappings (`/v1/cloudwatch/cidr-mappings`)

These endpoints are **not** gated by `trigger.enabled` — they should work even when the manual CloudWatch trigger is off.

### A.1 — List all Mongo documents

```bash
curl -sS -i "${BASE}/v1/cloudwatch/cidr-mappings"
```

| Expected | |
| -------- | --- |
| **HTTP** | **200** |
| **Body** | JSON **array**. Empty collection → `[]`. Each element includes `id`, `cidrBlock`, `applicationName`, `sortOrder` (Mongo-assigned `id`). |

---

### A.2 — Effective config map (Mongo if any row, else YAML `cidr-blocks`)

```bash
curl -sS -i "${BASE}/v1/cloudwatch/cidr-mappings/config"
```

| Expected | |
| -------- | --- |
| **HTTP** | **200** |
| **Body** | JSON **object**: keys = CIDR strings, values = application names. If Mongo has ≥1 mapping, reflects Mongo; otherwise YAML fallback from `cloudwatchanalyzer.cidr-blocks`. |

---

### A.3 — Create one mapping

```bash
curl -sS -i -X POST "${BASE}/v1/cloudwatch/cidr-mappings" \
  -H "Content-Type: application/json" \
  -d '{"cidrBlock":"203.0.113.0/24","applicationName":"test-app","sortOrder":100}'
```

| Expected | |
| -------- | --- |
| **HTTP** | **201 Created** |
| **Body** | Single object with persisted fields including generated **`id`**. |

**Negative — invalid CIDR / validation**

```bash
curl -sS -i -X POST "${BASE}/v1/cloudwatch/cidr-mappings" \
  -H "Content-Type: application/json" \
  -d '{"cidrBlock":"not-a-cidr","applicationName":"x","sortOrder":1}'
```

| Expected | |
| -------- | --- |
| **HTTP** | **400** |
| **Body** | Error payload (validation / bad CIDR message). |

---

### A.4 — Seed mappings (append)

```bash
curl -sS -i -X POST "${BASE}/v1/cloudwatch/cidr-mappings/seed?replace=false" \
  -H "Content-Type: application/json" \
  -d '[{"cidrBlock":"198.51.100.0/24","applicationName":"seed-app","sortOrder":50}]'
```

| Expected | |
| -------- | --- |
| **HTTP** | **200** |
| **Body** | JSON array of saved documents (with `id`). Existing rows are **not** removed. |

---

### A.5 — Seed with replace (wipe then insert)

```bash
curl -sS -i -X POST "${BASE}/v1/cloudwatch/cidr-mappings/seed?replace=true" \
  -H "Content-Type: application/json" \
  -d '[{"cidrBlock":"192.0.2.0/24","applicationName":"only-app","sortOrder":1}]'
```

| Expected | |
| -------- | --- |
| **HTTP** | **200** |
| **Body** | Array of new documents. **All previous** mappings removed first. |

---

### A.6 — Delete by id

Use an `id` from **A.1** or **A.3**:

```bash
ID="<paste-mongo-id-here>"
curl -sS -i -X DELETE "${BASE}/v1/cloudwatch/cidr-mappings/${ID}"
```

| Expected | |
| -------- | --- |
| **HTTP** | **204 No Content** (success) |
| **Body** | Empty |

**Unknown id**

```bash
curl -sS -i -X DELETE "${BASE}/v1/cloudwatch/cidr-mappings/000000000000000000000000"
```

| Expected | |
| -------- | --- |
| **HTTP** | **404** |

---

## B. Aggregate pipeline — legacy JSON

**Path:** `POST /v1/cloudwatch/analytics/trigger`  
**Response type:** `ManualTriggerResponse` (`success`, `message`, `rowCount`, `rows[]`, `windowStartEpochSeconds`, `windowEndEpochSeconds`, `gaimeUrl`, …).

### B.1 — Default window (configured `query.window`, e.g. 15m)

```bash
curl -sS -i -X POST "${BASE}/v1/cloudwatch/analytics/trigger"
```

| Expected (when pipeline **allowed** and AWS succeeds) | |
| ---------------------------------------------------- | --- |
| **HTTP** | **200** |
| **Body** | `"success": true`, `"rowCount": <int≥0>`, `rows` array length **equals** `rowCount` (one element per **merged** aggregate posted to GAIME). Each row has `payloadSent`, `cloudWatchRow`, `httpStatus`, optional `gaimeResponseBody` / error fields. |

| Expected (when **trigger disabled**) | |
| ------------------------------------ | --- |
| **HTTP** | **503** |
| **Body** | `"success": false`, message mentions `trigger.enabled=false`. |

| Expected (when **`aws.enabled=false`** or bean missing) | |
| ------------------------------------------------------- | --- |
| **HTTP** | **503** |
| **Body** | `"success": false`, message about pipeline / `CloudWatchTriggerService` not registered. |

| Expected (when **`cloudwatchanalyzer.enabled=false`**) | |
| ------------------------------------------------------ | --- |
| **HTTP** | **503** |
| **Body** | `"success": false`, message `cloudwatchanalyzer.enabled is false`. |

---

### B.2 — Sliding `window` query parameter (mutually exclusive with epoch)

```bash
curl -sS -i -X POST "${BASE}/v1/cloudwatch/analytics/trigger?window=2d"
```

| Expected | |
| -------- | --- |
| **HTTP** | **200** on success; **400** if `window` invalid or combined with epoch params |
| **Body (400)** | `"success": false`, message explains invalid `window` or “not both” epoch + window |

---

### B.3 — Absolute range — `startEpochSeconds` + `endEpochSeconds` (both required)

```bash
curl -sS -i -X POST "${BASE}/v1/cloudwatch/analytics/trigger?startEpochSeconds=1700000000&endEpochSeconds=1700086400"
```

| Expected | |
| -------- | --- |
| **HTTP** | **200** on success; **400** if only one epoch param, `end` ≤ `start`, span &gt; `max-window`, or combined with `window=` |
| **Body (success)** | Same shape as **B.1**; window fields match the requested epoch range. |

**Negative — only one epoch**

```bash
curl -sS -i -X POST "${BASE}/v1/cloudwatch/analytics/trigger?startEpochSeconds=1700000000"
```

| Expected | |
| -------- | --- |
| **HTTP** | **400** |
| **Body** | Message about both epoch params required. |

---

## C. Aggregate pipeline — spec JSON

**Path:** `POST /cloudwatch/trigger`  
**Response type:** `CloudWatchSpecTriggerResponse` — top-level **`payloadsSentToGaime`** (array) and **`gaimeResponses`** (array, aligned by index). Same pipeline as legacy.

### C.1 — Default window

```bash
curl -sS -i -X POST "${BASE}/cloudwatch/trigger"
```

| Expected | |
| -------- | --- |
| **HTTP** | Same status rules as **B.1** (200 / 400 / 503). |
| **Body (200)** | `"success": true`, `payloadsSentToGaime` length = `gaimeResponses` length = logical row count; each `gaimeResponses[i]` includes `cloudWatchDimensions`, `httpStatus`, `responseBody` / error fields. |

---

### C.2 — Spec epoch names: `startTimeSeconds` + `endTimeSeconds`

```bash
curl -sS -i -X POST "${BASE}/cloudwatch/trigger?startTimeSeconds=1700000000&endTimeSeconds=1700086400"
```

| Expected | |
| -------- | --- |
| **HTTP** | **200** or **400** (same validation as legacy epoch). |
| **Body (400)** | Mapped to spec JSON with `success: false`, empty or minimal `payloadsSentToGaime` / `gaimeResponses` depending on failure phase. |

---

### C.3 — Mutually exclusive epoch families

Do **not** send spec epoch **and** legacy epoch in the same request:

```bash
curl -sS -i -X POST "${BASE}/cloudwatch/trigger?startTimeSeconds=1&endTimeSeconds=2&startEpochSeconds=1&endEpochSeconds=2"
```

| Expected | |
| -------- | --- |
| **HTTP** | **400** |
| **Body** | Message: use one pair or the other, not both. |

---

## D. Inspecting results (optional)

```bash
# Legacy response pretty-printed
curl -sS -X POST "${BASE}/v1/cloudwatch/analytics/trigger" | jq .

# Spec response pretty-printed
curl -sS -X POST "${BASE}/cloudwatch/trigger" | jq .
```

**Healthy GAIME row (illustrative):** `rows[i].httpStatus` (legacy) or `gaimeResponses[i].httpStatus` (spec) in **2xx**; `gaimeResponseBody` / `responseBody` may be non-empty.  
**GAIME / network failure:** `httpStatus` **4xx/5xx** or missing; `errorMessage` / `errorResponseBody` populated in JSON (truncated in **application logs**, not necessarily in API body).

---

## E. Checklist summary

| # | Scenario | Expect |
|---|----------|--------|
| A.1 | GET cidr-mappings | 200, array |
| A.2 | GET cidr-mappings/config | 200, object map |
| A.3 | POST cidr-mappings (valid) | 201 |
| A.3− | POST cidr-mappings (bad CIDR) | 400 |
| A.4 | POST seed replace=false | 200 |
| A.5 | POST seed replace=true | 200, collection replaced |
| A.6 | DELETE by id | 204 / 404 |
| B.1 | POST legacy trigger (happy) | 200, success true |
| B.1 | POST legacy trigger (trigger off) | 503 |
| B.2 | POST legacy ?window= | 200 or 400 |
| B.3 | POST legacy epoch | 200 or 400 |
| C.1 | POST spec trigger (happy) | 200, payloads + gaimeResponses |
| C.2 | POST spec epoch | 200 or 400 |
| C.3 | POST spec mixed epoch | 400 |

---

*See also: [`CLOUDWATCH-CIDR-README-AND-PLAN.md`](CLOUDWATCH-CIDR-README-AND-PLAN.md) for architecture, properties, and logging (`event=` lines).*
