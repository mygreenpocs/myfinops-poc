# CloudWatch Analyzer & CIDR Mapping — README & Step-by-Step Implementation Plan

This document is the **product/technical README** for the CloudWatch log analytics, CIDR grouping, and GAIME integration described in the feature spec. It includes a **story backlog** ordered so each story is **small, mergeable, and testable on its own**.

---

## 1. Goals (from spec)


| Capability         | Target behavior                                                                                                                                                                                                                                           |
| ------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Insights query** | Single Logs Insights query: filter `TimeLoggerFilter`, parse `source`, `patternUrl`, `status`, `outputSize`, drop incomplete rows, **stats** `count(*)` and `sum(outputSize)` **by** `source`, `patternUrl`, `status`.                                    |
| **CIDR grouping**  | Map `source` (IP) → CIDR + application name (MongoDB, YAML fallback); merge aggregates by `(cidrBlock, applicationName, patternUrl, status)`; non-IP → as-is; unknown IP → `other`.                                                                       |
| **Log groups**     | Discover `/aws/ecs/{env}-{service}-svc-*-{region}` from config (not hardcoded full ARNs/names).                                                                                                                                                           |
| **GAIME**          | POST **one JSON body per aggregate row** (`source`, `patternUrl`, `status`, `count`, `totalOutputSize`) to configurable URL; capture HTTP status + raw response body.                                                                                     |
| **Scheduler**      | Optional scheduled run; resilient startup if AWS/trigger unavailable.                                                                                                                                                                                     |
| **Manual trigger** | **Legacy:** `POST /v1/cloudwatch/analytics/trigger` — `ManualTriggerResponse`. **Spec:** `POST /cloudwatch/trigger` — `payloadsSentToGaime` + `gaimeResponses`. Both return per-row GAIME HTTP status and bodies (see §10 for logging); **503** when CloudWatch/trigger/AWS pipeline disabled (CIDR APIs unaffected). |


---

## 2. Current codebase snapshot (as of this plan)

Use this to know what **already exists** vs what **stories below still build**.


| Area                  | Status              | Notes                                                                                                                                                                                                                                                                                                                                                              |
| --------------------- | ------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Component scan        | Done                | `com.pearson.cloudwatchanalyzer`                                                                                                                                                                                                                                                                                                                                   |
| AWS client            | Done                | `AwsConfig` — region + optional profile                                                                                                                                                                                                                                                                                                                            |
| Query execution       | Done                | `CloudWatchQueryService` — single/multi log group                                                                                                                                                                                                                                                                                                                  |
| **Query semantics**   | **Done (pipeline)** | **`CloudWatchTriggerService.runOnce`** runs `executeAggregateTimeLoggerQuery` → `AggregateStatsMergeService.mergeForGaime` → **`CloudWatchGaimeRunService.postMergedAggregateRow`** (GAIME POST + echo). GAIME `source`: matched CIDR block, unknown IPv4 → `other`, non-IPv4 → original `source`. GAIME contract may differ from legacy `AnalyticsResponse` — use `gaimeResponseBody` on each row in the trigger response. |
| Log group list        | **Partial**         | `**use-log-group-discovery: true` (default prod):** `CloudWatchLogGroupDiscoveryService` lists `/aws/ecs/{env}-{service}-svc-*` ending with `-{region}`. **Local:** `use-log-group-discovery: false` + explicit `query.log-groups`.                                                                                                                                |
| GAIME URL             | Done                | `cloudwatchanalyzer.gaime.url` (align naming with spec: `analytics.api-url`)                                                                                                                                                                                                                                                                                       |
| Scheduler             | Done                | `CloudWatchScheduler` + `scheduler.enabled`                                                                                                                                                                                                                                                                                                                        |
| Manual trigger        | **Done (dual path)** | **Legacy:** `POST /v1/cloudwatch/analytics/trigger` → `ManualTriggerResponse`. **Spec (G.2):** `POST /cloudwatch/trigger` → `CloudWatchSpecTriggerResponse` (`payloadsSentToGaime`, `gaimeResponses[].cloudWatchDimensions`, `responseBody`, …). Query: `startTimeSeconds`/`endTimeSeconds` on spec path; legacy `startEpochSeconds`/`endEpochSeconds` on `/v1/...` (spec path also accepts legacy epoch names if spec pair unused). |
| CIDR / Mongo          | **Done (merge path)** | `**CidrMatcher`** (D.1); `**CidrMappingService**` (D.2); `**CidrBlockMapping**` + repo (E.1). REST: **GET** list/config (E.2–E.3), **POST** create + **POST** seed + **DELETE** by id (E.4–E.6). **`AggregateStatsMergeService`** (F.1): merge on `(cidrBlock, applicationName, patternUrl, status)` before GAIME POST; tests `AggregateStatsMergeServiceTest`. |
| Optional trigger bean | **Done (G.1)**      | `CloudWatchTriggerService` registered only when `cloudwatchanalyzer.enabled` and `cloudwatchanalyzer.aws.enabled` are true (both `matchIfMissing`). `CloudWatchScheduler` + `CloudWatchManualTriggerController` inject `Optional<CloudWatchTriggerService>`; empty → scheduler no-op / manual POST **503** for pipeline. Env: `CLOUDWATCH_AWS_ENABLED`. |
| **Logging / ops (H.1)** | **Done**          | **`event=`** structured pipeline + GAIME logs; **`CloudWatchLogSanitizer`** (truncate bodies, GAIME host only at INFO); **`CloudWatchPipelineLog`** (HTTP success/fail counts). See **§9**. |


**Testing note:** Smoke either **`POST /v1/cloudwatch/analytics/trigger`** (legacy JSON) or **`POST /cloudwatch/trigger`** (spec JSON). Same pipeline; shared **`CloudWatchTriggerHttpCoordinator`**.

**Manual trigger response (current):** `rowCount` = number of **merged** aggregate rows sent to GAIME (≤ raw Insights row count when CIDR merge combines rows). Each `rows[i].payloadSent` is `AnalyticsAggregateRequest` JSON. Echo map includes `cidrBlock` and `applicationName` when present. Log groups come from **`CloudWatchTriggerService.resolveLogGroupsForQuery()`** (discovery when `use-log-group-discovery: true`, else static `query.log-groups`).

---

## 3. How to use this plan (step-by-step testing)

1. Complete stories **in order** within each epic (dependencies are listed).
2. After each story, run the **“How to test”** section and record pass/fail before the next story.
3. Prefer **one PR per story**; if a story is large, split into sub-stories only when each part remains testable.

**Baseline for all local tests**

- Profile: `local` (`application-local.yml`).
- MongoDB running if a story touches CIDR APIs.
- AWS: only required for stories that execute CloudWatch (use same shell/IDE env as working `aws` CLI).

---

## 4. Story backlog (individually testable)

### Epic A — Configuration model (no behavior change yet)


| ID      | Story                                    | Deliverables                                                                                                                                                                                                                                                                                | How to test                                                                                                                                                     | Depends on |
| ------- | ---------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------- |
| **A.1** | **Align configuration keys with spec** ✅ | Extend `CloudWatchAnalyzerProperties` (or dedicated nested config) for: `env`, `region` (suffix e.g. `use1`), `log-group.services` (list), `cidr-blocks` (map), `analytics.api-url` (alias or migrate from `gaime.url`). Keep backward compatibility or single migration note in changelog. | Start app with `local` + `dev` profiles; no errors; `Environment` or actuator (if exposed) shows bound properties; existing GAIME URL still works if unchanged. | —          |
| **A.2** | **Local profile semantics** ✅            | Document and implement: `scheduler.enabled: false` stops scheduled runs; define `**cloudwatchanalyzer.trigger.enabled`** (or equivalent) so **manual trigger returns 503** when CloudWatch path is off for local, **without** breaking Mongo CIDR APIs.                                     | With trigger disabled: `POST` manual endpoint → **503** + JSON message. CIDR GET (once exists) still **200**.                                                   | A.1        |


---

### Epic B — Log group discovery


| ID      | Story                                     | Deliverables                                                                                                                                                                               | How to test                                                                                                                                                                             | Depends on |
| ------- | ----------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------- |
| **B.1** | **DescribeLogGroups discovery service** ✅ | New service: for each service name, prefix `/aws/ecs/{env}-{service}-svc-`, filter groups whose name ends with `-{region}`. Return merged distinct list.                                   | **Unit test** with mocked `CloudWatchLogsClient` returning mixed names; assert only matching names. Optional: manual test in AWS account with read-only credentials — log list in logs. | A.1        |
| **B.2** | **Wire discovery into config** ✅          | Replace hardcoded `query.log-groups` with discovery output when a flag `use-log-group-discovery: true` (default `true` in prod, `false` + explicit list for narrow local tests if needed). | Toggle flag: with `false`, old list still used; with `true`, query uses discovered groups (integration or mocked).                                                                      | B.1        |


---

### Epic C — Insights query v2 (aggregated pipeline)


| ID      | Story                                         | Deliverables                                                                                                                                                  | How to test                                                                                                                    | Depends on                                    |
| ------- | --------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------ | --------------------------------------------- |
| **C.1** | **Store spec query as constant + document** ✅ | Exact query string from spec in code + comment linking to AWS console test.                                                                                   | Run same query in AWS Logs Insights UI on one log group; compare row count/shape to app logs (temporary debug) or test double. | —                                             |
| **C.2** | **Parse Insights stats result rows** ✅        | DTO e.g. `AggregateStatsRow` (`source`, `patternUrl`, `status`, `count`, `totalOutputSize`); parser from `GetQueryResults` field map (handle string numbers). | **Unit tests**: sample SDK-style result list → parsed objects; invalid/missing fields → clear error or skip.                   | C.1                                           |
| **C.3** | **Execute aggregated query end-to-end** ✅     | New method in query service or orchestrator: given log group names + time window → list of `AggregateStatsRow`.                                               | Integration test (AWS) or mock client returning fixed results; assert list size and sums.                                      | B.2 (or hardcoded groups for early test), C.2 |


---

### Epic D — CIDR matching (domain only)


| ID      | Story                       | Deliverables                                                                                                                                                                                                                        | How to test                                       | Depends on |
| ------- | --------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------- | ---------- |
| **D.1** | `**CidrMatcher` utility** ✅ | `com.pearson.cloudwatchanalyzer.cidr`: `CidrMatcher.fromRules`, `CidrRule`, `CidrMatchResult`; IPv4 CIDR only; **bare IPv4 keys default to `/32`**; order by `sortOrder`; NA/blank/non-IPv4 → `NON_IPV4`; unmatched IPv4 → `other`. | **Unit:** `CidrMatcherTest`.                      | —          |
| **D.2** | `**CidrMappingService`** ✅  | Load mappings from Mongo repository; if empty, load from YAML `cidr-blocks`; `loadOrderedRules()` / `buildMatcher()` / `effectiveConfigMap()` (E.3).                                                                                  | **Unit:** `CidrMappingServiceTest` (mocked repo). | A.1, E.1   |


---

### Epic E — MongoDB + REST for CIDR mappings


| ID      | Story                                       | Deliverables                                                                                                                                                                                                    | How to test                                                                             | Depends on |
| ------- | ------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------- | ---------- |
| **E.1** | **Entity + repository** ✅                   | `CidrBlockMapping` (`cidrBlock`, `applicationName`, `sortOrder`), collection `cidrBlockMapping`, `CidrBlockMappingRepository`; `@EnableMongoRepositories` includes `com.pearson.cloudwatchanalyzer.repository`. | App starts; repository bean exists; use Mongo shell or REST once E.4/E.5 land.          | —          |
| **E.2** | **GET `/v1/cloudwatch/cidr-mappings`** ✅   | List full documents including `id` (ordered by `sortOrder`).                                                                                                                                                    | `curl` → JSON array.                                                                    | E.1        |
| **E.3** | **GET `/v1/cloudwatch/cidr-mappings/config`** ✅ | Map `cidrBlock` → `applicationName` as used by analyzer (Mongo if any row; else YAML).                                                                                                                         | Mongo empty → YAML; Mongo seeded → Mongo.                                               | E.1, D.2   |
| **E.4** | **POST `/v1/cloudwatch/cidr-mappings`** ✅  | JSON `cidrBlock`, `applicationName`, `sortOrder`; CIDR normalized via `CidrRule`; **201** + saved doc (Mongo `id`).                                                                                             | POST → **201**; GET list includes row.                                                    | E.1        |
| **E.5** | **POST `/v1/cloudwatch/cidr-mappings/seed`** ✅ | JSON array of same shape; `?replace=true` → `deleteAll` then `saveAll`; `replace=false` → append only (duplicate CIDRs allowed).                                                                               | Replace twice; without replace, no delete.                                                | E.1        |
| **E.6** | **DELETE `/v1/cloudwatch/cidr-mappings/{id}`** ✅ | Remove by Mongo id.                                                                                                                                                                                         | **204** if present; **404** if missing.                                                   | E.1        |


---

### Epic F — Merge aggregates with CIDR + GAIME payload


| ID      | Story                                       | Deliverables                                                                                                                                                                                      | How to test                                                                  | Depends on         |
| ------- | ------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------- | ------------------ |
| **F.1** | **Resolve + merge stats rows** ✅           | For each `AggregateStatsRow`, resolve `source` through `CidrMappingService` + `CidrMatcher`; merge keys `(cidrBlock, applicationName, patternUrl, status)` summing `count` and `totalOutputSize`. Invoked from **`CloudWatchTriggerService`** before GAIME POST. | **Unit:** `AggregateStatsMergeServiceTest`, `CloudWatchTriggerServiceTest`. | C.2, D.2           |
| **F.2** | **GAIME aggregate DTO + HTTP** ✅ (baseline) | `AnalyticsAggregateRequest`; POST JSON to `analytics.api-url`; capture status + raw body (`GaimeRowResult.gaimeResponseBody`); optional parse to legacy `AnalyticsResponse` when JSON matches. Implemented on **`CloudWatchGaimeRunService`**.    | Unit: `CloudWatchTriggerServiceTest` (real GAIME service + mock `RestTemplate`). WireMock/integration optional. | A.1                |
| **F.3** | **Orchestrator `CloudWatchTriggerService`** ✅ | Single entry: discover groups → aggregated query → CIDR merge → POST each merged row via `CloudWatchGaimeRunService`. Returns existing **`ManualTriggerResponse`** (spec “trigger result” shape). | **Unit:** `CloudWatchTriggerServiceTest` (mocked AWS query + merge + GAIME HTTP). | B.2, C.3, F.1, F.2 |


---

### Epic G — Scheduler resilience + manual trigger (spec contract)


| ID      | Story                            | Deliverables                                                                                                                                                                                | How to test                                                                     | Depends on |
| ------- | -------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------- | ---------- |
| **G.1** | **Optional trigger wiring** ✅   | `@ConditionalOnProperty` on `CloudWatchTriggerService` (`enabled` + `aws.enabled`). `Optional` injection on scheduler + manual controller; **503** when bean absent.                        | **Unit:** `CloudWatchSchedulerTest`. Set `aws.enabled=false`: app starts; scheduled tick no-ops. | F.3, A.2   |
| **G.2** | `**POST /cloudwatch/trigger`** ✅ | `CloudWatchSpecTriggerController` + `CloudWatchSpecTriggerResponse` (`payloadsSentToGaime`, `gaimeResponses`); params `startTimeSeconds`/`endTimeSeconds`, `window`, legacy epoch pair (exclusive). Shared **`CloudWatchTriggerHttpCoordinator`**. | **Unit:** `CloudWatchSpecEpochParamsTest`, `CloudWatchSpecTriggerResponseTest`, `CloudWatchSpecTriggerControllerTest`. | F.3        |
| **G.3** | **503 when disabled** ✅         | **`CloudWatchTriggerHttpCoordinator` preflight** on legacy + spec URLs (`enabled`, `trigger`, optional bean).                                                                                 | `curl -i` → **503** when gated off.                                            | A.2, G.2   |
| **G.4** | **Path migration / deprecation** ✅ | Legacy **`/v1/cloudwatch/analytics/trigger`** + spec **`/cloudwatch/trigger`** documented (§2, §7, §8).                                                                                      | Both paths live.                                                                | G.2        |


---

### Epic H — Hardening & docs


| ID      | Story                        | Deliverables                                                                           | How to test                         | Depends on  |
| ------- | ---------------------------- | -------------------------------------------------------------------------------------- | ----------------------------------- | ----------- |
| **H.1** | **Error handling + logging** ✅ | `event=` key=value INFO lines: pipeline start/complete (log group **count**, window epochs, merge sizes, GAIME 2xx/fail counts); GAIME errors with **truncated** bodies + `sourceDimension`; multi-group Insights at DEBUG. **`CloudWatchLogSanitizer`**, **`CloudWatchPipelineLog`**. | Logs review; run trigger + scheduler. | G.2         |
| **H.2** | **Update main docs + curl** ✅ | Root **`README.md`** links this doc; §1 goals + §8 file map updated.                                                                                  | Peer review checklist.              | Prior epics |


---

## 5. Suggested test order (minimal path)

For the fastest **vertical slice** you can demo:

1. **E.1 → E.4 → E.3** — CIDR data in Mongo + read APIs (no CloudWatch).
2. **D.1 → D.2** — Matcher + config service wired to those APIs.
3. **C.1 → C.2** — Query + parse (mocked AWS).
4. **B.1 → B.2** — Discovery (mocked or real read-only).
5. **F.1 → F.2 → F.3** — Full orchestration.
6. **G.1 → G.2 → G.3** — Scheduler + `/cloudwatch/trigger` + 503 behavior.

---

## 6. Spec ↔ properties (checklist)

Implement and verify during **A.1**:


| Property                                | Purpose                                                                                            |
| --------------------------------------- | -------------------------------------------------------------------------------------------------- |
| `cloudwatchanalyzer.env`                | ECS name prefix segment (e.g. `gps-qa`)                                                            |
| `cloudwatchanalyzer.region`             | Suffix e.g. `use1` for log group names                                                             |
| `cloudwatchanalyzer.log-group.services` | Service keys for discovery                                                                         |
| `cloudwatchanalyzer.cidr-blocks`        | YAML fallback map                                                                                  |
| `cloudwatchanalyzer.analytics.api-url`  | GAIME URL                                                                                          |
| `cloudwatchanalyzer.scheduler.enabled`  | Scheduled job on/off                                                                               |
| `cloudwatchanalyzer.scheduler.interval` | e.g. `900s`                                                                                        |
| `cloudwatchanalyzer.trigger.enabled`    | **Implemented (A.2):** manual `POST .../analytics/trigger` only; CIDR REST will not depend on this |
| `cloudwatchanalyzer.aws.enabled`        | **G.1:** when false, `CloudWatchTriggerService` bean omitted; scheduler no-op; manual aggregate trigger **503** (CIDR APIs OK). Env alias in `application.yml`: `CLOUDWATCH_AWS_ENABLED`. |


---

## 7. cURL quick reference (target state after stories)

**Step-by-step expected results:** see **[`CLOUDWATCH-CURL-TEST-SCENARIOS.md`](CLOUDWATCH-CURL-TEST-SCENARIOS.md)** (separate QA doc).

**Note:** CIDR paths use `/v1/cloudwatch/...`. Aggregate trigger: **legacy** `/v1/cloudwatch/analytics/trigger` or **spec** `/cloudwatch/trigger` (same pipeline).

```bash
# CIDR: raw Mongo documents (empty array if collection empty)
curl -sS "http://localhost:8081/api/v1/cloudwatch/cidr-mappings"

# CIDR: effective cidrBlock → applicationName (Mongo if any row, else YAML cidr-blocks)
curl -sS "http://localhost:8081/api/v1/cloudwatch/cidr-mappings/config"

# Create one mapping (201)
curl -sS -X POST "http://localhost:8081/api/v1/cloudwatch/cidr-mappings" \
  -H "Content-Type: application/json" \
  -d '{"cidrBlock":"34.254.0.0/16","applicationName":"search-service","sortOrder":10}'

# Replace all mappings from array
curl -sS -X POST "http://localhost:8081/api/v1/cloudwatch/cidr-mappings/seed?replace=true" \
  -H "Content-Type: application/json" \
  -d '[{"cidrBlock":"34.254.0.0/16","applicationName":"search-service","sortOrder":10}]'

# Delete by id (use id from GET list)
# curl -sS -X DELETE "http://localhost:8081/api/v1/cloudwatch/cidr-mappings/<mongoId>"

# --- Manual aggregate pipeline (enable cloudwatchanalyzer + trigger.enabled + aws.enabled) ---
LEGACY="http://localhost:8081/api/v1/cloudwatch/analytics/trigger"
SPEC="http://localhost:8081/api/cloudwatch/trigger"

# 1) Default: sliding window from config (query.window, e.g. 15m) — legacy JSON
curl -sS -X POST "$LEGACY"

# 2) Spec path, same behavior, spec-shaped JSON (payloadsSentToGaime, gaimeResponses)
curl -sS -X POST "$SPEC"

# 3) Override window with a duration (15m, 2d, 1h, … or ISO-8601 PT15M). Mutually exclusive with epoch params.
curl -sS -X POST "${SPEC}?window=2d"

# 4) Absolute range — legacy path: startEpochSeconds & endEpochSeconds (Unix seconds)
curl -sS -X POST "${LEGACY}?startEpochSeconds=1700000000&endEpochSeconds=1700086400"

# 5) Absolute range — spec path: startTimeSeconds & endTimeSeconds (same semantics; mutually exclusive with legacy pair on same request)
curl -sS -X POST "${SPEC}?startTimeSeconds=1700000000&endTimeSeconds=1700086400"

# Verbose (status + headers); use curl.exe on Windows CMD if `curl` is aliased
curl -v -X POST "${LEGACY}?window=15m"

# Pretty JSON (requires jq)
# curl -sS -X POST "$SPEC" | jq .

```

---

## 8. File map (target state — create as stories land)


| Area          | Target package / path                                                                                                                 |
| ------------- | ------------------------------------------------------------------------------------------------------------------------------------- |
| Config        | `application.yml`, `application-local.yml`, `CloudWatchAnalyzerProperties`                                                            |
| Discovery     | e.g. `CloudWatchLogGroupDiscoveryService`                                                                                             |
| Query + parse | `CloudWatchQueryService` + aggregate DTOs; `AggregateStatsMergeService` (F.1)                                                         |
| CIDR          | `cidr/CidrMatcher`, `CidrRule`, `CidrMatchResult`; `CidrMappingService` (D.2)                                                         |
| REST CIDR     | `CidrBlockMappingController` (`/v1/cloudwatch/cidr-mappings`, `/config`)                                                              |
| REST trigger  | `CloudWatchManualTriggerController` (`/v1/cloudwatch/analytics/trigger`); `CloudWatchSpecTriggerController` (`/cloudwatch/trigger`)   |
| Orchestration | `CloudWatchTriggerService` (pipeline); `CloudWatchGaimeRunService` (GAIME POST + echo per merged row)                                  |
| Scheduler     | `CloudWatchScheduler`                                                                                                                 |
| Mongo         | `cloudwatchanalyzer.entity.CidrBlockMapping`, `cloudwatchanalyzer.repository.CidrBlockMappingRepository`                              |
| DTOs          | `AnalyticsAggregateRequest`, `AggregateStatsRow`, `GaimeRowResult`, `CloudWatchSpecTriggerResponse` (G.2); `dto/CidrBlockMappingRequest` (CIDR REST) |
| Logging (H.1) | `logging/CloudWatchLogSanitizer`, `logging/CloudWatchPipelineLog` — pipeline + GAIME log hygiene |


---

## 9. Pipeline logging (Epic H.1)

Use **`event=`** + **`key=value`** on INFO/WARN/ERROR lines so log platforms can filter (e.g. CloudWatch Logs metric filters, Splunk).

| `event` | Level | Meaning |
| ------- | ----- | ------- |
| `cloudwatch_pipeline_start` | INFO | `logGroupCount`, `windowEpochStart`/`End`, `spanSeconds`, `gaimeHost` (not full URL), `useLogGroupDiscovery` |
| `cloudwatch_pipeline_start_detail` | DEBUG | Full `logGroups` list |
| `cloudwatch_insights_aggregate` | INFO | `logGroupCount`, `rawInsightsRows`, `parsedAggregateRows` |
| `cloudwatch_insights_aggregate_parse_skipped` | WARN | Unparseable Insights rows |
| `cloudwatch_pipeline_merge_complete` | INFO | `rawAggregateRows`, `mergedRows` |
| `cloudwatch_pipeline_complete` | INFO | `mergedRowsPosted`, `gaimeHttp2xx`, `gaimeHttpFailures` |
| `gaime_http_error` / `gaime_network_error` / `gaime_unexpected_error` | WARN/ERROR | Per-row GAIME failure; **response body truncated** (default 512 chars); `sourceDimension` for correlation |
| `cloudwatch_http_trigger_complete` | INFO | Manual/spec HTTP trigger OK: `rowCount`, `gaimeHttp2xx`, `gaimeHttpFailures` |
| `cloudwatch_http_trigger_rejected` / `_failed` | WARN/ERROR | 400 validation or 500 |
| `cloudwatch_trigger_preflight` | DEBUG | 503 reasons (disabled trigger, missing bean) — avoids noise |
| `cloudwatch_scheduled_run_*` | INFO/ERROR | Scheduler tick start/complete/fail with GAIME counts |

**Do not log:** full GAIME URLs with secrets in query strings at INFO (host only). Do not log full error response bodies at WARN (truncated).

---

## 10. Revision history


| Version | Date       | Notes                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| ------- | ---------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1.0     | 2026-03-20 | Initial README + story plan from feature spec; gap analysis vs current repo.                                                                                                                                                                                                                                                                                                                                                                                           |
| 1.1     | 2026-03-20 | **A.1 done:** `CloudWatchAnalyzerProperties` — `env`, `region` (log suffix), `log-group.services`, `cidr-blocks`, `analytics.api-url` + `resolveAnalyticsApiUrl()`; `gaime.url` fallback. Tests: `CloudWatchAnalyzerPropertiesTest`.                                                                                                                                                                                                                                   |
| 1.2     | 2026-03-20 | **A.2 done:** `cloudwatchanalyzer.trigger.enabled` — manual `POST .../analytics/trigger` returns **503** when false; `application-local` defaults trigger off via `CLOUDWATCH_TRIGGER_ENABLED` (default false); scheduler remains `scheduler.enabled`.                                                                                                                                                                                                                 |
| 1.3     | 2026-03-20 | **B.1 + B.2 done:** `CloudWatchLogGroupDiscoveryService` (paginated `DescribeLogGroups`), `query.use-log-group-discovery` (default true); `CloudWatchGaimeRunService.resolveLogGroupsForQuery()`. Local profile: discovery off + explicit `log-groups`. Tests: `CloudWatchLogGroupDiscoveryServiceTest`.                                                                                                                                                               |
| 1.4     | 2026-03-20 | **C.1–C.3 done:** `CloudWatchTimeLoggerAggregateInsightsQuery.QUERY`, `AggregateStatsRow` + `tryParse`, `CloudWatchQueryService.executeAggregateTimeLoggerQuery`. Tests: `AggregateStatsRowTest`, `CloudWatchQueryServiceAggregateTest`.                                                                                                                                                                                                                               |
| 1.5     | 2026-03-18 | **Manual trigger + scheduler → aggregate pipeline:** `CloudWatchGaimeRunService.runOnce()` uses `executeAggregateTimeLoggerQuery`, `resolveLogGroupsForQuery()` (discovery + static list), POSTs `AnalyticsAggregateRequest` per aggregate row. `GaimeRowResult`: aggregate payload + `gaimeResponseBody`. Legacy per-row `TimeLogger` Insights query removed from this path. Test: `CloudWatchGaimeRunServiceTest`. **Epic F.1** (CIDR merge before POST) still open. |
| 1.6     | 2026-03-20 | **D.1 done:** `CidrMatcher`, `CidrRule`, `CidrMatchResult`, `Ipv4Cidr` helper. Tests: `CidrMatcherTest`. **Next:** D.2 `CidrMappingService`, then E.1 entity/repo.                                                                                                                                                                                                                                                                                                     |
| 1.7     | 2026-03-20 | **CIDR default prefix:** bare IPv4 in `CidrRule` / YAML keys normalized to `**/32`** (single-host grouping).                                                                                                                                                                                                                                                                                                                                                           |
| 1.8     | 2026-03-18 | **Configurable query window (multi-day):** `query.window` / `query.max-window` as Spring **Duration** strings (e.g. `15m`, `2d`, `30d`); legacy `window-seconds` / `max-window-seconds` still work. Manual trigger: `?window=2d` or `?startEpochSeconds=&endEpochSeconds=`.                                                                                                                                                                                            |
| 1.9     | 2026-03-20 | **cURL quick ref (§7):** copy-paste examples for default trigger, `?window=`, `?startEpochSeconds=&endEpochSeconds=`, `-v` / `jq`.                                                                                                                                                                                                                                                                                                                                     |
| 1.10    | 2026-03-20 | **E.1 + D.2:** `CidrBlockMapping` + `CidrBlockMappingRepository`; `CidrMappingService` (Mongo if any row, else YAML `cidr-blocks`). Tests: `CidrMappingServiceTest`. `EnableMongoRepositories` extended for `cloudwatchanalyzer.repository`.                                                                                                                                                                                                                           |
| 1.11    | 2026-03-20 | **E.2 + E.3:** `CidrBlockMappingController` — GET list, GET `/config`; `CidrMappingService.effectiveConfigMap()`. WebMvc: `CidrBlockMappingControllerTest`.                                                                                                                                                                                                                                                                                                       |
| 1.12    | 2026-03-20 | **E.4–E.6:** POST create (`CidrBlockMappingRequest`), POST `/seed?replace=`, DELETE `/{id}`; `CidrBlockMappingPayloadMapper`; 400 for validation / bad CIDR.                                                                                                                                                                                                                                                                                                    |
| 1.13    | 2026-03-20 | **F.1 done:** `AggregateStatsMergeService` — CIDR resolve + merge on `(cidrBlock, applicationName, patternUrl, status)`; GAIME `source` = CIDR / `other` / original non-IPv4. `CloudWatchGaimeRunService` calls `mergeForGaime` after aggregate query; echo adds `cidrBlock`, `applicationName`. Tests: `AggregateStatsMergeServiceTest`, `CloudWatchGaimeRunServiceTest`.                                                                                           |
| 1.14    | 2026-03-20 | **F.3 done:** `CloudWatchTriggerService` — orchestrates discovery, aggregate query, merge, GAIME posts. `CloudWatchGaimeRunService` slimmed to `postMergedAggregateRow` + HTTP/response parsing. Scheduler + `CloudWatchManualTriggerController` use `CloudWatchTriggerService`. Tests renamed/moved to `CloudWatchTriggerServiceTest`.                                                                                                                                   |
| 1.15    | 2026-03-20 | **G.1 done:** `CloudWatchTriggerService` conditional on `cloudwatchanalyzer.enabled` + `cloudwatchanalyzer.aws.enabled` (`aws.enabled` on `CloudWatchAnalyzerProperties`). `Optional<CloudWatchTriggerService>` on scheduler + manual controller. `CloudWatchSchedulerTest`, properties test for `aws.enabled`. `application.yml`: `CLOUDWATCH_AWS_ENABLED`.                                                                                                        |
| 1.16    | 2026-03-20 | **G.2 + G.4:** `POST /cloudwatch/trigger` (`CloudWatchSpecTriggerResponse`), epoch param resolver, `CloudWatchTriggerHttpCoordinator` for shared 503/400/500 + pipeline. Legacy `POST /v1/cloudwatch/analytics/trigger` unchanged shape. Tests: spec epoch, spec DTO mapping, spec controller support.                                                                                                                                                                  |
| 1.17    | 2026-03-20 | **H.1 + H.2:** Structured `event=` logging across pipeline, GAIME, HTTP coordinator, scheduler; `CloudWatchLogSanitizer` + `CloudWatchPipelineLog`; multi-group Insights verbosity at DEBUG. Root **`README.md`** links this plan. §9 logging table. Tests: `CloudWatchLogSanitizerTest`, `CloudWatchPipelineLogTest`.                                                                                                                                                |
| 1.18    | 2026-03-20 | **QA doc:** [`CLOUDWATCH-CURL-TEST-SCENARIOS.md`](CLOUDWATCH-CURL-TEST-SCENARIOS.md) — cURL scenarios with expected HTTP status and response shape (CIDR + legacy/spec triggers). Linked from §7 and root README.                                                                                                                                                                                                                                                      |
| 1.19    | 2026-03-21 | **AWS credential refresh:** `AwsConfig` — `ProfileCredentialsProvider` + `ProfileFileSupplier.defaultSupplier()`; `DefaultCredentialsProvider` + `asyncCredentialUpdateEnabled(true)`. `cloudwatchlogs` **2.32.24** (aligned with DynamoDB SDK).                                                                                                                                                                         |
| 1.21    | 2026-03-22 | **SSO without restart:** `RefreshingProfileCredentialsProvider` — new profile resolution on each CloudWatch API call when `cloudwatchanalyzer.aws.refresh-credentials-each-request=true` (default). Fixes SDK behavior where `ProfileFile` equality did not change after `aws sso login` (only SSO cache files did). Optional `AWS_PROFILE` when `aws.profile` blank.                                                                                                |
| 1.20    | 2026-03-21 | **GAIME handoff:** [`GAIME-AGGREGATE-PAYLOAD-TODO.md`](GAIME-AGGREGATE-PAYLOAD-TODO.md) — aggregate `AnalyticsAggregateRequest` JSON properties, `source` semantics (CIDR / `other`), per-row POST, TODO checklist; linked from root README.                                                                                                                                                                                                                          |


### A.1 migration / compatibility

- **AWS SSO / expired tokens:** When a profile is effective (`cloudwatchanalyzer.aws.profile` or `AWS_PROFILE`), default **`refresh-credentials-each-request: true`** uses `RefreshingProfileCredentialsProvider` so each Insights/Logs call re-reads `~/.aws` and the SSO cache — **`aws sso login` without JVM restart**. Set `refresh-credentials-each-request: false` to restore a singleton `ProfileCredentialsProvider` + `ProfileFileSupplier` (can stay stale until `~/.aws/config` changes). No profile → `DefaultCredentialsProvider` + `asyncCredentialUpdateEnabled(true)`. `cloudwatchlogs` **2.32.24**.
- **New keys** (optional): `cloudwatchanalyzer.env`, `cloudwatchanalyzer.region` (log name suffix, not SDK region), `cloudwatchanalyzer.log-group.services`, `cloudwatchanalyzer.cidr-blocks`, `cloudwatchanalyzer.analytics.api-url`.
- **GAIME URL:** Set either `analytics.api-url` (spec) or `gaime.url` (legacy). If both are set, `**analytics.api-url` wins** when non-blank.
- **AWS SDK region** remains `cloudwatchanalyzer.aws.region` (e.g. `ap-south-1`) — do not confuse with `cloudwatchanalyzer.region` (`use1` suffix).

### A.2 trigger vs scheduler vs `enabled`


| Property                                      | Effect                                                                                                                                        |
| --------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------- |
| `cloudwatchanalyzer.enabled`                  | Master off: **`CloudWatchTriggerService` not registered**; scheduler no-ops (optional empty); manual aggregate **503**.                         |
| `cloudwatchanalyzer.aws.enabled`              | **G.1:** false → **`CloudWatchTriggerService` not registered** (same as optional empty); CIDR REST unaffected. Env: `CLOUDWATCH_AWS_ENABLED`.   |
| `cloudwatchanalyzer.trigger.enabled`          | **REST manual trigger only:** false → **503** with explanation. Scheduler and future CIDR APIs do not use this flag.                          |
| `cloudwatchanalyzer.scheduler.enabled`        | When false, `@Scheduled` bean not registered — no periodic runs.                                                                              |
| `cloudwatchanalyzer.query.window`             | Sliding window ending at **now** (scheduler + manual trigger when no `window`/`start`/`end` params). Spring Duration: `15m`, `2d`, `7d`, etc. |
| `cloudwatchanalyzer.query.max-window`         | Max span for configured window, `?window=`, and epoch range. Examples: `30d`, `90d`. `0s` disables the cap.                                   |
| `cloudwatchanalyzer.query.window-seconds`     | **Legacy:** integer seconds; same role as `window`.                                                                                           |
| `cloudwatchanalyzer.query.max-window-seconds` | **Legacy:** integer seconds; `0` = no cap.                                                                                                    |


**Local:** `trigger.enabled: ${CLOUDWATCH_TRIGGER_ENABLED:false}` and `scheduler.enabled: false` in `application-local.yml`. To test manual pipeline locally: set `CLOUDWATCH_TRIGGER_ENABLED=true` or `cloudwatchanalyzer.trigger.enabled: true`.

**Backfill:** `POST /v1/cloudwatch/analytics/trigger?startEpochSeconds=1700000000&endEpochSeconds=1700086400` (both together), or `POST .../trigger?window=2d`. Large windows may hit CloudWatch Insights timeouts or retention — tune `max-window` as needed.

---

*This file is the working agreement for incremental delivery. Update section 2 and story statuses as you implement. The repository root **README.md** points here for CloudWatch/CIDR topics.*