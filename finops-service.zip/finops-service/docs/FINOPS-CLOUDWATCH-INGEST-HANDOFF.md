# FINOPS — CloudWatch / config-service aggregate ingest (for emitter owners)

**Purpose:** Emitter (Gateway Configuration Service) configuration and contract. **Epic O.4.**

**Canonical copy:** May also live in the FINOPS repo; keep in sync when the contract changes.

## Endpoint

Point `cloudwatchanalyzer.analytics.api-url` (or `gaime.url`) to:

```text
POST {FINOPS_ORIGIN}/api/analytics/requests/aggregates/cloudwatch
Content-Type: application/json
```

Use **`/aggregates/cloudwatch`**, not `/aggregates`, unless you transform the body to `RequestAggregateRequest` yourself.

Example default in `application.yml`:

```yaml
cloudwatchanalyzer:
  analytics:
    api-url: ${FINOPS_ORIGIN:http://localhost:8081}/api/analytics/requests/aggregates/cloudwatch
```

Set **`FINOPS_ORIGIN`** in each environment (no trailing slash required; path is appended).

## JSON body (combined O-A shape)

Required: `source`, `count`, `totalOutputSize`, `windowStart`, `windowEnd` (ISO-8601 instants, e.g. `2026-03-02T10:00:00Z`).

| Field | Type | Required | Notes |
| ----- | ---- | -------- | ----- |
| `source` | string | yes | CIDR / `other` / passthrough |
| `patternUrl` | string | no | Maps to `endpoint`; blank → `"/"` |
| `status` | string | no | Numeric HTTP code 100–599; blank → `httpCode` null in upsert key |
| `count` | number | yes | ≥ 0 |
| `totalOutputSize` | number | yes | Maps to `totalOutputBytes`; ≥ 0 |
| `windowStart` | string (ISO-8601) | yes | CloudWatch query window start |
| `windowEnd` | string (ISO-8601) | yes | Must be after `windowStart` |
| `method` | string | no | Default `POST` |
| `logGroupService` | string | no | ECS service key from Insights `@log`. Omitted when unknown. |
| `serviceName` | string | no | Same as `logGroupService` when known (explicit ECS service label). Omitted when unknown. |
| `systemName` | string | no | **Separate from `source` and service:** CIDR mapping application name when matched; for unknown-IPv4 aggregate bucket a **representative client IP**; non-IPv4 → original source. Never concatenated with `source`. Omitted when blank. |
| `logGroupName` | string | no | Insights `@log`; FINOPS may parse routing from it |
| `avgResponseTimeMs` | number | no | Default `0` |
| `totalInputBytes` | number | no | Default `0` |

## Example

```json
{
  "source": "10.0.0.0/8",
  "patternUrl": "/api/v1/search",
  "status": "200",
  "count": 42,
  "totalOutputSize": 1048576,
  "windowStart": "2026-03-02T10:00:00Z",
  "windowEnd": "2026-03-02T10:15:00Z",
  "logGroupName": "610608459180:/aws/ecs/gps-qa-usrsrh-svc-01-use1",
  "logGroupService": "usrsrh",
  "serviceName": "usrsrh",
  "systemName": "corp"
}
```

## Emitter change checklist

- [x] For each merged row POST, set **`windowStart`** / **`windowEnd`** to the **same** CloudWatch Insights window used for that trigger run.
- [x] Set **`analytics.api-url`** to `.../api/analytics/requests/aggregates/cloudwatch` (via `FINOPS_ORIGIN` + path).
- [ ] Re-run manual trigger; confirm **2xx** from FINOPS and a document in `request_aggregates`.

## Code references (FINOPS service)

| Artifact | Location |
| -------- | -------- |
| DTO | `com.pearson.gps.analytics.CloudWatchAggregateIngestRequest` |
| Mapper | `com.pearson.gps.analytics.CloudWatchAggregateIngestMapper` |
| Service | `RequestAggregateService#upsertCloudWatchAggregate` |
| REST | `POST /analytics/requests/aggregates/cloudwatch` in `RequestLogController` |

---

*Last updated: 2026-03-22*
