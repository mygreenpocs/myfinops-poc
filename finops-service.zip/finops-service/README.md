# FinOps Service

Spring Boot service for CloudWatch log analytics aggregate triggers (FINOPS ingest). Extracted from Gateway Configuration Service (`config-service`).

## Server

- **Port:** `8081` (override with env `PORT`)
- **Context path:** `/api` — all paths below are relative to `http://localhost:8081/api`

## Endpoints

| Method | Path | Description |
| ------ | ---- | ----------- |
| POST | `/v1/cloudwatch/analytics/trigger` | Legacy manual trigger (`ManualTriggerResponse`) |
| POST | `/cloudwatch/trigger` | Spec trigger (`CloudWatchSpecTriggerResponse`, G.2) |
| GET | `/auth/openam-gateway-token` | OpenAM gateway JWT for UI |
| POST | `/ai/agents/invocations` | Proxy: create Pearson AI agent invocation |
| GET | `/ai/agents/invocations/{id}` | Proxy: fetch invocation status |

Query parameters: `startEpochSeconds` / `endEpochSeconds`, `window`, or spec `startTimeSeconds` / `endTimeSeconds`. Optional JSON body: `logGroups` or `logGroupName`.

## Documentation

| Topic | Location |
| ----- | -------- |
| CloudWatch pipeline, CIDR grouping, triggers | [`docs/CLOUDWATCH-CIDR-README-AND-PLAN.md`](docs/CLOUDWATCH-CIDR-README-AND-PLAN.md) |
| cURL test scenarios | [`docs/CLOUDWATCH-CURL-TEST-SCENARIOS.md`](docs/CLOUDWATCH-CURL-TEST-SCENARIOS.md) |
| FINOPS ingest handoff | [`docs/FINOPS-CLOUDWATCH-INGEST-HANDOFF.md`](docs/FINOPS-CLOUDWATCH-INGEST-HANDOFF.md) |

## Build & run

```bash
./gradlew build
./gradlew bootRun --args='--spring.profiles.active=local'
```

Use profile `local` for development (`application-local.yml`).

## Configuration

Primary prefix: `cloudwatchanalyzer` (see `application.yml`). CIDR rules load from MongoDB `cidrBlockMapping` when present, otherwise `cloudwatchanalyzer.cidr-blocks` YAML.
