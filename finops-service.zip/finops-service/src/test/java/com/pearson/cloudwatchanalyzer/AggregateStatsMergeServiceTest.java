package com.pearson.cloudwatchanalyzer;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import com.pearson.cloudwatchanalyzer.dto.AggregateStatsRow;
import com.pearson.cloudwatchanalyzer.repository.CidrBlockMappingRepository;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class AggregateStatsMergeServiceTest {

    @Mock
    private CidrBlockMappingRepository cidrBlockMappingRepository;

    private final CloudWatchAnalyzerProperties properties = new CloudWatchAnalyzerProperties();

    private AggregateStatsMergeService mergeService;

    @BeforeEach
    void setUp() {
        when(cidrBlockMappingRepository.count()).thenReturn(0L);
        CidrMappingService cidrMappingService = new CidrMappingService(cidrBlockMappingRepository, properties);
        mergeService = new AggregateStatsMergeService(cidrMappingService, properties);
    }

    @Test
    void mergesIpsInSameYamlCidr() {
        Map<String, String> yaml = new LinkedHashMap<>();
        yaml.put("10.0.0.0/8", "corp");
        properties.setCidrBlocks(yaml);

        List<AggregateStatsRow> raw =
                List.of(
                        new AggregateStatsRow("10.0.0.1", "/api/a", "200", 2, 100L),
                        new AggregateStatsRow("10.0.0.2", "/api/a", "200", 3, 50L));

        List<AggregateStatsMergeService.MergedStatsRow> out = mergeService.mergeAggregates(raw);

        assertThat(out).hasSize(1);
        AggregateStatsMergeService.MergedStatsRow m = out.get(0);
        assertThat(m.statsRow().getSource()).isEqualTo("10.0.0.0/8");
        assertThat(m.statsRow().getPatternUrl()).isEqualTo("/api/a");
        assertThat(m.statsRow().getStatus()).isEqualTo("200");
        assertThat(m.statsRow().getCount()).isEqualTo(5L);
        assertThat(m.statsRow().getTotalOutputSize()).isEqualTo(150L);
        assertThat(m.cidrBlock()).isEqualTo("10.0.0.0/8");
        assertThat(m.applicationName()).isEqualTo("corp");
        assertThat(m.payloadSystemName()).isEqualTo("corp");
        assertThat(m.finopsCidrBlock()).isEqualTo("10.0.0.0/8");
    }

    @Test
    void unknownIpv4InSameSlash16Merges() {
        properties.setCidrBlocks(Map.of());

        List<AggregateStatsRow> raw =
                List.of(
                        new AggregateStatsRow("8.8.8.8", "/x", "500", 1, 10L),
                        new AggregateStatsRow("8.8.9.9", "/x", "500", 4, 20L));

        List<AggregateStatsMergeService.MergedStatsRow> out = mergeService.mergeAggregates(raw);

        assertThat(out).hasSize(1);
        assertThat(out.get(0).statsRow().getSource()).isEqualTo("other");
        assertThat(out.get(0).statsRow().getCount()).isEqualTo(5L);
        assertThat(out.get(0).applicationName()).isEqualTo("other");
        assertThat(out.get(0).payloadSystemName()).isEqualTo("other");
        assertThat(out.get(0).cidrBlock()).isEqualTo("8.8.0.0/16");
        assertThat(out.get(0).finopsCidrBlock()).isEqualTo("8.8.0.0/16");
    }

    @Test
    void unknownIpv4DifferentSlash16StaysSeparate() {
        properties.setCidrBlocks(Map.of());

        List<AggregateStatsRow> raw =
                List.of(
                        new AggregateStatsRow("8.8.8.8", "/x", "500", 1, 10L),
                        new AggregateStatsRow("1.1.1.1", "/x", "500", 4, 20L));

        List<AggregateStatsMergeService.MergedStatsRow> out = mergeService.mergeAggregates(raw);

        assertThat(out).hasSize(2);
        assertThat(out.stream().map(AggregateStatsMergeService.MergedStatsRow::finopsCidrBlock))
                .containsExactlyInAnyOrder("8.8.0.0/16", "1.1.0.0/16");
    }

    @Test
    void unknownIpv4Prefix32KeepsDistinctHosts() {
        properties.setCidrBlocks(Map.of());
        properties.setUnknownIpv4AggregatePrefixLength(32);

        List<AggregateStatsRow> raw =
                List.of(
                        new AggregateStatsRow("8.8.8.8", "/x", "500", 1, 10L),
                        new AggregateStatsRow("8.8.8.9", "/x", "500", 4, 20L));

        List<AggregateStatsMergeService.MergedStatsRow> out = mergeService.mergeAggregates(raw);

        assertThat(out).hasSize(2);
        assertThat(out.stream().map(AggregateStatsMergeService.MergedStatsRow::finopsCidrBlock))
                .containsExactlyInAnyOrder("8.8.8.8/32", "8.8.8.9/32");
    }

    @Test
    void nonIpv4SourcesStayDistinct() {
        properties.setCidrBlocks(Map.of());

        List<AggregateStatsRow> raw =
                List.of(
                        new AggregateStatsRow("host-a.internal", "/p", "200", 1, 5L),
                        new AggregateStatsRow("host-b.internal", "/p", "200", 2, 7L));

        List<AggregateStatsMergeService.MergedStatsRow> out = mergeService.mergeAggregates(raw);

        assertThat(out).hasSize(2);
        assertThat(out.stream().map(m -> m.statsRow().getSource()))
                .containsExactlyInAnyOrder("host-a.internal", "host-b.internal");
        assertThat(out.stream().map(AggregateStatsMergeService.MergedStatsRow::payloadSystemName))
                .containsExactlyInAnyOrder("host-a.internal", "host-b.internal");
    }

    @Test
    void differentPatternUrlStaysSeparateForSameCidr() {
        properties.setCidrBlocks(Map.of("10.0.0.0/8", "corp"));

        List<AggregateStatsRow> raw =
                List.of(
                        new AggregateStatsRow("10.0.0.1", "/a", "200", 1, 1L),
                        new AggregateStatsRow("10.0.0.2", "/b", "200", 1, 2L));

        List<AggregateStatsMergeService.MergedStatsRow> out = mergeService.mergeAggregates(raw);

        assertThat(out).hasSize(2);
    }

    @Test
    void sameCidrDifferentLogSystemNameStaysSeparate() {
        properties.setCidrBlocks(Map.of("10.0.0.0/8", "corp"));

        List<AggregateStatsRow> raw =
                List.of(
                        new AggregateStatsRow(
                                "10.0.0.1", "/api/a", "200", 1, 10L, "", "", "app-a.example"),
                        new AggregateStatsRow(
                                "10.0.0.2", "/api/a", "200", 2, 20L, "", "", "app-b.example"));

        List<AggregateStatsMergeService.MergedStatsRow> out = mergeService.mergeAggregates(raw);

        assertThat(out).hasSize(2);
        assertThat(out.stream().map(AggregateStatsMergeService.MergedStatsRow::timeLoggerSystemName))
                .containsExactlyInAnyOrder("app-a.example", "app-b.example");
    }
}
