package com.pearson.cloudwatchanalyzer;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.pearson.cloudwatchanalyzer.dto.CloudWatchTriggerRequestBody;
import java.time.Duration;
import java.util.List;
import org.junit.jupiter.api.Test;

class CloudWatchManualTriggerControllerParseTest {

    @Test
    void parsesSimpleDurations() {
        assertThat(CloudWatchManualTriggerController.parseOptionalWindowParameter("15m"))
                .isEqualTo(Duration.ofMinutes(15));
        assertThat(CloudWatchManualTriggerController.parseOptionalWindowParameter("2d"))
                .isEqualTo(Duration.ofDays(2));
        assertThat(CloudWatchManualTriggerController.parseOptionalWindowParameter(" 1h "))
                .isEqualTo(Duration.ofHours(1));
    }

    @Test
    void parsesIso8601Duration() {
        assertThat(CloudWatchManualTriggerController.parseOptionalWindowParameter("PT30M"))
                .isEqualTo(Duration.ofMinutes(30));
    }

    @Test
    void blankMeansAbsent() {
        assertThat(CloudWatchManualTriggerController.parseOptionalWindowParameter(null)).isNull();
        assertThat(CloudWatchManualTriggerController.parseOptionalWindowParameter("  ")).isNull();
    }

    @Test
    void rejectsGarbage() {
        assertThatThrownBy(() -> CloudWatchManualTriggerController.parseOptionalWindowParameter("not-a-duration"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Invalid window");
    }

    @Test
    void logGroupsFromBody_nullMeansNoOverride() {
        assertThat(CloudWatchManualTriggerController.logGroupsFromBody(null)).isNull();
    }

    @Test
    void logGroupsFromBody_logGroupNameOnly() {
        CloudWatchTriggerRequestBody body = new CloudWatchTriggerRequestBody();
        body.setLogGroupName("  /aws/ecs/a  ");
        assertThat(CloudWatchManualTriggerController.logGroupsFromBody(body))
                .containsExactly("/aws/ecs/a");
    }

    @Test
    void logGroupsFromBody_logGroupsWinsOverLogGroupName() {
        CloudWatchTriggerRequestBody body = new CloudWatchTriggerRequestBody();
        body.setLogGroups(List.of("/aws/ecs/b"));
        body.setLogGroupName("/aws/ecs/ignored");
        assertThat(CloudWatchManualTriggerController.logGroupsFromBody(body)).containsExactly("/aws/ecs/b");
    }

    @Test
    void logGroupsFromBody_emptyListFallsBackToLogGroupName() {
        CloudWatchTriggerRequestBody body = new CloudWatchTriggerRequestBody();
        body.setLogGroups(List.of());
        body.setLogGroupName("/aws/ecs/c");
        assertThat(CloudWatchManualTriggerController.logGroupsFromBody(body)).containsExactly("/aws/ecs/c");
    }
}
