package com.pearson.cloudwatchanalyzer;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import com.pearson.cloudwatchanalyzer.dto.CloudWatchSpecTriggerResponse;
import com.pearson.cloudwatchanalyzer.dto.ManualTriggerResponse;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@ExtendWith(MockitoExtension.class)
class CloudWatchSpecTriggerControllerTest {

    @Mock
    private CloudWatchTriggerHttpCoordinator coordinator;

    @Test
    void execute_mapsPreflight503ToSpecBody() {
        ManualTriggerResponse failure = ManualTriggerResponse.failure("off");
        when(coordinator.preflightManualTrigger())
                .thenReturn(Optional.of(ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(failure)));

        ResponseEntity<CloudWatchSpecTriggerResponse> r =
                CloudWatchSpecTriggerController.SpecTriggerSupport.execute(
                        coordinator, null, null, null, null, null, null, null);

        assertThat(r.getStatusCode()).isEqualTo(HttpStatus.SERVICE_UNAVAILABLE);
        assertThat(r.getBody()).isNotNull();
        assertThat(r.getBody().isSuccess()).isFalse();
        assertThat(r.getBody().getMessage()).isEqualTo("off");
    }

    @Test
    void execute_usesStartTimeSecondsForPipeline() {
        when(coordinator.preflightManualTrigger()).thenReturn(Optional.empty());
        ManualTriggerResponse ok = new ManualTriggerResponse();
        ok.setSuccess(true);
        when(coordinator.executePipeline(5L, 6L, null, null, null)).thenReturn(ResponseEntity.ok(ok));

        CloudWatchSpecTriggerController.SpecTriggerSupport.execute(
                coordinator, 5L, 6L, null, null, null, null, null);

        org.mockito.Mockito.verify(coordinator).executePipeline(5L, 6L, null, null, null);
    }
}
