package com.pearson.cloudwatchanalyzer.cidr;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.Test;

class Ipv4CanonicalNetworkTest {

    @Test
    void slash16ClearsHostOctets() {
        assertThat(Ipv4CanonicalNetwork.networkCidr("10.12.3.4", 16)).isEqualTo("10.12.0.0/16");
    }

    @Test
    void slash32IsSingleHost() {
        assertThat(Ipv4CanonicalNetwork.networkCidr("203.0.113.7", 32)).isEqualTo("203.0.113.7/32");
    }

    @Test
    void invalidHostReturnsNull() {
        assertThat(Ipv4CanonicalNetwork.networkCidr("not-an-ip", 16)).isNull();
    }

    @Test
    void prefixOutOfRangeThrows() {
        assertThatThrownBy(() -> Ipv4CanonicalNetwork.networkCidr("1.0.0.0", 33))
                .isInstanceOf(IllegalArgumentException.class);
    }
}
