package com.pearson.cloudwatchanalyzer;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import com.pearson.cloudwatchanalyzer.cidr.CidrMatchResult;
import com.pearson.cloudwatchanalyzer.cidr.CidrMatcher;
import com.pearson.cloudwatchanalyzer.cidr.CidrRule;
import com.pearson.cloudwatchanalyzer.entity.CidrBlockMapping;
import com.pearson.cloudwatchanalyzer.repository.CidrBlockMappingRepository;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class CidrMappingServiceTest {

    @Mock
    private CidrBlockMappingRepository repository;

    private final CloudWatchAnalyzerProperties properties = new CloudWatchAnalyzerProperties();

    private CidrMappingService service;

    @BeforeEach
    void setUp() {
        service = new CidrMappingService(repository, properties);
    }

    @Test
    void whenMongoEmpty_usesYamlCidrBlocksInOrder() {
        when(repository.count()).thenReturn(0L);
        Map<String, String> yaml = new LinkedHashMap<>();
        yaml.put("10.0.0.0/8", "corp");
        yaml.put("192.168.1.1", "edge"); // bare IPv4 → /32
        properties.setCidrBlocks(yaml);

        List<CidrRule> rules = service.loadOrderedRules();

        assertThat(rules).hasSize(2);
        assertThat(rules.get(0).getCidrBlock()).isEqualTo("10.0.0.0/8");
        assertThat(rules.get(0).getSortOrder()).isZero();
        assertThat(rules.get(1).getCidrBlock()).isEqualTo("192.168.1.1/32");
        assertThat(rules.get(1).getSortOrder()).isEqualTo(1);

        CidrMatcher matcher = CidrMatcher.fromRules(rules);
        assertThat(matcher.resolve("10.1.2.3").getKind()).isEqualTo(CidrMatchResult.Kind.MATCHED);
        assertThat(matcher.resolve("10.1.2.3").getApplicationName()).isEqualTo("corp");
    }

    @Test
    void whenMongoHasRows_ignoresYaml() {
        when(repository.count()).thenReturn(1L);
        CidrBlockMapping doc = new CidrBlockMapping();
        doc.setId("id1");
        doc.setCidrBlock("172.16.0.0/16");
        doc.setApplicationName("from-db");
        doc.setSortOrder(5);
        when(repository.findAllByOrderBySortOrderAsc()).thenReturn(List.of(doc));

        properties.setCidrBlocks(Map.of("10.0.0.0/8", "yaml-should-not-use"));

        List<CidrRule> rules = service.loadOrderedRules();

        assertThat(rules).singleElement().satisfies(r -> {
            assertThat(r.getCidrBlock()).isEqualTo("172.16.0.0/16");
            assertThat(r.getApplicationName()).isEqualTo("from-db");
            assertThat(r.getSortOrder()).isEqualTo(5);
        });
    }

    @Test
    void whenMongoEmptyAndYamlEmpty_returnsEmptyRules() {
        when(repository.count()).thenReturn(0L);
        properties.setCidrBlocks(Map.of());

        assertThat(service.loadOrderedRules()).isEmpty();
        assertThat(service.effectiveConfigMap()).isEmpty();
        assertThat(service.buildMatcher().resolve("8.8.8.8").getKind()).isEqualTo(CidrMatchResult.Kind.UNKNOWN);
    }

    @Test
    void effectiveConfigMap_matchesYamlEntries() {
        when(repository.count()).thenReturn(0L);
        Map<String, String> yaml = new LinkedHashMap<>();
        yaml.put("10.0.0.0/8", "corp");
        properties.setCidrBlocks(yaml);

        assertThat(service.effectiveConfigMap()).containsEntry("10.0.0.0/8", "corp");
    }

    @Test
    void skipsInvalidMongoDocuments() {
        when(repository.count()).thenReturn(2L);
        CidrBlockMapping bad = new CidrBlockMapping();
        bad.setId("bad");
        bad.setCidrBlock("not-a-cidr");
        bad.setApplicationName("x");
        bad.setSortOrder(0);
        CidrBlockMapping good = new CidrBlockMapping();
        good.setId("good");
        good.setCidrBlock("203.0.113.0/24");
        good.setApplicationName("ok");
        good.setSortOrder(1);
        when(repository.findAllByOrderBySortOrderAsc()).thenReturn(List.of(bad, good));

        List<CidrRule> rules = service.loadOrderedRules();

        assertThat(rules).singleElement().extracting(CidrRule::getCidrBlock).isEqualTo("203.0.113.0/24");
    }
}
