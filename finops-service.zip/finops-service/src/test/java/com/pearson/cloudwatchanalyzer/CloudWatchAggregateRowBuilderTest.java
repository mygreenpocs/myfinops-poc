package com.pearson.cloudwatchanalyzer;

import static org.assertj.core.api.Assertions.assertThat;

import com.pearson.cloudwatchanalyzer.dto.AggregateStatsRow;
import com.pearson.cloudwatchanalyzer.dto.AggregateTriggerRow;
import java.util.ArrayList;
import org.junit.jupiter.api.Test;

class CloudWatchAggregateRowBuilderTest {

    private final CloudWatchAggregateRowBuilder builder = new CloudWatchAggregateRowBuilder();

    @Test
    void prefersLogSystemNameWhenPresent_andEchoesClientIp() {
        AggregateStatsRow stats = new AggregateStatsRow("other", "/x", "500", 1, 10L, "", "", "");
        AggregateStatsMergeService.MergedStatsRow merged =
                new AggregateStatsMergeService.MergedStatsRow(
                        stats, "8.8.0.0/16", "other", "other", "client.example.org", "8.8.8.8");

        AggregateTriggerRow row = builder.buildMergedRow(merged, 1L, 2L);

        assertThat(row.getCloudWatchRow().get("systemName")).isEqualTo("client.example.org");
        assertThat(row.getCloudWatchRow().get("clientIp")).isEqualTo("8.8.8.8");
    }

    @Test
    void cloudWatchRowKeysAreStableOrder() {
        AggregateStatsRow stats = new AggregateStatsRow("corp", "/x", "200", 1, 1L, "", "", "");
        AggregateStatsMergeService.MergedStatsRow merged =
                new AggregateStatsMergeService.MergedStatsRow(stats, "10.0.0.0/8", "corp", "corp", "", "10.0.0.1");

        AggregateTriggerRow row = builder.buildMergedRow(merged, 0L, 0L);

        assertThat(new ArrayList<>(row.getCloudWatchRow().keySet()))
                .containsExactly(
                        "patternUrl",
                        "status",
                        "method",
                        "count",
                        "totalOutputSize",
                        "serviceName",
                        "logGroupName",
                        "systemName",
                        "clientIp",
                        "windowStart",
                        "windowEnd");
    }
}
