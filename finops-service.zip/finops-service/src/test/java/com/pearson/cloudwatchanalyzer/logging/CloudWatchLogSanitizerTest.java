package com.pearson.cloudwatchanalyzer.logging;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class CloudWatchLogSanitizerTest {

    @Test
    void truncatesLongStrings() {
        String s = "x".repeat(600);
        assertThat(CloudWatchLogSanitizer.truncateForLog(s, 100)).hasSize(100 + "...(truncated,len=600)".length());
    }
}
