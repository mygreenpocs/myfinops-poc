package com.pearson.cloudwatchanalyzer;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import com.pearson.cloudwatchanalyzer.dto.AggregateStatsRow;
import com.pearson.cloudwatchanalyzer.dto.ManualTriggerResponse;
import java.time.Duration;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class CloudWatchTriggerServiceTest {

    @Mock
    private CloudWatchQueryService queryService;

    @Mock
    private CloudWatchLogGroupDiscoveryService discoveryService;

    @Mock
    private AggregateStatsMergeService aggregateStatsMergeService;

    private final CloudWatchAnalyzerProperties properties = new CloudWatchAnalyzerProperties();

    private CloudWatchTriggerService triggerService;

    @BeforeEach
    void setUp() {
        properties.setEnabled(true);
        properties.getQuery().setUseLogGroupDiscovery(false);
        properties.getQuery().setLogGroups(List.of("/aws/ecs/test-group"));
        properties.getQuery().setWindowSeconds(120);
        properties.getQuery().setMaxWindowSeconds(86_400);
        lenient()
                .when(aggregateStatsMergeService.mergeAggregates(anyList()))
                .thenAnswer(
                        inv -> {
                            @SuppressWarnings("unchecked")
                            List<AggregateStatsRow> list = inv.getArgument(0);
                            return list.stream()
                                    .map(
                                            r ->
                                                    new AggregateStatsMergeService.MergedStatsRow(
                                                            r, "", "", r.getSource(), "", r.getSource()))
                                    .toList();
                        });
        CloudWatchAggregateRowBuilder rowBuilder = new CloudWatchAggregateRowBuilder();
        triggerService = new CloudWatchTriggerService(
                queryService,
                discoveryService,
                properties,
                aggregateStatsMergeService,
                rowBuilder);
    }

    @Test
    void runOnce_usesStaticLogGroups_runsAggregateQuery_returnsRows() {
        List<AggregateStatsRow> rows =
                List.of(new AggregateStatsRow("10.0.0.1", "/api/foo", "200", 5, 1200L));
        when(queryService.executeAggregateTimeLoggerQuery(eq(List.of("/aws/ecs/test-group")), anyLong(), anyLong(), org.mockito.ArgumentMatchers.nullable(String.class)))
                .thenReturn(rows);

        ManualTriggerResponse resp = triggerService.runOnce();

        assertThat(resp.isSuccess()).isTrue();
        assertThat(resp.getRowCount()).isEqualTo(1);
        assertThat(resp.getRows()).hasSize(1);
        assertThat(resp.getRows().get(0).getCloudWatchRow()).isNotEmpty();
        assertThat(resp.getMessage()).contains("merge");
    }

    @Test
    void runOnce_usesDiscoveryWhenConfigured() {
        properties.getQuery().setUseLogGroupDiscovery(true);
        when(discoveryService.discoverLogGroups()).thenReturn(List.of("/discovered/a", "/discovered/b"));
        when(queryService.executeAggregateTimeLoggerQuery(
                        eq(List.of("/discovered/a", "/discovered/b")), anyLong(), anyLong(), org.mockito.ArgumentMatchers.nullable(String.class)))
                .thenReturn(List.of());

        ManualTriggerResponse resp = triggerService.runOnce();

        assertThat(resp.getRowCount()).isZero();
        verify(queryService).executeAggregateTimeLoggerQuery(eq(List.of("/discovered/a", "/discovered/b")), anyLong(), anyLong(), org.mockito.ArgumentMatchers.nullable(String.class));
    }

    @Test
    void runOnce_whenDiscoveryEmpty_fallsBackToStaticLogGroups() {
        properties.getQuery().setUseLogGroupDiscovery(true);
        when(discoveryService.discoverLogGroups()).thenReturn(List.of());
        when(queryService.executeAggregateTimeLoggerQuery(
                        eq(List.of("/aws/ecs/test-group")), anyLong(), anyLong(), org.mockito.ArgumentMatchers.nullable(String.class)))
                .thenReturn(List.of());

        ManualTriggerResponse resp = triggerService.runOnce();

        assertThat(resp.isSuccess()).isTrue();
        verify(queryService).executeAggregateTimeLoggerQuery(eq(List.of("/aws/ecs/test-group")), anyLong(), anyLong(), org.mockito.ArgumentMatchers.nullable(String.class));
    }

    @Test
    void runOnce_requestBodyLogGroupsOverride_skipsDiscovery() {
        properties.getQuery().setUseLogGroupDiscovery(true);
        List<String> override = List.of("/override/one", "/override/two");
        when(queryService.executeAggregateTimeLoggerQuery(eq(override), anyLong(), anyLong(), org.mockito.ArgumentMatchers.nullable(String.class)))
                .thenReturn(List.of());

        ManualTriggerResponse resp = triggerService.runOnce(null, null, null, null, override);

        assertThat(resp.isSuccess()).isTrue();
        verify(queryService).executeAggregateTimeLoggerQuery(eq(override), anyLong(), anyLong(), org.mockito.ArgumentMatchers.nullable(String.class));
        verify(discoveryService, never()).discoverLogGroups();
        verifyNoMoreInteractions(discoveryService);
    }

    @Test
    void runOnce_withExplicitEpochRange_passesRangeToQuery() {
        when(queryService.executeAggregateTimeLoggerQuery(
                        eq(List.of("/aws/ecs/test-group")), eq(1_700_000_000L), eq(1_700_000_100L), org.mockito.ArgumentMatchers.nullable(String.class)))
                .thenReturn(List.of());

        ManualTriggerResponse resp = triggerService.runOnce(1_700_000_000L, 1_700_000_100L);

        assertThat(resp.isSuccess()).isTrue();
        verify(queryService)
                .executeAggregateTimeLoggerQuery(
                        eq(List.of("/aws/ecs/test-group")), eq(1_700_000_000L), eq(1_700_000_100L), org.mockito.ArgumentMatchers.nullable(String.class));
    }

    @Test
    void runOnce_rejectsSingleEpochParam() {
        assertThatThrownBy(() -> triggerService.runOnce(1L, null))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Both startEpochSeconds");
        assertThatThrownBy(() -> triggerService.runOnce(null, 2L))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Both startEpochSeconds");
    }

    @Test
    void runOnce_rejectsSpanAboveMaxWindow() {
        properties.getQuery().setMaxWindowSeconds(50);
        assertThatThrownBy(() -> triggerService.runOnce(100L, 200L))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("max-window");
    }

    @Test
    void runOnce_rejectsConfiguredWindowAboveMax() {
        properties.getQuery().setWindowSeconds(10_000);
        properties.getQuery().setMaxWindowSeconds(100);
        assertThatThrownBy(() -> triggerService.runOnce())
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("query.window");
    }

    @Test
    void runOnce_rejectsEpochRangeCombinedWithWindowParam() {
        assertThatThrownBy(() -> triggerService.runOnce(1L, 2L, Duration.ofHours(1)))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("not both");
    }

    @Test
    void runOnce_withRequestWindow_usesThatSpan() {
        when(queryService.executeAggregateTimeLoggerQuery(
                        eq(List.of("/aws/ecs/test-group")), anyLong(), anyLong(), org.mockito.ArgumentMatchers.nullable(String.class)))
                .thenReturn(List.of());

        ManualTriggerResponse resp = triggerService.runOnce(null, null, Duration.ofMinutes(7));

        assertThat(resp.isSuccess()).isTrue();
        ArgumentCaptor<Long> startCap = ArgumentCaptor.forClass(Long.class);
        ArgumentCaptor<Long> endCap = ArgumentCaptor.forClass(Long.class);
        verify(queryService)
                .executeAggregateTimeLoggerQuery(
                        eq(List.of("/aws/ecs/test-group")), startCap.capture(), endCap.capture(), org.mockito.ArgumentMatchers.nullable(String.class));
        assertThat(endCap.getValue() - startCap.getValue()).isEqualTo(Duration.ofMinutes(7).toSeconds());
        assertThat(endCap.getValue()).isEqualTo(resp.getWindowEndEpochSeconds());
    }

    @Test
    void runOnce_mergeServiceCombinesRows() {
        List<AggregateStatsRow> raw =
                List.of(
                        new AggregateStatsRow("10.0.0.1", "/api/foo", "200", 3, 100L),
                        new AggregateStatsRow("10.0.0.2", "/api/foo", "200", 2, 50L));
        when(queryService.executeAggregateTimeLoggerQuery(eq(List.of("/aws/ecs/test-group")), anyLong(), anyLong(), org.mockito.ArgumentMatchers.nullable(String.class)))
                .thenReturn(raw);
        when(aggregateStatsMergeService.mergeAggregates(raw))
                .thenReturn(
                        List.of(
                                new AggregateStatsMergeService.MergedStatsRow(
                                        new AggregateStatsRow("10.0.0.0/8", "/api/foo", "200", 5, 150L),
                                        "10.0.0.0/8",
                                        "corp",
                                        "corp",
                                        "",
                                        "10.0.0.1")));

        ManualTriggerResponse resp = triggerService.runOnce();

        assertThat(resp.getRowCount()).isEqualTo(1);
        assertThat(resp.getRows()).hasSize(1);
        verify(aggregateStatsMergeService).mergeAggregates(raw);
    }
}
