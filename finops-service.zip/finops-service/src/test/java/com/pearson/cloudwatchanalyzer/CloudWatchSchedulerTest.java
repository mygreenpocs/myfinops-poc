package com.pearson.cloudwatchanalyzer;

import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.pearson.cloudwatchanalyzer.dto.ManualTriggerResponse;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class CloudWatchSchedulerTest {

    @Mock
    private CloudWatchTriggerService cloudWatchTriggerService;

    @Mock
    private CloudWatchAnalyzerProperties properties;

    @Test
    void runScheduledQuery_skipsWhenAnalyzerDisabled() {
        when(properties.isEnabled()).thenReturn(false);
        CloudWatchScheduler scheduler =
                new CloudWatchScheduler(Optional.of(cloudWatchTriggerService), properties);

        scheduler.runScheduledQuery();

        verify(cloudWatchTriggerService, never()).runOnce();
    }

    @Test
    void runScheduledQuery_skipsWhenTriggerBeanAbsent() {
        when(properties.isEnabled()).thenReturn(true);
        CloudWatchScheduler scheduler = new CloudWatchScheduler(Optional.empty(), properties);

        scheduler.runScheduledQuery();

        verify(cloudWatchTriggerService, never()).runOnce();
    }

    @Test
    void runScheduledQuery_invokesRunOnceWhenBeanPresent() {
        when(properties.isEnabled()).thenReturn(true);
        when(cloudWatchTriggerService.runOnce()).thenReturn(new ManualTriggerResponse());
        CloudWatchScheduler scheduler =
                new CloudWatchScheduler(Optional.of(cloudWatchTriggerService), properties);

        scheduler.runScheduledQuery();

        verify(cloudWatchTriggerService).runOnce();
    }
}
