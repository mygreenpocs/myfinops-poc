package com.pearson.cloudwatchanalyzer.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.LinkedHashMap;
import java.util.Map;
import org.junit.jupiter.api.Test;

class CloudWatchSpecTriggerResponseTest {

    @Test
    void mapsManualResponseToSpecShape() {
        ManualTriggerResponse manual = new ManualTriggerResponse();
        manual.setSuccess(true);
        manual.setMessage("ok");
        manual.setWindowStartEpochSeconds(1);
        manual.setWindowEndEpochSeconds(2);
        manual.setRowCount(1);

        AggregateTriggerRow row = new AggregateTriggerRow();
        Map<String, String> echo = new LinkedHashMap<>();
        echo.put("patternUrl", "/x");
        echo.put("status", "200");
        echo.put("count", "3");
        echo.put("totalOutputSize", "9");
        echo.put("serviceName", "usrsrh");
        echo.put("logGroupName", "/aws/ecs/x");
        echo.put("systemName", "corp");
        echo.put("clientIp", "10.0.0.1");
        echo.put("windowStart", "1970-01-01T00:00:01Z");
        echo.put("windowEnd", "1970-01-01T00:00:02Z");
        row.setCloudWatchRow(echo);
        manual.getRows().add(row);

        CloudWatchSpecTriggerResponse spec = CloudWatchSpecTriggerResponse.from(manual);

        assertThat(spec.isSuccess()).isTrue();
        assertThat(spec.getRowDetails()).hasSize(1);
        CloudWatchSpecTriggerResponse.CloudWatchDimensions d =
                spec.getRowDetails().get(0).getCloudWatchDimensions();
        assertThat(d.getPatternUrl()).isEqualTo("/x");
        assertThat(d.getServiceName()).isEqualTo("usrsrh");
        assertThat(d.getSystemName()).isEqualTo("corp");
        assertThat(d.getClientIp()).isEqualTo("10.0.0.1");
        assertThat(d.getWindowStart()).isEqualTo("1970-01-01T00:00:01Z");
    }

    @Test
    void failureResponseHasEmptyRowDetails() {
        ManualTriggerResponse manual = ManualTriggerResponse.failure("nope");
        CloudWatchSpecTriggerResponse spec = CloudWatchSpecTriggerResponse.from(manual);
        assertThat(spec.isSuccess()).isFalse();
        assertThat(spec.getMessage()).isEqualTo("nope");
        assertThat(spec.getRowDetails()).isEmpty();
    }
}
