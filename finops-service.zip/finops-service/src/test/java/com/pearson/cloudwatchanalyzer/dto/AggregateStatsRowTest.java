package com.pearson.cloudwatchanalyzer.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Map;
import org.junit.jupiter.api.Test;

class AggregateStatsRowTest {

    @Test
    void tryParse_mapsAllFields() {
        var row =
                AggregateStatsRow.tryParse(
                        Map.of(
                                "source", "10.0.0.1",
                                "patternUrl", "POST:/v1/x",
                                "status", "200",
                                "count", "12",
                                "totalOutputSize", "16464"));

        assertThat(row).isPresent();
        AggregateStatsRow a = row.get();
        assertThat(a.getSource()).isEqualTo("10.0.0.1");
        assertThat(a.getPatternUrl()).isEqualTo("POST:/v1/x");
        assertThat(a.getStatus()).isEqualTo("200");
        assertThat(a.getCount()).isEqualTo(12);
        assertThat(a.getTotalOutputSize()).isEqualTo(16464);
    }

    @Test
    void tryParse_isCaseInsensitiveForKeys() {
        var row =
                AggregateStatsRow.tryParse(
                        Map.of(
                                "SOURCE", "NA",
                                "PATTERNURL", "GET:/y",
                                "STATUS", "500",
                                "Count", "1",
                                "totaloutputsize", "100"));

        assertThat(row).isPresent();
        assertThat(row.get().getCount()).isEqualTo(1);
    }

    @Test
    void tryParse_emptyWhenRequiredMissing() {
        assertThat(
                        AggregateStatsRow.tryParse(
                                Map.of(
                                        "source", "x",
                                        "patternUrl", "y",
                                        "status", "200")))
                .isEmpty();
    }

    @Test
    void tryParse_acceptsCommaSeparatedNumbers() {
        var row =
                AggregateStatsRow.tryParse(
                        Map.of(
                                "source", "s",
                                "patternUrl", "p",
                                "status", "200",
                                "count", "1,000",
                                "totalOutputSize", "2,000"));

        assertThat(row).isPresent();
        assertThat(row.get().getCount()).isEqualTo(1000);
        assertThat(row.get().getTotalOutputSize()).isEqualTo(2000);
    }

    @Test
    void parseLongFlexible_roundsDecimal() {
        assertThat(AggregateStatsRow.parseLongFlexible("99.7")).isEqualTo(100);
    }

    @Test
    void tryParse_readsSystemNameColumn() {
        var row =
                AggregateStatsRow.tryParse(
                        Map.of(
                                "source", "10.0.0.1",
                                "patternUrl", "GET:/a",
                                "status", "200",
                                "count", "1",
                                "totalOutputSize", "10",
                                "systemName", "client.corp.example"));

        assertThat(row).isPresent();
        assertThat(row.get().getTimeLoggerSystemName()).isEqualTo("client.corp.example");
    }

    @Test
    void tryParse_sysNameAliasFallsBackWhenSystemNameAbsent() {
        var row =
                AggregateStatsRow.tryParse(
                        Map.of(
                                "source", "10.0.0.1",
                                "patternUrl", "GET:/a",
                                "status", "200",
                                "count", "1",
                                "totalOutputSize", "10",
                                "sysName", "legacy.sys"));

        assertThat(row).isPresent();
        assertThat(row.get().getTimeLoggerSystemName()).isEqualTo("legacy.sys");
    }

    @Test
    void tryParse_extractsLogGroupService_fromInsightsLog() {
        var row =
                AggregateStatsRow.tryParse(
                        Map.of(
                                "source", "10.0.0.1",
                                "patternUrl", "GET:/a",
                                "status", "200",
                                "count", "1",
                                "totalOutputSize", "10",
                                "@log", "/aws/ecs/gps-qa-usrsrh-svc-01-use1"),
                        "gps-qa");

        assertThat(row).isPresent();
        assertThat(row.get().getLogGroupName()).isEqualTo("/aws/ecs/gps-qa-usrsrh-svc-01-use1");
        assertThat(row.get().getLogGroupService()).isEqualTo("usrsrh");
    }

    @Test
    void tryParse_extractsLogGroupService_whenLogHasAccountIdPrefix() {
        var row =
                AggregateStatsRow.tryParse(
                        Map.of(
                                "source", "10.0.0.1",
                                "patternUrl", "GET:/a",
                                "status", "200",
                                "count", "1",
                                "totalOutputSize", "10",
                                "@log", "610608459180:/aws/ecs/gps-qa-usrsrh-svc-01-use1"),
                        "gps-qa");

        assertThat(row).isPresent();
        assertThat(row.get().getLogGroupName()).isEqualTo("610608459180:/aws/ecs/gps-qa-usrsrh-svc-01-use1");
        assertThat(row.get().getLogGroupService()).isEqualTo("usrsrh");
    }
}
