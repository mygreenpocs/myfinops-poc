package com.pearson.cloudwatchanalyzer.cidr;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.List;
import org.junit.jupiter.api.Test;

class CidrMatcherTest {

    @Test
    void invalidRuleCidrRejected() {
        assertThatThrownBy(() -> new CidrRule("not-a-cidr", "app", 0)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new CidrRule("10.0.0.0/99", "app", 0)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void insideBlockAndBoundaries() {
        CidrMatcher m =
                CidrMatcher.fromRules(
                        List.of(new CidrRule("10.0.0.0/8", "ten-net", 10)));
        assertThat(m.resolve("10.0.0.1").getKind()).isEqualTo(CidrMatchResult.Kind.MATCHED);
        assertThat(m.resolve("10.0.0.1").getApplicationName()).isEqualTo("ten-net");
        assertThat(m.resolve("10.0.0.0").getKind()).isEqualTo(CidrMatchResult.Kind.MATCHED);
        assertThat(m.resolve("10.255.255.255").getKind()).isEqualTo(CidrMatchResult.Kind.MATCHED);
    }

    @Test
    void overlapping_firstSortOrderWins() {
        CidrMatcher m =
                CidrMatcher.fromRules(
                        List.of(
                                new CidrRule("10.0.0.0/8", "broad", 20),
                                new CidrRule("10.1.0.0/16", "narrow", 10)));
        CidrMatchResult r = m.resolve("10.1.0.5");
        assertThat(r.getKind()).isEqualTo(CidrMatchResult.Kind.MATCHED);
        assertThat(r.getApplicationName()).isEqualTo("narrow");
        assertThat(r.getCidrBlock()).isEqualTo("10.1.0.0/16");
    }

    @Test
    void overlapping_equalSortOrder_stableByCidrString() {
        CidrMatcher m =
                CidrMatcher.fromRules(
                        List.of(
                                new CidrRule("10.0.0.0/8", "a", 0),
                                new CidrRule("172.16.0.0/12", "b", 0)));
        assertThat(m.resolve("10.5.5.5").getApplicationName()).isEqualTo("a");
    }

    @Test
    void unknownIpv4WhenNoRuleMatches() {
        CidrMatcher m = CidrMatcher.fromRules(List.of(new CidrRule("192.168.0.0/16", "lan", 0)));
        CidrMatchResult r = m.resolve("8.8.8.8");
        assertThat(r.getKind()).isEqualTo(CidrMatchResult.Kind.UNKNOWN);
        assertThat(r.getApplicationName()).isEqualTo("other");
    }

    @Test
    void emptyRules_unknownForIpv4() {
        CidrMatcher m = CidrMatcher.fromRules(List.of());
        assertThat(m.resolve("1.2.3.4").getKind()).isEqualTo(CidrMatchResult.Kind.UNKNOWN);
    }

    @Test
    void nonIpv4_hostnameLiteralBlankNa() {
        CidrMatcher m =
                CidrMatcher.fromRules(List.of(new CidrRule("127.0.0.0/8", "loop", 0)));
        assertThat(m.resolve("api.pearson.com").getKind()).isEqualTo(CidrMatchResult.Kind.NON_IPV4);
        assertThat(m.resolve("api.pearson.com").getApplicationName()).isEqualTo("api.pearson.com");

        assertThat(m.resolve("").getKind()).isEqualTo(CidrMatchResult.Kind.NON_IPV4);
        assertThat(m.resolve("  ").getKind()).isEqualTo(CidrMatchResult.Kind.NON_IPV4);
        assertThat(m.resolve(null).getKind()).isEqualTo(CidrMatchResult.Kind.NON_IPV4);

        assertThat(m.resolve("NA").getKind()).isEqualTo(CidrMatchResult.Kind.NON_IPV4);
        assertThat(m.resolve("n/a").getKind()).isEqualTo(CidrMatchResult.Kind.NON_IPV4);
    }

    @Test
    void ipv6AddressTreatedAsNonIpv4() {
        CidrMatcher m = CidrMatcher.fromRules(List.of(new CidrRule("0.0.0.0/0", "all", 0)));
        CidrMatchResult r = m.resolve("2001:db8::1");
        assertThat(r.getKind()).isEqualTo(CidrMatchResult.Kind.NON_IPV4);
    }

    @Test
    void trimsSource() {
        CidrMatcher m = CidrMatcher.fromRules(List.of(new CidrRule("10.0.0.0/8", "ten", 0)));
        assertThat(m.resolve("  10.1.2.3  ").getApplicationName()).isEqualTo("ten");
    }

    @Test
    void bareIpv4InRuleDefaultsToSlash32() {
        CidrRule rule = new CidrRule("10.2.3.4", "solo-host", 0);
        assertThat(rule.getCidrBlock()).isEqualTo("10.2.3.4/32");

        CidrMatcher m = CidrMatcher.fromRules(List.of(rule));
        assertThat(m.resolve("10.2.3.4").getApplicationName()).isEqualTo("solo-host");
        assertThat(m.resolve("10.2.3.5").getKind()).isEqualTo(CidrMatchResult.Kind.UNKNOWN);
    }
}
