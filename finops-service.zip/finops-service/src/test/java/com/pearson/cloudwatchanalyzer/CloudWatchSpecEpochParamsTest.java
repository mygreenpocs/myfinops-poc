package com.pearson.cloudwatchanalyzer;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.Test;

class CloudWatchSpecEpochParamsTest {

    @Test
    void resolvesNullsWhenAllAbsent() {
        Long[] r = CloudWatchSpecEpochParams.resolve(null, null, null, null);
        assertThat(r).containsExactly(null, null);
    }

    @Test
    void prefersSpecNamesOverLegacy() {
        Long[] r = CloudWatchSpecEpochParams.resolve(10L, 20L, null, null);
        assertThat(r).containsExactly(10L, 20L);
    }

    @Test
    void usesLegacyWhenSpecAbsent() {
        Long[] r = CloudWatchSpecEpochParams.resolve(null, null, 100L, 200L);
        assertThat(r).containsExactly(100L, 200L);
    }

    @Test
    void rejectsMixedSpecAndLegacy() {
        assertThatThrownBy(() -> CloudWatchSpecEpochParams.resolve(1L, 2L, 3L, null))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("not both");
    }

    @Test
    void rejectsSingleSpecParam() {
        assertThatThrownBy(() -> CloudWatchSpecEpochParams.resolve(1L, null, null, null))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("startTimeSeconds");
    }

    @Test
    void rejectsSingleLegacyParam() {
        assertThatThrownBy(() -> CloudWatchSpecEpochParams.resolve(null, null, 1L, null))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("startEpochSeconds");
    }
}
