package com.pearson.cloudwatchanalyzer;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Duration;
import org.junit.jupiter.api.Test;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Configuration;

class CloudWatchAnalyzerPropertiesTest {

    private final ApplicationContextRunner runner =
            new ApplicationContextRunner().withUserConfiguration(TestConfig.class);

    @Configuration
    @EnableConfigurationProperties(CloudWatchAnalyzerProperties.class)
    static class TestConfig {}

    @Test
    void bindsSpecKeys() {
        runner.withPropertyValues(
                        "cloudwatchanalyzer.env=my-env",
                        "cloudwatchanalyzer.region=usw2",
                        "cloudwatchanalyzer.cidr-blocks[10.0.0.0/8]=corp",
                        "cloudwatchanalyzer.log-group.services[0]=svc-a",
                        "cloudwatchanalyzer.log-group.services[1]=svc-b")
                .run(
                        ctx -> {
                            assertThat(ctx).hasSingleBean(CloudWatchAnalyzerProperties.class);
                            CloudWatchAnalyzerProperties p = ctx.getBean(CloudWatchAnalyzerProperties.class);
                            assertThat(p.getEnv()).isEqualTo("my-env");
                            assertThat(p.getRegion()).isEqualTo("usw2");
                            assertThat(p.getCidrBlocks()).containsEntry("10.0.0.0/8", "corp");
                            assertThat(p.getLogGroup().getServices()).containsExactly("svc-a", "svc-b");
                        });
    }

    @Test
    void defaultLogGroupServicesMatchSpec() {
        runner.run(
                ctx -> {
                    CloudWatchAnalyzerProperties p = ctx.getBean(CloudWatchAnalyzerProperties.class);
                    assertThat(p.getLogGroup().getServices())
                            .containsExactly("usrsrh", "org", "orgv2", "prfncv2");
                });
    }

    @Test
    void triggerEnabledBinds() {
        runner.withPropertyValues("cloudwatchanalyzer.trigger.enabled=false")
                .run(
                        ctx -> {
                            CloudWatchAnalyzerProperties p = ctx.getBean(CloudWatchAnalyzerProperties.class);
                            assertThat(p.getTrigger().isEnabled()).isFalse();
                        });
    }

    @Test
    void awsEnabledDefaultsTrueAndBinds() {
        runner.run(
                ctx -> {
                    CloudWatchAnalyzerProperties p = ctx.getBean(CloudWatchAnalyzerProperties.class);
                    assertThat(p.getAws().isEnabled()).isTrue();
                    assertThat(p.getAws().isRefreshCredentialsEachRequest()).isTrue();
                });
        runner.withPropertyValues("cloudwatchanalyzer.aws.enabled=false")
                .run(
                        ctx -> {
                            CloudWatchAnalyzerProperties p = ctx.getBean(CloudWatchAnalyzerProperties.class);
                            assertThat(p.getAws().isEnabled()).isFalse();
                        });
    }

    @Test
    void awsRefreshCredentialsEachRequestBinds() {
        runner.withPropertyValues("cloudwatchanalyzer.aws.refresh-credentials-each-request=false")
                .run(
                        ctx -> {
                            CloudWatchAnalyzerProperties p = ctx.getBean(CloudWatchAnalyzerProperties.class);
                            assertThat(p.getAws().isRefreshCredentialsEachRequest()).isFalse();
                        });
    }

    @Test
    void queryWindowAndMaxWindowBindAsDuration() {
        runner.withPropertyValues(
                        "cloudwatchanalyzer.query.window=2d",
                        "cloudwatchanalyzer.query.max-window=90d")
                .run(
                        ctx -> {
                            CloudWatchAnalyzerProperties p = ctx.getBean(CloudWatchAnalyzerProperties.class);
                            assertThat(p.getQuery().getWindow()).isEqualTo(Duration.ofDays(2));
                            assertThat(p.getQuery().getMaxWindow()).isEqualTo(Duration.ofDays(90));
                            assertThat(p.getQuery().getWindowSeconds()).isEqualTo(2L * 24 * 60 * 60);
                        });
    }

    @Test
    void queryWindowSecondsLegacyStillBinds() {
        runner.withPropertyValues("cloudwatchanalyzer.query.window-seconds=120")
                .run(
                        ctx -> {
                            CloudWatchAnalyzerProperties p = ctx.getBean(CloudWatchAnalyzerProperties.class);
                            assertThat(p.getQuery().getWindowSeconds()).isEqualTo(120);
                            assertThat(p.getQuery().getWindow()).isEqualTo(Duration.ofMinutes(2));
                        });
    }
}
