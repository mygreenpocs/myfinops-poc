package com.pearson.cloudwatchanalyzer;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import software.amazon.awssdk.services.cloudwatchlogs.CloudWatchLogsClient;
import software.amazon.awssdk.services.cloudwatchlogs.model.DescribeLogGroupsRequest;
import software.amazon.awssdk.services.cloudwatchlogs.model.DescribeLogGroupsResponse;
import software.amazon.awssdk.services.cloudwatchlogs.model.LogGroup;

@ExtendWith(MockitoExtension.class)
class CloudWatchLogGroupDiscoveryServiceTest {

    @Mock private CloudWatchLogsClient cloudWatchLogsClient;

    private CloudWatchAnalyzerProperties properties;
    private CloudWatchLogGroupDiscoveryService service;

    @BeforeEach
    void setUp() {
        properties = new CloudWatchAnalyzerProperties();
        properties.setEnv("gps-qa");
        properties.setRegion("use1");
        properties.getLogGroup().setServices(List.of("usrsrh", "org"));
        service = new CloudWatchLogGroupDiscoveryService(cloudWatchLogsClient, properties);
    }

    @Test
    void discover_keepsOnlyNamesEndingWithRegionSuffix() {
        when(cloudWatchLogsClient.describeLogGroups(any(DescribeLogGroupsRequest.class)))
                .thenAnswer(
                        inv -> {
                            DescribeLogGroupsRequest req = inv.getArgument(0);
                            String p = req.logGroupNamePrefix();
                            if (p.contains("usrsrh")) {
                                return DescribeLogGroupsResponse.builder()
                                        .logGroups(
                                                LogGroup.builder()
                                                        .logGroupName("/aws/ecs/gps-qa-usrsrh-svc-01-use1")
                                                        .build(),
                                                LogGroup.builder()
                                                        .logGroupName("/aws/ecs/gps-qa-usrsrh-svc-99-other")
                                                        .build())
                                        .build();
                            }
                            if (p.contains("-org-svc-")) {
                                return DescribeLogGroupsResponse.builder()
                                        .logGroups(
                                                LogGroup.builder()
                                                        .logGroupName("/aws/ecs/gps-qa-org-svc-01-use1")
                                                        .build())
                                        .build();
                            }
                            return DescribeLogGroupsResponse.builder().build();
                        });

        List<String> found = service.discoverLogGroups();

        assertThat(found)
                .containsExactly(
                        "/aws/ecs/gps-qa-usrsrh-svc-01-use1",
                        "/aws/ecs/gps-qa-org-svc-01-use1");
    }

    @Test
    void discover_mergesPagination() {
        properties.getLogGroup().setServices(List.of("usrsrh"));
        when(cloudWatchLogsClient.describeLogGroups(any(DescribeLogGroupsRequest.class)))
                .thenAnswer(
                        inv -> {
                            DescribeLogGroupsRequest req = inv.getArgument(0);
                            if (req.nextToken() == null) {
                                return DescribeLogGroupsResponse.builder()
                                        .logGroups(
                                                LogGroup.builder()
                                                        .logGroupName("/aws/ecs/gps-qa-usrsrh-svc-01-use1")
                                                        .build())
                                        .nextToken("page2")
                                        .build();
                            }
                            if ("page2".equals(req.nextToken())) {
                                return DescribeLogGroupsResponse.builder()
                                        .logGroups(
                                                LogGroup.builder()
                                                        .logGroupName("/aws/ecs/gps-qa-usrsrh-svc-02-use1")
                                                        .build())
                                        .build();
                            }
                            return DescribeLogGroupsResponse.builder().build();
                        });

        assertThat(service.discoverLogGroups())
                .containsExactly(
                        "/aws/ecs/gps-qa-usrsrh-svc-01-use1",
                        "/aws/ecs/gps-qa-usrsrh-svc-02-use1");
    }

    @Test
    void discover_returnsEmptyWhenNoServices() {
        properties.getLogGroup().setServices(List.of());
        assertThat(service.discoverLogGroups()).isEmpty();
    }
}
