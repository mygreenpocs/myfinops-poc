package com.pearson.cloudwatchanalyzer.dto;

import static org.assertj.core.api.Assertions.assertThat;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Instant;
import org.junit.jupiter.api.Test;

class AnalyticsAggregateRequestTest {

    @Test
    void from_setsServiceName_andSystemName_separately_fromSource() throws Exception {
        AggregateStatsRow row =
                new AggregateStatsRow(
                        "3.228.0.0/16",
                        "/api/x",
                        "200",
                        3,
                        100L,
                        "610608459180:/aws/ecs/gps-qa-usrsrh-svc-01-use1",
                        "usrsrh");

        AnalyticsAggregateRequest r =
                AnalyticsAggregateRequest.from(row, 1_700_000_000L, 1_700_000_900L, "my-mapped-app");

        assertThat(r.getSource()).isEqualTo("3.228.0.0/16");
        assertThat(r.getLogGroupName()).isEqualTo("610608459180:/aws/ecs/gps-qa-usrsrh-svc-01-use1");
        assertThat(r.getLogGroupService()).isEqualTo("usrsrh");
        assertThat(r.getServiceName()).isEqualTo("usrsrh");
        assertThat(r.getSystemName()).isEqualTo("my-mapped-app");

        String json = new ObjectMapper().findAndRegisterModules().writeValueAsString(r);
        assertThat(json).contains("\"logGroupService\":\"usrsrh\"");
        assertThat(json).contains("\"serviceName\":\"usrsrh\"");
        assertThat(json).contains("\"systemName\":\"my-mapped-app\"");
        assertThat(json).contains("\"source\":\"3.228.0.0/16\"");
        assertThat(json).doesNotContain("|");
        assertThat(json).doesNotContain("verbar");
        assertThat(json).doesNotContain("[\"usrsrh\"]");
    }

    @Test
    void from_unknownIpUsesSystemNameWithoutService() {
        AggregateStatsRow row = new AggregateStatsRow("other", "/api/x", "200", 3, 100L);

        AnalyticsAggregateRequest r = AnalyticsAggregateRequest.from(row, 100L, 200L, "203.0.113.7");

        assertThat(r.getLogGroupName()).isEmpty();
        assertThat(r.getLogGroupService()).isNull();
        assertThat(r.getServiceName()).isNull();
        assertThat(r.getSystemName()).isEqualTo("203.0.113.7");
        assertThat(r.getCidrBlock()).isNull();
        assertThat(r.getWindowStart()).isEqualTo(Instant.ofEpochSecond(100L));
        assertThat(r.getWindowEnd()).isEqualTo(Instant.ofEpochSecond(200L));
    }

    @Test
    void from_withFinopsCidrBlock_serializesUnknownHostRoute() throws Exception {
        AggregateStatsRow row = new AggregateStatsRow("other", "/api/x", "200", 3, 100L);

        AnalyticsAggregateRequest r =
                AnalyticsAggregateRequest.from(row, 100L, 200L, "203.0.113.7", "203.0.113.7/32");

        assertThat(r.getCidrBlock()).isEqualTo("203.0.113.7/32");
        String json = new ObjectMapper().findAndRegisterModules().writeValueAsString(r);
        assertThat(json).contains("\"cidrBlock\":\"203.0.113.7/32\"");
    }

    @Test
    void from_blankPayloadSystemName_omitsSystemName() {
        AggregateStatsRow row =
                new AggregateStatsRow(
                        "10.0.0.1", "/api/x", "200", 3, 100L, "/aws/ecs/x", "usrsrh");

        AnalyticsAggregateRequest r = AnalyticsAggregateRequest.from(row, 1L, 2L, "   ");

        assertThat(r.getServiceName()).isEqualTo("usrsrh");
        assertThat(r.getSystemName()).isNull();
    }
}
