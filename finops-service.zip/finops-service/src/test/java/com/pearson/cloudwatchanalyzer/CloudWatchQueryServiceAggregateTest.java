package com.pearson.cloudwatchanalyzer;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.pearson.cloudwatchanalyzer.dto.AggregateStatsRow;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import software.amazon.awssdk.services.cloudwatchlogs.CloudWatchLogsClient;
import software.amazon.awssdk.services.cloudwatchlogs.model.GetQueryResultsRequest;
import software.amazon.awssdk.services.cloudwatchlogs.model.GetQueryResultsResponse;
import software.amazon.awssdk.services.cloudwatchlogs.model.QueryStatus;
import software.amazon.awssdk.services.cloudwatchlogs.model.ResultField;
import software.amazon.awssdk.services.cloudwatchlogs.model.StartQueryRequest;
import software.amazon.awssdk.services.cloudwatchlogs.model.StartQueryResponse;

@ExtendWith(MockitoExtension.class)
class CloudWatchQueryServiceAggregateTest {

    @Mock private CloudWatchLogsClient cloudWatchLogsClient;

    private CloudWatchQueryService service;

    private final CloudWatchAnalyzerProperties analyzerProperties = new CloudWatchAnalyzerProperties();

    @BeforeEach
    void setUp() {
        analyzerProperties.setEnv("gps-qa");
        service = new CloudWatchQueryService(cloudWatchLogsClient, analyzerProperties);
    }

    @Test
    void executeAggregateTimeLoggerQuery_parsesCompleteResults() {
        when(cloudWatchLogsClient.startQuery(any(StartQueryRequest.class)))
                .thenReturn(StartQueryResponse.builder().queryId("q-1").build());
        when(cloudWatchLogsClient.getQueryResults(any(GetQueryResultsRequest.class)))
                .thenReturn(
                        GetQueryResultsResponse.builder()
                                .status(QueryStatus.COMPLETE)
                                .results(
                                        List.of(
                                                List.of(
                                                        rf("source", "1.1.1.1"),
                                                        rf("patternUrl", "GET:/a"),
                                                        rf("status", "200"),
                                                        rf("count", "5"),
                                                        rf("totalOutputSize", "500"),
                                                        rf("@log", "/aws/ecs/gps-qa-usrsrh-svc-01-use1")),
                                                List.of(
                                                        rf("source", "bad"),
                                                        rf("patternUrl", ""))))
                                .build());

        List<AggregateStatsRow> rows =
                service.executeAggregateTimeLoggerQuery(List.of("/aws/ecs/test"), 1000L, 2000L);

        assertThat(rows).hasSize(1);
        assertThat(rows.get(0).getCount()).isEqualTo(5);
        assertThat(rows.get(0).getTotalOutputSize()).isEqualTo(500);
        assertThat(rows.get(0).getLogGroupName()).isEqualTo("/aws/ecs/gps-qa-usrsrh-svc-01-use1");
        assertThat(rows.get(0).getLogGroupService()).isEqualTo("usrsrh");
    }

    private static ResultField rf(String field, String value) {
        return ResultField.builder().field(field).value(value).build();
    }
}
