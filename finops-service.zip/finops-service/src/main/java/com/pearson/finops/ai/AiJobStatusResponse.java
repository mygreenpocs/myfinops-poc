package com.pearson.finops.ai;

import java.time.Instant;
import java.util.Map;

public record AiJobStatusResponse(
        String requestId,
        String invocationId,
        AiJobStatus status,
        Map<String, Object> response,
        String errorMessage,
        Instant createdAt,
        Instant updatedAt) {}
