package com.pearson.finops.ai;

public record AiJobCreateResponse(String requestId, AiJobStatus status) {}
