package com.pearson.finops.config;

import io.swagger.v3.oas.models.servers.Server;
import java.util.List;
import org.springdoc.core.customizers.OpenApiCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;

/**
 * Springdoc sometimes emits {@code http://localhost:0/...} for "Try it out" when the inferred
 * server port is wrong. A relative server URL forces Swagger UI to call the same host/port used to open the UI.
 */
@Configuration
public class OpenApiServerConfig {

    @Bean
    @Order(Ordered.LOWEST_PRECEDENCE)
    public OpenApiCustomizer relativeServerUrlOpenApiCustomizer() {
        return openApi -> {
            Server root = new Server().url("/").description("Current origin");
            openApi.setServers(List.of(root));
        };
    }
}
