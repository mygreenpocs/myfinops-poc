package com.pearson.finops.auth;

import io.swagger.v3.oas.annotations.Hidden;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Issues a short-lived gateway JWT via Pearson OpenAM for the Config Hub / CloudWatch trigger UI.
 * Credentials stay on the server ({@code FINOPS_OPENAM_*}); the browser only receives {@code token}.
 *
 * <p>Public URL: {@code /api/auth/openam-gateway-token} (server {@code context-path: /api}).
 */
@Hidden
@RestController
@RequestMapping("/auth")
public class OpenAmGatewayTokenController {

    private final OpenAmGatewayTokenService openAmGatewayTokenService;

    public OpenAmGatewayTokenController(OpenAmGatewayTokenService openAmGatewayTokenService) {
        this.openAmGatewayTokenService = openAmGatewayTokenService;
    }

    @GetMapping("/openam-gateway-token")
    public Map<String, String> openAmGatewayToken() {
        String token = openAmGatewayTokenService.fetchGatewayToken();
        return Map.of("token", token);
    }
}
