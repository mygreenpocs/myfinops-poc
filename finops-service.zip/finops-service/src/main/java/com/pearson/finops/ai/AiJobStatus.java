package com.pearson.finops.ai;

public enum AiJobStatus {
    PENDING,
    RUNNING,
    COMPLETED,
    FAILED,
    TIMED_OUT
}
