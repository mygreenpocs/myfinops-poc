package com.pearson.finops.ai;

import jakarta.validation.constraints.NotBlank;

public record AiInvocationRequest(@NotBlank String crewId, @NotBlank String userInput) {}
