package com.pearson.finops;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@ComponentScan({"com.pearson.finops", "com.pearson.cloudwatchanalyzer"})
@EnableMongoRepositories(basePackages = "com.pearson.cloudwatchanalyzer.repository")
@EnableScheduling
public class FinOpsServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(FinOpsServiceApplication.class, args);
    }
}
