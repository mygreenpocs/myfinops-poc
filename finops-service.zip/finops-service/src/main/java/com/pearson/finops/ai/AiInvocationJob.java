package com.pearson.finops.ai;

import java.time.Instant;
import java.util.Map;

public final class AiInvocationJob {

    private final String requestId;
    private final String invocationId;
    private volatile AiJobStatus status;
    private volatile Map<String, Object> response;
    private volatile String errorMessage;
    private final Instant createdAt;
    private volatile Instant updatedAt;

    public AiInvocationJob(String requestId, String invocationId) {
        this.requestId = requestId;
        this.invocationId = invocationId;
        this.status = AiJobStatus.PENDING;
        this.createdAt = Instant.now();
        this.updatedAt = this.createdAt;
    }

    public String getRequestId() {
        return requestId;
    }

    public String getInvocationId() {
        return invocationId;
    }

    public AiJobStatus getStatus() {
        return status;
    }

    public Map<String, Object> getResponse() {
        return response;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public boolean isTerminal() {
        return status == AiJobStatus.COMPLETED
                || status == AiJobStatus.FAILED
                || status == AiJobStatus.TIMED_OUT;
    }

    public void markRunning() {
        if (status == AiJobStatus.PENDING) {
            status = AiJobStatus.RUNNING;
            touch();
        }
    }

    public void updateProgress(AiJobStatus nextStatus, Map<String, Object> latestResponse, String error) {
        status = nextStatus;
        response = latestResponse;
        errorMessage = error;
        touch();
    }

    private void touch() {
        updatedAt = Instant.now();
    }
}
