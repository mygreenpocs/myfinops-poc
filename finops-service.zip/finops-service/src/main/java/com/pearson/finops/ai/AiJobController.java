package com.pearson.finops.ai;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/ai/jobs")
@Tag(name = "AI Jobs", description = "Server-side AI polling with in-memory status for UI.")
public class AiJobController {

    private final AiInvocationJobService jobService;

    public AiJobController(AiInvocationJobService jobService) {
        this.jobService = jobService;
    }

    @PostMapping
    @Operation(summary = "Start an AI invocation; backend polls upstream until complete or timeout")
    public AiJobCreateResponse startJob(@Valid @RequestBody AiInvocationRequest request) {
        return jobService.startJob(request);
    }

    @GetMapping("/{requestId}")
    @Operation(summary = "Poll job status from in-memory store; terminal jobs are removed after read")
    public AiJobStatusResponse getJobStatus(@PathVariable String requestId) {
        return jobService.getJobStatus(requestId);
    }
}
