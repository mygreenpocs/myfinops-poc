package com.pearson.finops.ai;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties(AiProperties.class)
public class AiConfiguration {

    @Bean(destroyMethod = "shutdown")
    ExecutorService aiJobExecutor() {
        return Executors.newCachedThreadPool();
    }
}
