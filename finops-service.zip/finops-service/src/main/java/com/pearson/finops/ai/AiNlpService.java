package com.pearson.finops.ai;

import com.pearson.finops.auth.OpenAmGatewayTokenService;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class AiNlpService {

    private static final Logger LOGGER = LoggerFactory.getLogger(AiNlpService.class);
    private static final String FILTER_TASK = "Extract final filter JSON (single-step)";

    private final AiService aiService;
    private final AiProperties aiProperties;
    private final OpenAmGatewayTokenService openAmGatewayTokenService;

    public AiNlpService(
            AiService aiService,
            AiProperties aiProperties,
            OpenAmGatewayTokenService openAmGatewayTokenService) {
        this.aiService = aiService;
        this.aiProperties = aiProperties;
        this.openAmGatewayTokenService = openAmGatewayTokenService;
    }

    public String processNlpQuery(String userInput) {
        String ssoToken = "";
        if (aiProperties.isUseOpenAmSso()) {
            try {
                ssoToken = openAmGatewayTokenService.fetchGatewayToken();
            } catch (ResponseStatusException ex) {
                LOGGER.warn("Failed to fetch OpenAM token, falling back to static pearsonSsoSession: {}", ex.getReason());
                ssoToken = aiProperties.getPearsonSsoSession();
            }
        } else {
            ssoToken = aiProperties.getPearsonSsoSession();
        }
        String apiKey = aiProperties.getApiKey();
        String crewId = aiProperties.getCrewId();

        AiInvocationRequest request = new AiInvocationRequest(crewId, userInput);
        Map<String, Object> createRes = aiService.createInvocation(request, ssoToken, apiKey);
        
        Map<String, Object> data = getMap(createRes, "data");
        if (data == null || !data.containsKey("invocation_id")) {
            throw new ResponseStatusException(HttpStatus.BAD_GATEWAY, "Agent start: missing invocation_id in response");
        }
        
        String invocationId = (String) data.get("invocation_id");
        LOGGER.info("Started AI invocation id: {}", invocationId);

        long maxDuration = aiProperties.getPolling().getMaxDurationMs();
        long interval = aiProperties.getPolling().getIntervalMs();
        long deadline = System.currentTimeMillis() + maxDuration;

        while (System.currentTimeMillis() < deadline) {
            Map<String, Object> pollRes = aiService.getInvocation(invocationId, ssoToken, apiKey);
            Map<String, Object> pollData = getMap(pollRes, "data");

            if (isInvocationFailed(pollData)) {
                throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Agent invocation failed.");
            }

            String found = findCompletedFilterOutputJson(pollData);
            if (found != null) {
                return found;
            }

            String status = readInvocationStatus(pollData);
            if (status != null) {
                String lower = status.toLowerCase();
                if (lower.equals("completed") || lower.equals("success") || lower.equals("done")) {
                    // Completed but no filter JSON found
                    throw new ResponseStatusException(HttpStatus.OK, "Agent completed without returning filter output.");
                }
            }

            try {
                Thread.sleep(interval);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE, "Polling interrupted");
            }
        }

        throw new ResponseStatusException(HttpStatus.REQUEST_TIMEOUT, "Timed out waiting for response from agent.");
    }

    private boolean isInvocationFailed(Map<String, Object> data) {
        String status = readInvocationStatus(data);
        if (status == null) {
            return false;
        }
        String lower = status.toLowerCase();
        return lower.contains("fail") || lower.equals("error");
    }

    private String readInvocationStatus(Map<String, Object> data) {
        if (data == null) {
            return null;
        }
        Object status = data.get("invocation_status");
        return status instanceof String ? (String) status : null;
    }

    @SuppressWarnings("unchecked")
    private String findCompletedFilterOutputJson(Map<String, Object> data) {
        if (data == null) {
            return null;
        }
        Map<String, Object> progressData = getMap(data, "progress_data");
        if (progressData == null) {
            return null;
        }
        Object timelineObj = progressData.get("events_timeline");
        if (!(timelineObj instanceof List)) {
            return null;
        }
        
        List<?> timeline = (List<?>) timelineObj;
        for (int i = timeline.size() - 1; i >= 0; i--) {
            Object eventObj = timeline.get(i);
            if (!(eventObj instanceof Map)) {
                continue;
            }
            Map<String, Object> event = (Map<String, Object>) eventObj;
            if (!"task_completed".equals(event.get("event_type"))) {
                continue;
            }
            if (!FILTER_TASK.equals(event.get("task_name"))) {
                continue;
            }
            Object out = event.get("output");
            if (out instanceof String) {
                String strOut = ((String) out).trim();
                if (!strOut.isEmpty()) {
                    return strOut;
                }
            } else if (out instanceof Map) {
                try {
                    return new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(out);
                } catch (Exception e) {
                    return null;
                }
            }
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> getMap(Map<String, Object> map, String key) {
        if (map == null) return null;
        Object val = map.get(key);
        return val instanceof Map ? (Map<String, Object>) val : null;
    }
}
