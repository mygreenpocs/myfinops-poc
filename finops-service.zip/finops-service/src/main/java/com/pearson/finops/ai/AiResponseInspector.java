package com.pearson.finops.ai;

import java.util.List;
import java.util.Map;

final class AiResponseInspector {

    private static final String FILTER_TASK = "Extract final filter JSON (single-step)";

    private AiResponseInspector() {}

    static String extractInvocationId(Map<String, Object> body) {
        if (body == null || body.isEmpty()) {
            return null;
        }
        Object data = body.get("data");
        if (data instanceof Map<?, ?> dataMap) {
            Object id = dataMap.get("invocation_id");
            if (id instanceof String s && !s.isBlank()) {
                return s.trim();
            }
        }
        Object id = body.get("invocation_id");
        if (id instanceof String s && !s.isBlank()) {
            return s.trim();
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    static Map<String, Object> unwrapData(Map<String, Object> body) {
        if (body == null) {
            return Map.of();
        }
        Object data = body.get("data");
        if (data instanceof Map<?, ?> dataMap) {
            return (Map<String, Object>) dataMap;
        }
        return body;
    }

    static AiJobStatus deriveStatus(Map<String, Object> data) {
        if (data == null || data.isEmpty()) {
            return AiJobStatus.RUNNING;
        }
        if (isInvocationFailed(data)) {
            return AiJobStatus.FAILED;
        }
        if (findCompletedFilterOutputJson(data) != null) {
            return AiJobStatus.COMPLETED;
        }
        String status = readInvocationStatus(data);
        if (status != null) {
            String u = status.toLowerCase();
            if (u.contains("fail") || "error".equals(u)) {
                return AiJobStatus.FAILED;
            }
            if (u.contains("complete") || u.contains("success") || u.contains("succeeded")) {
                return AiJobStatus.COMPLETED;
            }
        }
        return AiJobStatus.RUNNING;
    }

    static String findCompletedFilterOutputJson(Map<String, Object> data) {
        List<Map<String, Object>> timeline = readTimeline(data);
        for (int i = timeline.size() - 1; i >= 0; i--) {
            Map<String, Object> e = timeline.get(i);
            if (!"task_completed".equals(e.get("event_type"))) {
                continue;
            }
            if (!FILTER_TASK.equals(e.get("task_name"))) {
                continue;
            }
            Object out = e.get("output");
            if (out instanceof String s && !s.isBlank()) {
                return s.trim();
            }
        }
        return null;
    }

    private static boolean isInvocationFailed(Map<String, Object> data) {
        String s = readInvocationStatus(data);
        if (s == null) {
            return false;
        }
        String u = s.toLowerCase();
        return u.contains("fail") || "error".equals(u);
    }

    private static String readInvocationStatus(Map<String, Object> data) {
        Object v = data.get("invocation_status");
        return v instanceof String s ? s : null;
    }

    @SuppressWarnings("unchecked")
    private static List<Map<String, Object>> readTimeline(Map<String, Object> data) {
        Object progress = data.get("progress_data");
        if (!(progress instanceof Map<?, ?> progressMap)) {
            return List.of();
        }
        Object timeline = progressMap.get("events_timeline");
        if (!(timeline instanceof List<?> list)) {
            return List.of();
        }
        return list.stream()
                .filter(Map.class::isInstance)
                .map(x -> (Map<String, Object>) x)
                .toList();
    }
}
