package com.pearson.finops.ai;

import com.pearson.finops.auth.FinopsOpenAmProperties;
import com.pearson.finops.auth.OpenAmGatewayTokenService;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.server.ResponseStatusException;

@Component
public class AiCredentialsResolver {

    private final AiProperties aiProperties;
    private final FinopsOpenAmProperties openAmProperties;
    private final OpenAmGatewayTokenService openAmGatewayTokenService;

    public AiCredentialsResolver(
            AiProperties aiProperties,
            FinopsOpenAmProperties openAmProperties,
            OpenAmGatewayTokenService openAmGatewayTokenService) {
        this.aiProperties = aiProperties;
        this.openAmProperties = openAmProperties;
        this.openAmGatewayTokenService = openAmGatewayTokenService;
    }

    public record AiCredentials(String pearsonSsoSession, String apiKey) {}

    public AiCredentials resolve() {
        String apiKey = aiProperties.getApiKey();
        if (!StringUtils.hasText(apiKey)) {
            throw new ResponseStatusException(
                    HttpStatus.SERVICE_UNAVAILABLE,
                    "AI api-key is not configured (set AI_API_KEY)");
        }

        String sso = resolveSsoSession();
        if (!StringUtils.hasText(sso)) {
            throw new ResponseStatusException(
                    HttpStatus.SERVICE_UNAVAILABLE,
                    "AI PearsonExtSSOSession is not configured (set AI_PEARSON_SSO_SESSION or enable OpenAM with finops.openam.enabled=true)");
        }
        return new AiCredentials(sso.trim(), apiKey.trim());
    }

    private String resolveSsoSession() {
        if (StringUtils.hasText(aiProperties.getPearsonSsoSession())) {
            return aiProperties.getPearsonSsoSession().trim();
        }
        if (aiProperties.isUseOpenAmSso() && openAmProperties.isEnabled()) {
            return openAmGatewayTokenService.fetchGatewayToken();
        }
        return "";
    }
}
