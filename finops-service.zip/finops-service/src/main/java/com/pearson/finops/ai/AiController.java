package com.pearson.finops.ai;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/ai")
@Tag(name = "AI", description = "Proxy to Pearson AI agents.")
public class AiController {

    private final AiService aiService;
    private final AiNlpService aiNlpService;

    public AiController(AiService aiService, AiNlpService aiNlpService) {
        this.aiService = aiService;
        this.aiNlpService = aiNlpService;
    }

    @PostMapping("/agents/invocations")
    @Operation(summary = "Create a new AI agent invocation")
    public Object createInvocation(
            @Valid @RequestBody AiInvocationRequest request,
            @RequestHeader("PearsonExtSSOSession") String ssoToken,
            @RequestHeader("x-api-key") String apiKey) {
        return aiService.createInvocation(request, ssoToken, apiKey);
    }

    @GetMapping("/agents/invocations/{invocationId}")
    @Operation(summary = "Fetch AI agent invocation status")
    public Object getInvocation(
            @PathVariable String invocationId,
            @RequestHeader("PearsonExtSSOSession") String ssoToken,
            @RequestHeader("x-api-key") String apiKey) {
        return aiService.getInvocation(invocationId, ssoToken, apiKey);
    }
    @PostMapping("/nlp/filter")
    @Operation(summary = "Execute NLP Assistant query synchronously")
    public Object processNlpFilter(@Valid @RequestBody AiNlpRequest request) {
        return aiNlpService.processNlpQuery(request.userInput());
    }
}
