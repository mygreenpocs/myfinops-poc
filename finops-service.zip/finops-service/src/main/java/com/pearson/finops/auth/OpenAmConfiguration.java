package com.pearson.finops.auth;

import java.time.Duration;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestClient;

@Configuration
@EnableConfigurationProperties(FinopsOpenAmProperties.class)
public class OpenAmConfiguration {

    @Bean
    @Qualifier("openAmRestClient")
    RestClient openAmRestClient(FinopsOpenAmProperties props) {
        SimpleClientHttpRequestFactory rf = new SimpleClientHttpRequestFactory();
        rf.setConnectTimeout(Duration.ofMillis(Math.max(1000, props.getConnectTimeoutMs())));
        rf.setReadTimeout(Duration.ofMillis(Math.max(1000, props.getReadTimeoutMs())));
        return RestClient.builder().requestFactory(rf).build();
    }
}
