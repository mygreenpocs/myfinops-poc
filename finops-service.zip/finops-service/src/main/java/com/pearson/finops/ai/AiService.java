package com.pearson.finops.ai;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import org.slf4j.LoggerFactory;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.util.UriUtils;

@Service
public class AiService {

    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;
    private final AiProperties aiProperties;

    public AiService(RestTemplateBuilder restTemplateBuilder, ObjectMapper objectMapper, AiProperties aiProperties) {
        this.restTemplate = restTemplateBuilder.build();
        this.objectMapper = objectMapper;
        this.aiProperties = aiProperties;
    }

    public Map<String, Object> createInvocation(AiInvocationRequest request, String ssoToken, String apiKey) {
        String crewId = UriUtils.encodeQueryParam(request.crewId(), StandardCharsets.UTF_8);
        String url = String.format("%s?crew_id=%s", createInvocationBasePath(), crewId);
        Map<String, Object> payload = Map.of("inputs", Map.of("user_input", request.userInput()));
        return exchange(url, HttpMethod.POST, payload, ssoToken, apiKey);
    }

    public Map<String, Object> getInvocation(String invocationId, String ssoToken, String apiKey) {
        String safeId = UriUtils.encodePathSegment(invocationId, StandardCharsets.UTF_8);
        String url = String.format("%s/%s", invocationBasePath(), safeId);
        return exchange(url, HttpMethod.GET, null, ssoToken, apiKey);
    }

    private String baseUrl() {
        return aiProperties.getBaseUrl().replaceAll("/+$", "");
    }

    private String createInvocationBasePath() {
        return aiProperties.getProvider() == AiProperties.Provider.AGENTOPS
                ? baseUrl() + "/invocations"
                : baseUrl() + "/agents/invocations";
    }

    private String invocationBasePath() {
        return aiProperties.getProvider() == AiProperties.Provider.AGENTOPS
                ? baseUrl() + "/invocations"
                : baseUrl() + "/agents/invocations";
    }

    private Map<String, Object> exchange(
            String url, HttpMethod method, Object payload, String ssoToken, String apiKey) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(java.util.List.of(MediaType.APPLICATION_JSON));
        headers.set("PearsonExtSSOSession", ssoToken);
        headers.set("x-api-key", apiKey);
        HttpEntity<Object> entity = new HttpEntity<>(payload, headers);
        try {
            ResponseEntity<String> response = restTemplate.exchange(url, method, entity, String.class);
            return parseJson(response.getBody());
        } catch (HttpStatusCodeException ex) {
            throw new ResponseStatusException(ex.getStatusCode(), ex.getResponseBodyAsString(), ex);
        }
    }

    private Map<String, Object> parseJson(String body) {
        if (body == null || body.isBlank()) {
            return Map.of();
        }
        try {
            return objectMapper.readValue(body, new TypeReference<>() {});
        } catch (Exception ex) {
            LoggerFactory.getLogger(AiService.class).error("Failed to parse AI response. Body was: {}", body);
            throw new IllegalStateException("Failed to parse AI response. Body: " + body, ex);
        }
    }
}
