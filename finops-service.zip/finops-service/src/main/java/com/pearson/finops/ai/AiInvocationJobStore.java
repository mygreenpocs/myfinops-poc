package com.pearson.finops.ai;

import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.stereotype.Component;

@Component
public class AiInvocationJobStore {

    private final ConcurrentHashMap<String, AiInvocationJob> jobs = new ConcurrentHashMap<>();

    public void put(AiInvocationJob job) {
        jobs.put(job.getRequestId(), job);
    }

    public Optional<AiInvocationJob> find(String requestId) {
        return Optional.ofNullable(jobs.get(requestId));
    }

    public Optional<AiInvocationJob> remove(String requestId) {
        return Optional.ofNullable(jobs.remove(requestId));
    }
}
