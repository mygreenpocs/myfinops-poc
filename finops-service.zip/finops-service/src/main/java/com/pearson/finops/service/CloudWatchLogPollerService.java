package com.pearson.finops.service;

import com.pearson.cloudwatchanalyzer.CloudWatchAnalyzerProperties;
import com.pearson.cloudwatchanalyzer.CloudWatchLogGroupDiscoveryService;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.cloudwatchlogs.CloudWatchLogsClient;
import software.amazon.awssdk.services.cloudwatchlogs.model.FilterLogEventsRequest;
import software.amazon.awssdk.services.cloudwatchlogs.model.FilterLogEventsResponse;
import software.amazon.awssdk.services.cloudwatchlogs.model.FilteredLogEvent;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
public class CloudWatchLogPollerService {

    private final CloudWatchLogsClient logsClient;
    private final CloudWatchLogGroupDiscoveryService discoveryService;
    
    // Track the last time we fetched logs to avoid overlaps or missed logs
    private long lastFetchedTime = Instant.now().minus(1, ChronoUnit.MINUTES).toEpochMilli();

    public CloudWatchLogPollerService(CloudWatchAnalyzerProperties properties, CloudWatchLogGroupDiscoveryService discoveryService) {
        this.discoveryService = discoveryService;
        
        String regionStr = properties.getAws().getRegion();
        if (regionStr == null || regionStr.isBlank()) {
            regionStr = "ap-south-1";
        }
        
        this.logsClient = CloudWatchLogsClient.builder()
                .region(Region.of(regionStr)) 
                .build();
    }

    // This method runs every 10 seconds (10000 ms) - to fetch logs quickly for the UI
    @Scheduled(fixedRate = 10000) 
    public void fetchLogsFromCloudWatch() {
        List<String> logGroups = discoveryService.discoverLogGroups();
        if (logGroups.isEmpty()) {
            System.out.println("No log groups discovered for polling.");
            return;
        }

        // Fetching logs from the last fetched time up to the current time
        long endTime = Instant.now().toEpochMilli();
        long startTime = lastFetchedTime;
        lastFetchedTime = endTime; // Saving the current time for the next run

        for (String logGroupName : logGroups) {
            System.out.println("Fetching logs from CloudWatch for group: " + logGroupName);

            try {
                FilterLogEventsRequest request = FilterLogEventsRequest.builder()
                        .logGroupName(logGroupName)
                        .startTime(startTime)
                        .endTime(endTime)
                        // .filterPattern("ERROR") // Uncomment this if you only want logs containing "ERROR"
                        .build();

                FilterLogEventsResponse response = logsClient.filterLogEvents(request);

                if (response.events().isEmpty()) {
                    System.out.println("No new logs found in the last run for group " + logGroupName + ".");
                    continue;
                }

                for (FilteredLogEvent event : response.events()) {
                    // You can write the logic to save to your FinOps Database here
                    // For now, we are printing to the Console
                    System.out.println("-------------------------------------------------");
                    System.out.println("Log Stream: " + event.logStreamName());
                    System.out.println("Timestamp: " + Instant.ofEpochMilli(event.timestamp()));
                    System.out.println("Log Message: " + event.message());
                }
                System.out.println("-------------------------------------------------");

            } catch (Exception e) {
                System.err.println("Error fetching logs for group " + logGroupName + ": " + e.getMessage());
            }
        }
    }
}
