package com.pearson.finops.service;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.cloudwatchlogs.CloudWatchLogsClient;
import software.amazon.awssdk.services.cloudwatchlogs.model.FilterLogEventsRequest;
import software.amazon.awssdk.services.cloudwatchlogs.model.FilterLogEventsResponse;
import software.amazon.awssdk.services.cloudwatchlogs.model.FilteredLogEvent;

import java.time.Instant;
import java.time.temporal.ChronoUnit;

@Service
public class CloudWatchLogPollerService {

    private final CloudWatchLogsClient logsClient;
    
    // Same Log Group Name as in the image
    private final String logGroupName = "ec2-app-log"; 
    
    // Track the last time we fetched logs to avoid overlaps or missed logs
    private long lastFetchedTime = Instant.now().minus(1, ChronoUnit.MINUTES).toEpochMilli();

    public CloudWatchLogPollerService() {
        // Change to your AWS Region (e.g., AP_SOUTH_1 for Mumbai, US_EAST_1 for N. Virginia)
        this.logsClient = CloudWatchLogsClient.builder()
                .region(Region.US_EAST_1) 
                .build();
    }

    // This method runs every 10 seconds (10000 ms) - to fetch logs quickly for the UI
    @Scheduled(fixedRate = 10000) 
    public void fetchLogsFromCloudWatch() {
        System.out.println("Fetching logs from CloudWatch for group: " + logGroupName);

        // Fetching logs from the last fetched time up to the current time
        long endTime = Instant.now().toEpochMilli();
        long startTime = lastFetchedTime;
        lastFetchedTime = endTime; // Saving the current time for the next run

        try {
            FilterLogEventsRequest request = FilterLogEventsRequest.builder()
                    .logGroupName(logGroupName)
                    .startTime(startTime)
                    .endTime(endTime)
                    // .filterPattern("ERROR") // Uncomment this if you only want logs containing "ERROR"
                    .build();

            FilterLogEventsResponse response = logsClient.filterLogEvents(request);

            if (response.events().isEmpty()) {
                System.out.println("No new logs found in the last 5 minutes.");
                return;
            }

            for (FilteredLogEvent event : response.events()) {
                // You can write the logic to save to your FinOps Database here
                // For now, we are printing to the Console
                System.out.println("-------------------------------------------------");
                System.out.println("Log Stream: " + event.logStreamName());
                System.out.println("Timestamp: " + Instant.ofEpochMilli(event.timestamp()));
                System.out.println("Log Message: " + event.message());
            }
            System.out.println("-------------------------------------------------");

        } catch (Exception e) {
            System.err.println("Error fetching logs: " + e.getMessage());
        }
    }
}
