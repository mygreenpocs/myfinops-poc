package com.pearson.finops.service;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.cloudwatchlogs.CloudWatchLogsClient;
import software.amazon.awssdk.services.cloudwatchlogs.model.FilterLogEventsRequest;
import software.amazon.awssdk.services.cloudwatchlogs.model.FilterLogEventsResponse;
import software.amazon.awssdk.services.cloudwatchlogs.model.FilteredLogEvent;

import java.time.Instant;
import java.time.temporal.ChronoUnit;

@Service
public class CloudWatchLogPollerService {

    private final CloudWatchLogsClient logsClient;
    
    // Image-ல இருக்கிற அதே Log Group Name
    private final String logGroupName = "ec2-app-log"; 
    
    // Track the last time we fetched logs to avoid overlaps or missed logs
    private long lastFetchedTime = Instant.now().minus(1, ChronoUnit.MINUTES).toEpochMilli();

    public CloudWatchLogPollerService() {
        // உங்க AWS Region-ஐ மாத்திக்கோங்க (எ.கா: AP_SOUTH_1 for Mumbai, US_EAST_1 for N. Virginia)
        this.logsClient = CloudWatchLogsClient.builder()
                .region(Region.US_EAST_1) 
                .build();
    }

    // ஒவ்வொரு 10 செகண்டுக்கும் (10000 ms) இந்த method run ஆகும் - UI-க்கு fast-ஆக logs வர
    @Scheduled(fixedRate = 10000) 
    public void fetchLogsFromCloudWatch() {
        System.out.println("Fetching logs from CloudWatch for group: " + logGroupName);

        // முந்தைய முறை fetch செய்த time-ல் இருந்து இப்போதைய time வரைக்கும் logs எடுக்கிறோம்
        long endTime = Instant.now().toEpochMilli();
        long startTime = lastFetchedTime;
        lastFetchedTime = endTime; // அடுத்த முறைக்காக இப்போதைய time-ஐ save செய்கிறோம்

        try {
            FilterLogEventsRequest request = FilterLogEventsRequest.builder()
                    .logGroupName(logGroupName)
                    .startTime(startTime)
                    .endTime(endTime)
                    // .filterPattern("ERROR") // "ERROR" அப்படின்னு வர logs மட்டும் வேணும்னா இத uncomment பண்ணிக்கலாம்
                    .build();

            FilterLogEventsResponse response = logsClient.filterLogEvents(request);

            if (response.events().isEmpty()) {
                System.out.println("No new logs found in the last 5 minutes.");
                return;
            }

            for (FilteredLogEvent event : response.events()) {
                // இங்க உங்க FinOps Database-ல save பண்ற logic-ஐ எழுதலாம்
                // இப்போதைக்கு Console-ல Print பண்றோம்
                System.out.println("-------------------------------------------------");
                System.out.println("Log Stream: " + event.logStreamName());
                System.out.println("Timestamp: " + Instant.ofEpochMilli(event.timestamp()));
                System.out.println("Log Message: " + event.message());
            }
            System.out.println("-------------------------------------------------");

        } catch (Exception e) {
            System.err.println("Error fetching logs: " + e.getMessage());
        }
    }
}
