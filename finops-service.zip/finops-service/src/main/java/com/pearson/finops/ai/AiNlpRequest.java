package com.pearson.finops.ai;

import jakarta.validation.constraints.NotBlank;

public record AiNlpRequest(@NotBlank String userInput) {}
