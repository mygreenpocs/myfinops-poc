package com.pearson.finops.ai;

import com.pearson.finops.ai.AiCredentialsResolver.AiCredentials;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class AiInvocationJobService {

    private final AiService aiService;
    private final AiProperties aiProperties;
    private final AiCredentialsResolver credentialsResolver;
    private final AiInvocationJobStore jobStore;
    private final ExecutorService aiJobExecutor;

    public AiInvocationJobService(
            AiService aiService,
            AiProperties aiProperties,
            AiCredentialsResolver credentialsResolver,
            AiInvocationJobStore jobStore,
            ExecutorService aiJobExecutor) {
        this.aiService = aiService;
        this.aiProperties = aiProperties;
        this.credentialsResolver = credentialsResolver;
        this.jobStore = jobStore;
        this.aiJobExecutor = aiJobExecutor;
    }

    public AiJobCreateResponse startJob(AiInvocationRequest request) {
        AiCredentials credentials = credentialsResolver.resolve();
        Map<String, Object> created =
                aiService.createInvocation(request, credentials.pearsonSsoSession(), credentials.apiKey());
        String invocationId = AiResponseInspector.extractInvocationId(created);
        if (invocationId == null || invocationId.isBlank()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_GATEWAY, "AI create response missing invocation_id");
        }

        String requestId = UUID.randomUUID().toString();
        AiInvocationJob job = new AiInvocationJob(requestId, invocationId);
        jobStore.put(job);
        aiJobExecutor.submit(() -> pollUntilDone(job, credentials));
        return new AiJobCreateResponse(requestId, job.getStatus());
    }

    /**
     * Returns the latest snapshot for the UI. Terminal jobs are removed from the in-memory store after this call
     * so completed work does not accumulate.
     */
    public AiJobStatusResponse getJobStatus(String requestId) {
        AiInvocationJob job =
                jobStore.find(requestId).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Unknown request id"));
        AiJobStatusResponse snapshot = toResponse(job);
        if (job.isTerminal()) {
            jobStore.remove(requestId);
        }
        return snapshot;
    }

    private void pollUntilDone(AiInvocationJob job, AiCredentials credentials) {
        job.markRunning();
        long intervalMs = Math.max(250, aiProperties.getPolling().getIntervalMs());
        long maxDurationMs = Math.max(intervalMs, aiProperties.getPolling().getMaxDurationMs());
        long deadline = System.currentTimeMillis() + maxDurationMs;

        while (System.currentTimeMillis() < deadline) {
            try {
                Map<String, Object> raw =
                        aiService.getInvocation(job.getInvocationId(), credentials.pearsonSsoSession(), credentials.apiKey());
                Map<String, Object> data = AiResponseInspector.unwrapData(raw);
                AiJobStatus derived = AiResponseInspector.deriveStatus(data);
                String error = derived == AiJobStatus.FAILED ? "Agent invocation failed." : null;
                job.updateProgress(derived, data, error);
                if (job.isTerminal()) {
                    return;
                }
            } catch (Exception ex) {
                job.updateProgress(AiJobStatus.FAILED, job.getResponse(), ex.getMessage());
                return;
            }
            sleep(intervalMs);
        }
        job.updateProgress(AiJobStatus.TIMED_OUT, job.getResponse(), "Timed out waiting for AI invocation.");
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
        }
    }

    private static AiJobStatusResponse toResponse(AiInvocationJob job) {
        return new AiJobStatusResponse(
                job.getRequestId(),
                job.getInvocationId(),
                job.getStatus(),
                job.getResponse(),
                job.getErrorMessage(),
                job.getCreatedAt(),
                job.getUpdatedAt());
    }
}
