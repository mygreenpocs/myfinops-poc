package com.pearson.finops.auth;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "finops.openam")
public class FinopsOpenAmProperties {

    /**
     * When false, {@code /auth/openam-gateway-token} responds with 503 (UI falls back to manual JWT if configured).
     */
    private boolean enabled = false;

    /**
     * Pearson OpenAM authenticate endpoint (including {@code authIndexType} / {@code authIndexValue} query params).
     */
    private String authenticateUrl =
            "https://iam.pearson.com/auth/json/realms/root/realms/pearson/authenticate"
                    + "?authIndexType=service&authIndexValue=ldapService";

    /** Service account user name — use env {@code FINOPS_OPENAM_USERNAME}, never commit secrets. */
    private String username = "";

    /** Service account password — use env {@code FINOPS_OPENAM_PASSWORD}, never commit secrets. */
    private String password = "";

    private int connectTimeoutMs = 15000;
    private int readTimeoutMs = 60000;

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getAuthenticateUrl() {
        return authenticateUrl;
    }

    public void setAuthenticateUrl(String authenticateUrl) {
        this.authenticateUrl = authenticateUrl;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getConnectTimeoutMs() {
        return connectTimeoutMs;
    }

    public void setConnectTimeoutMs(int connectTimeoutMs) {
        this.connectTimeoutMs = connectTimeoutMs;
    }

    public int getReadTimeoutMs() {
        return readTimeoutMs;
    }

    public void setReadTimeoutMs(int readTimeoutMs) {
        this.readTimeoutMs = readTimeoutMs;
    }

    public boolean hasCredentials() {
        return username != null && !username.isBlank() && password != null && !password.isBlank();
    }
}
