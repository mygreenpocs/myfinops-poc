package com.pearson.finops.auth;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.server.ResponseStatusException;

@Service
public class OpenAmGatewayTokenService {

    private final FinopsOpenAmProperties props;
    private final RestClient openAmRestClient;
    private final ObjectMapper objectMapper;

    public OpenAmGatewayTokenService(
            FinopsOpenAmProperties props,
            @Qualifier("openAmRestClient") RestClient openAmRestClient,
            ObjectMapper objectMapper) {
        this.props = props;
        this.openAmRestClient = openAmRestClient;
        this.objectMapper = objectMapper;
    }

    /**
     * Calls OpenAM {@code /authenticate} with JSON body and {@code X-OpenAM-Username} /
     * {@code X-OpenAM-Password}, returning {@code tokenId} for use as config-service gateway JWT.
     */
    public String fetchGatewayToken() {
        if (!props.isEnabled()) {
            throw new ResponseStatusException(
                    HttpStatus.SERVICE_UNAVAILABLE, "OpenAM token endpoint is disabled (finops.openam.enabled=false)");
        }
        if (!props.hasCredentials()) {
            throw new ResponseStatusException(
                    HttpStatus.SERVICE_UNAVAILABLE,
                    "OpenAM credentials are not configured (set FINOPS_OPENAM_USERNAME and FINOPS_OPENAM_PASSWORD)");
        }
        if (!StringUtils.hasText(props.getAuthenticateUrl())) {
            throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE, "finops.openam.authenticate-url is empty");
        }

        final ResponseEntity<String> entity;
        try {
            entity = openAmRestClient
                    .post()
                    .uri(props.getAuthenticateUrl())
                    .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                    .header("X-OpenAM-Username", props.getUsername().trim())
                    .header("X-OpenAM-Password", props.getPassword())
                    .body("{}")
                    .retrieve()
                    .toEntity(String.class);
        } catch (RestClientResponseException e) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_GATEWAY,
                    "OpenAM authenticate HTTP " + e.getStatusCode().value() + ": " + abbreviate(e.getResponseBodyAsString()));
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.BAD_GATEWAY, "OpenAM authenticate failed: " + e.getMessage());
        }

        String rawBody = entity.getBody();
        if (rawBody == null || rawBody.isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_GATEWAY, "OpenAM returned an empty body");
        }

        try {
            JsonNode root = objectMapper.readTree(rawBody);
            if (root.has("tokenId") && root.get("tokenId").isTextual()) {
                String tokenId = root.get("tokenId").asText();
                if (StringUtils.hasText(tokenId)) {
                    return tokenId.trim();
                }
            }
            if (root.has("callbacks")) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_GATEWAY,
                        "OpenAM returned an authentication callback chain; expected direct tokenId (ldapService headers flow)");
            }
            throw new ResponseStatusException(HttpStatus.BAD_GATEWAY, "OpenAM JSON response missing tokenId");
        } catch (ResponseStatusException e) {
            throw e;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.BAD_GATEWAY, "Could not parse OpenAM JSON: " + e.getMessage());
        }
    }

    private static String abbreviate(String s) {
        if (s == null) {
            return "";
        }
        String t = s.strip();
        if (t.length() <= 240) {
            return t;
        }
        return t.substring(0, 240) + "…";
    }
}
