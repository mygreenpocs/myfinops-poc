package com.pearson.finops.ai;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "ai")
public class AiProperties {

    public enum Provider {
        PACE,
        AGENTOPS
    }

    private Provider provider = Provider.AGENTOPS;
    private String baseUrl = "https://agentops.pearson.com/axis/api";
    private String pearsonSsoSession = "";
    private String apiKey = "";
    /** When true and OpenAM is enabled, SSO session is fetched from OpenAM instead of {@code pearson-sso-session}. */
    private boolean useOpenAmSso = true;
    private Polling polling = new Polling();

    public Provider getProvider() {
        return provider;
    }

    public void setProvider(Provider provider) {
        this.provider = provider;
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public String getPearsonSsoSession() {
        return pearsonSsoSession;
    }

    public void setPearsonSsoSession(String pearsonSsoSession) {
        this.pearsonSsoSession = pearsonSsoSession;
    }

    public String getApiKey() {
        return apiKey;
    }

    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }

    public boolean isUseOpenAmSso() {
        return useOpenAmSso;
    }

    public void setUseOpenAmSso(boolean useOpenAmSso) {
        this.useOpenAmSso = useOpenAmSso;
    }

    public Polling getPolling() {
        return polling;
    }

    public void setPolling(Polling polling) {
        this.polling = polling;
    }

    public boolean hasStaticCredentials() {
        return pearsonSsoSession != null
                && !pearsonSsoSession.isBlank()
                && apiKey != null
                && !apiKey.isBlank();
    }

    public static class Polling {
        private long intervalMs = 1500;
        private long maxDurationMs = 120_000;

        public long getIntervalMs() {
            return intervalMs;
        }

        public void setIntervalMs(long intervalMs) {
            this.intervalMs = intervalMs;
        }

        public long getMaxDurationMs() {
            return maxDurationMs;
        }

        public void setMaxDurationMs(long maxDurationMs) {
            this.maxDurationMs = maxDurationMs;
        }
    }
}
