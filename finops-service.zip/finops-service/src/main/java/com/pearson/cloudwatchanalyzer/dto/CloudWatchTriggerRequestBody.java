package com.pearson.cloudwatchanalyzer.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import lombok.Data;

/**
 * Optional JSON body for {@code POST .../analytics/trigger} and {@code POST .../cloudwatch/trigger}. When
 * {@code logGroups} is non-empty, or {@code logGroupName} is non-blank, that overrides discovery and static YAML for
 * this request only. If both are present, {@code logGroups} wins.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CloudWatchTriggerRequestBody {

    /**
     * Full CloudWatch log group names to query (e.g. {@code /aws/ecs/gps-stg-usrsrh-svc-01-use1}). Max 50 (Insights
     * limit). Whitespace-only entries are dropped.
     */
    private List<String> logGroups;

    /**
     * Single log group when you do not want to send a JSON array. Ignored when {@link #logGroups} is non-empty.
     */
    private String logGroupName;
}
