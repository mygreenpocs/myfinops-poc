package com.pearson.cloudwatchanalyzer;

import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Configuration for CloudWatch log analysis, log-group discovery, and CIDR fallback.
 *
 * <p><strong>Note:</strong> {@link #getRegion()} is the <em>ECS log group name suffix</em> (e.g. {@code
 * use1}), not the AWS SDK region id. SDK region stays under {@link Aws#getRegion()} (e.g. {@code
 * us-east-1}).
 */
@ConfigurationProperties(prefix = "cloudwatchanalyzer")
public class CloudWatchAnalyzerProperties {

    /**
     * Master switch for the CloudWatch aggregate pipeline: when false, {@link CloudWatchTriggerService} is not
     * registered and the scheduler no-ops scheduled runs. Prefer {@link Trigger#enabled} to disable only the REST
     * manual trigger while keeping the module “on” for future CIDR APIs.
     */
    private boolean enabled = true;

    /**
     * Environment segment in ECS log group names (e.g. {@code gps-qa} for groups like {@code
     * /aws/ecs/gps-qa-usrsrh-svc-01-use1}).
     */
    private String env = "gps-qa";

    /**
     * Region <em>suffix</em> in log group names (e.g. {@code use1}). Used with {@link #getEnv()} and
     * {@link LogGroup#getServices()} for discovery — not the same as {@link Aws#getRegion()}.
     */
    private String region = "use1";

    /**
     * YAML fallback: CIDR block → application name when MongoDB has no mappings (see CIDR stories). Keys may be
     * {@code a.b.c.d/prefix} or a bare IPv4 {@code a.b.c.d} (treated as {@code /32} when building {@link com.pearson.cloudwatchanalyzer.cidr.CidrRule}).
     */
    private Map<String, String> cidrBlocks = new LinkedHashMap<>();

    /**
     * Prefix length for bucketing <strong>unmatched</strong> (unknown) IPv4 {@code source} values when merging
     * aggregates and when emitting FINOPS-style {@code cidrBlock} echoes. Default {@code 16} yields {@code x.x.0.0/16};
     * use {@code 32} for per-host (single-IP) grouping.
     */
    private int unknownIpv4AggregatePrefixLength = 16;

    private final Scheduler scheduler = new Scheduler();
    private final Trigger trigger = new Trigger();
    private final LogGroup logGroup = new LogGroup();
    private final Query query = new Query();
    private final Aws aws = new Aws();

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    /**
     * Log group name suffix (e.g. use1). For AWS API region, use {@code cloudwatchanalyzer.aws.region}.
     */
    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public Map<String, String> getCidrBlocks() {
        return cidrBlocks;
    }

    public void setCidrBlocks(Map<String, String> cidrBlocks) {
        this.cidrBlocks = cidrBlocks != null ? new LinkedHashMap<>(cidrBlocks) : new LinkedHashMap<>();
    }

    public int getUnknownIpv4AggregatePrefixLength() {
        return unknownIpv4AggregatePrefixLength;
    }

    public void setUnknownIpv4AggregatePrefixLength(int unknownIpv4AggregatePrefixLength) {
        this.unknownIpv4AggregatePrefixLength = unknownIpv4AggregatePrefixLength;
    }

    public Scheduler getScheduler() {
        return scheduler;
    }

    /**
     * REST-only: {@code POST .../analytics/trigger}. When false, returns 503 without calling AWS. Future
     * {@code /cloudwatch/cidr-mappings} endpoints should not depend on this flag.
     */
    public Trigger getTrigger() {
        return trigger;
    }

    public LogGroup getLogGroup() {
        return logGroup;
    }

    public Query getQuery() {
        return query;
    }

    public Aws getAws() {
        return aws;
    }

    /** Region + optional named profile so the app matches {@code aws} CLI behavior when run from IDE/Gradle. */
    public static class Aws {
        /**
         * When false, {@link CloudWatchTriggerService} is not registered: scheduled and manual aggregate runs are
         * unavailable (empty {@link java.util.Optional}), while the rest of the app (including CIDR REST) still starts.
         */
        private boolean enabled = true;

        private String region = "us-east-1";
        /** If set, uses ProfileCredentialsProvider for that profile (same as {@code aws --profile}). */
        private String profile;
        /**
         * When true (default), each CloudWatch SDK call resolves credentials through a fresh profile provider so
         * {@code aws sso login} updates are visible without restart. When false, uses a single
         * {@link software.amazon.awssdk.auth.credentials.ProfileCredentialsProvider} (can stay stale for SSO until
         * {@code ~/.aws/config} changes). Ignored when no effective profile (see {@link AwsConfig}).
         */
        private boolean refreshCredentialsEachRequest = true;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public String getRegion() {
            return region;
        }

        public void setRegion(String region) {
            this.region = region;
        }

        public String getProfile() {
            return profile;
        }

        public void setProfile(String profile) {
            this.profile = profile;
        }

        public boolean isRefreshCredentialsEachRequest() {
            return refreshCredentialsEachRequest;
        }

        public void setRefreshCredentialsEachRequest(boolean refreshCredentialsEachRequest) {
            this.refreshCredentialsEachRequest = refreshCredentialsEachRequest;
        }
    }

    public static class Scheduler {
        private boolean enabled = true;
        /** Spring @Scheduled fixedDelay string, e.g. 900s */
        private String interval = "900s";

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public String getInterval() {
            return interval;
        }

        public void setInterval(String interval) {
            this.interval = interval;
        }
    }

    /** Gates the manual HTTP trigger only (not the scheduler, not future CIDR CRUD). */
    public static class Trigger {
        private boolean enabled = true;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }
    }

    /**
     * Service name keys for log group discovery: {@code /aws/ecs/{env}-{service}-svc-*-{region}} (see Epic
     * B).
     */
    public static class LogGroup {
        private List<String> services = new ArrayList<>(List.of("usrsrh", "org", "orgv2", "prfncv2"));

        public List<String> getServices() {
            return services;
        }

        public void setServices(List<String> services) {
            this.services = services != null ? new ArrayList<>(services) : new ArrayList<>();
        }
    }

    public static class Query {
        /**
         * Sliding window ending at "now" for {@link CloudWatchTriggerService#runOnce()} and the scheduler. Use
         * Spring {@link Duration} syntax in YAML, e.g. {@code 15m}, {@code 2d}, {@code 1h}. Legacy
         * {@code window-seconds} maps to {@link #setWindowSeconds(int)}.
         */
        private Duration window = Duration.ofMinutes(15);

        /**
         * Maximum query span for the configured window, {@code window} query param, and explicit epoch range on the
         * manual trigger. Examples: {@code 30d}, {@code 0s} (disable cap). Legacy {@code max-window-seconds} still
         * supported.
         */
        private Duration maxWindow = Duration.ofDays(30);

        /**
         * When true, log groups are resolved via {@link CloudWatchLogGroupDiscoveryService} using {@code env},
         * {@code region} (suffix), and {@link LogGroup#getServices()}. When false, {@link #logGroups} is used.
         */
        private boolean useLogGroupDiscovery = true;

        private List<String> logGroups = new ArrayList<>();

        public Duration getWindow() {
            return window;
        }

        public void setWindow(Duration window) {
            this.window = window != null ? window : Duration.ofMinutes(15);
        }

        public Duration getMaxWindow() {
            return maxWindow;
        }

        public void setMaxWindow(Duration maxWindow) {
            this.maxWindow = maxWindow != null ? maxWindow : Duration.ofDays(30);
        }

        /**
         * Window length in whole seconds (for CloudWatch epoch math). Prefer {@link #getWindow()} in new code.
         */
        public long getWindowSeconds() {
            return window.toSeconds();
        }

        /** @deprecated Prefer {@code query.window} (e.g. {@code 15m}) in YAML. */
        @Deprecated
        public void setWindowSeconds(int windowSeconds) {
            this.window = Duration.ofSeconds(windowSeconds);
        }

        /**
         * Max span in seconds; {@code 0} means no cap (legacy {@code max-window-seconds: 0} or {@code max-window: 0s}).
         */
        public long getMaxWindowSeconds() {
            if (maxWindow.isZero() || maxWindow.isNegative()) {
                return 0;
            }
            return maxWindow.toSeconds();
        }

        /** @deprecated Prefer {@code query.max-window} (e.g. {@code 30d}) in YAML. */
        @Deprecated
        public void setMaxWindowSeconds(int maxWindowSeconds) {
            this.maxWindow = maxWindowSeconds == 0 ? Duration.ZERO : Duration.ofSeconds(maxWindowSeconds);
        }

        public boolean isUseLogGroupDiscovery() {
            return useLogGroupDiscovery;
        }

        public void setUseLogGroupDiscovery(boolean useLogGroupDiscovery) {
            this.useLogGroupDiscovery = useLogGroupDiscovery;
        }

        public List<String> getLogGroups() {
            return logGroups;
        }

        public void setLogGroups(List<String> logGroups) {
            this.logGroups = logGroups != null ? new ArrayList<>(logGroups) : new ArrayList<>();
        }
    }
}
