package com.pearson.cloudwatchanalyzer;

/**
 * Resolves epoch query parameters for CloudWatch trigger endpoints: spec names {@code startTimeSeconds} /
 * {@code endTimeSeconds} vs legacy {@code startEpochSeconds} / {@code endEpochSeconds}.
 */
final class CloudWatchSpecEpochParams {

    private CloudWatchSpecEpochParams() {}

    /**
     * @return {@code [start, end]} both possibly null when absent (default window)
     * @throws IllegalArgumentException if parameters are inconsistent
     */
    static Long[] resolve(
            Long startTimeSeconds,
            Long endTimeSeconds,
            Long startEpochSeconds,
            Long endEpochSeconds) {
        boolean specStart = startTimeSeconds != null;
        boolean specEnd = endTimeSeconds != null;
        boolean legStart = startEpochSeconds != null;
        boolean legEnd = endEpochSeconds != null;

        if (specStart || specEnd) {
            if (!specStart || !specEnd) {
                throw new IllegalArgumentException(
                        "Both startTimeSeconds and endTimeSeconds are required for a custom range (or omit both for the configured window)");
            }
            if (legStart || legEnd) {
                throw new IllegalArgumentException(
                        "Use either startTimeSeconds/endTimeSeconds or startEpochSeconds/endEpochSeconds, not both");
            }
            return new Long[] {startTimeSeconds, endTimeSeconds};
        }
        if (legStart || legEnd) {
            if (!legStart || !legEnd) {
                throw new IllegalArgumentException(
                        "Both startEpochSeconds and endEpochSeconds are required for a custom range (or omit both for the configured window)");
            }
            return new Long[] {startEpochSeconds, endEpochSeconds};
        }
        return new Long[] {null, null};
    }
}
