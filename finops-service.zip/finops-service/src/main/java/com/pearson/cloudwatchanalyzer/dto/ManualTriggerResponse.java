package com.pearson.cloudwatchanalyzer.dto;

import java.util.ArrayList;
import java.util.List;

/** Response for {@code POST /v1/cloudwatch/analytics/trigger}. */
public class ManualTriggerResponse {

    private boolean success;
    private String message;
    /** Populated on failure when AWS SDK returns an error code (e.g. AccessDeniedException). */
    private String awsErrorCode;
    /** Hints for fixing credential / IAM mismatches between CLI and the JVM. */
    private String troubleshootingHint;
    private long windowStartEpochSeconds;
    private long windowEndEpochSeconds;
    /** Number of merged aggregate rows (one entry per {@link #rows} element). */
    private int rowCount;
    private final List<AggregateTriggerRow> rows = new ArrayList<>();

    public static ManualTriggerResponse failure(String message) {
        ManualTriggerResponse r = new ManualTriggerResponse();
        r.success = false;
        r.message = message;
        return r;
    }

    public String getAwsErrorCode() {
        return awsErrorCode;
    }

    public void setAwsErrorCode(String awsErrorCode) {
        this.awsErrorCode = awsErrorCode;
    }

    public String getTroubleshootingHint() {
        return troubleshootingHint;
    }

    public void setTroubleshootingHint(String troubleshootingHint) {
        this.troubleshootingHint = troubleshootingHint;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public long getWindowStartEpochSeconds() {
        return windowStartEpochSeconds;
    }

    public void setWindowStartEpochSeconds(long windowStartEpochSeconds) {
        this.windowStartEpochSeconds = windowStartEpochSeconds;
    }

    public long getWindowEndEpochSeconds() {
        return windowEndEpochSeconds;
    }

    public void setWindowEndEpochSeconds(long windowEndEpochSeconds) {
        this.windowEndEpochSeconds = windowEndEpochSeconds;
    }

    public int getRowCount() {
        return rowCount;
    }

    public void setRowCount(int rowCount) {
        this.rowCount = rowCount;
    }

    public List<AggregateTriggerRow> getRows() {
        return rows;
    }
}
