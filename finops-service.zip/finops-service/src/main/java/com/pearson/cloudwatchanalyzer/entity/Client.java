package com.pearson.cloudwatchanalyzer.entity;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.util.List;

/**
 * MongoDB document representing a client/tenant and their associated service names/endpoints.
 */
@Data
@Document(collection = "client")
public class Client {
    @Id
    private String id;
    private String name;
    private List<String> services;
    private List<String> awsRegions;

    @com.fasterxml.jackson.annotation.JsonIgnore
    public void setAwsRegion(String awsRegion) {
        if (awsRegion != null && !awsRegion.isBlank()) {
            this.awsRegions = List.of(awsRegion.trim());
        }
    }
}
