package com.pearson.cloudwatchanalyzer.entity;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.util.Map;

/**
 * MongoDB document for client-specific cost model and rates configuration.
 */
@Data
@Document(collection = "costModelMapping")
public class CostModelMapping {

    @Id
    private String id;

    private String clientId;

    private String identityKey;

    private String costModel;

    private Map<String, Object> customRates;
}
