package com.pearson.cloudwatchanalyzer.cidr;

import com.google.common.net.InetAddresses;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.util.Locale;

/** IPv4-only CIDR parsing and containment (internal to {@link CidrMatcher}). */
final class Ipv4Cidr {

    /** When no {@code /prefix} is given, treat the value as a single host ({@code /32}). */
    static final int DEFAULT_HOST_PREFIX_LENGTH = 32;

    private Ipv4Cidr() {}

    static void validateCidrSyntax(String cidr) {
        parse(cidr);
    }

    /**
     * Trims input; if there is no {@code /}, parses as IPv4 and appends {@code /32} (default grouping is single host).
     * Otherwise returns the trimmed CIDR string.
     */
    static String normalizeCidrWithDefaultPrefix(String cidrOrHost) {
        if (cidrOrHost == null) {
            throw new IllegalArgumentException("cidrBlock must not be null");
        }
        String t = cidrOrHost.trim();
        if (t.isEmpty()) {
            throw new IllegalArgumentException("cidrBlock must not be blank");
        }
        if (!t.contains("/")) {
            parseIpv4Only(t);
            return t + "/" + DEFAULT_HOST_PREFIX_LENGTH;
        }
        return t;
    }

    /**
     * @throws IllegalArgumentException if {@code cidr} is not IPv4 {@code a.b.c.d} or {@code a.b.c.d/prefix}
     */
    static Parsed parse(String cidr) {
        String t = normalizeCidrWithDefaultPrefix(cidr);
        int slash = t.indexOf('/');
        if (slash <= 0 || slash == t.length() - 1) {
            throw new IllegalArgumentException("Invalid CIDR (expected a.b.c.d/prefix): " + cidr);
        }
        String host = t.substring(0, slash);
        int prefix;
        try {
            prefix = Integer.parseInt(t.substring(slash + 1).trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid CIDR prefix: " + cidr);
        }
        if (prefix < 0 || prefix > 32) {
            throw new IllegalArgumentException("CIDR prefix must be 0..32: " + cidr);
        }
        InetAddress addr;
        try {
            addr = InetAddresses.forString(host);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid IPv4 network address: " + cidr, e);
        }
        if (!(addr instanceof Inet4Address)) {
            throw new IllegalArgumentException("Only IPv4 CIDRs are supported: " + cidr);
        }
        long network = ipv4ToUnsignedLong((Inet4Address) addr);
        long mask = prefix == 0 ? 0L : (0xffffffffL << (32 - prefix)) & 0xffffffffL;
        return new Parsed(network, mask, t);
    }

    static boolean contains(Parsed cidr, Inet4Address ip) {
        long ipL = ipv4ToUnsignedLong(ip);
        return (ipL & cidr.mask) == (cidr.network & cidr.mask);
    }

    static Inet4Address parseIpv4Only(String ip) {
        InetAddress a = InetAddresses.forString(ip.trim());
        if (!(a instanceof Inet4Address)) {
            throw new IllegalArgumentException("Not an IPv4 address: " + ip);
        }
        return (Inet4Address) a;
    }

    static long ipv4ToUnsignedLong(Inet4Address ip) {
        byte[] b = ip.getAddress();
        return ((b[0] & 0xffL) << 24)
                | ((b[1] & 0xffL) << 16)
                | ((b[2] & 0xffL) << 8)
                | (b[3] & 0xffL);
    }

    static final class Parsed {
        final long network;
        final long mask;
        final String canonicalCidr;

        Parsed(long network, long mask, String canonicalCidr) {
            this.network = network;
            this.mask = mask;
            this.canonicalCidr = canonicalCidr;
        }
    }

    static boolean looksLikeNaSentinel(String s) {
        if (s == null) {
            return true;
        }
        String t = s.trim();
        if (t.isEmpty()) {
            return true;
        }
        String u = t.toUpperCase(Locale.ROOT);
        return "NA".equals(u) || "N/A".equals(u);
    }
}
