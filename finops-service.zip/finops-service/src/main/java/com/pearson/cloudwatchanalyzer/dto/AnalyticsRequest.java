package com.pearson.cloudwatchanalyzer.dto;

/**
 * Legacy per-log-line analytics shape (pre-aggregate pipeline). The CloudWatch → GAIME job posts
 * {@link AnalyticsAggregateRequest} instead.
 */
public class AnalyticsRequest {
    private String nrTraceId;
    private String amznTraceId;
    private String method;
    private String endpoint;
    private String status;
    private String responseTimeMs;
    private String xAppId;
    private String xTraceId;
    private String inputSize;
    private String outputSize;
    private String prsnUserId;

    public AnalyticsRequest() {}

    public AnalyticsRequest(String nrTraceId, String amznTraceId, String method, String endpoint, String status, String responseTimeMs, String xAppId, String xTraceId, String inputSize, String outputSize, String prsnUserId) {
        this.nrTraceId = nrTraceId;
        this.amznTraceId = amznTraceId;
        this.method = method;
        this.endpoint = endpoint;
        this.status = status;
        this.responseTimeMs = responseTimeMs;
        this.xAppId = xAppId;
        this.xTraceId = xTraceId;
        this.inputSize = inputSize;
        this.outputSize = outputSize;
        this.prsnUserId = prsnUserId;
    }

    // Getters and setters

    public String getNrTraceId() {
        return nrTraceId;
    }

    public void setNrTraceId(String nrTraceId) {
        this.nrTraceId = nrTraceId;
    }

    public String getAmznTraceId() {
        return amznTraceId;
    }

    public void setAmznTraceId(String amznTraceId) {
        this.amznTraceId = amznTraceId;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getEndpoint() {
        return endpoint;
    }

    public void setEndpoint(String endpoint) {
        this.endpoint = endpoint;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getResponseTimeMs() {
        return responseTimeMs;
    }

    public void setResponseTimeMs(String responseTimeMs) {
        this.responseTimeMs = responseTimeMs;
    }

    public String getxAppId() {
        return xAppId;
    }

    public void setxAppId(String xAppId) {
        this.xAppId = xAppId;
    }

    public String getxTraceId() {
        return xTraceId;
    }

    public void setxTraceId(String xTraceId) {
        this.xTraceId = xTraceId;
    }

    public String getInputSize() {
        return inputSize;
    }

    public void setInputSize(String inputSize) {
        this.inputSize = inputSize;
    }

    public String getOutputSize() {
        return outputSize;
    }

    public void setOutputSize(String outputSize) {
        this.outputSize = outputSize;
    }

    public String getPrsnUserId() {
        return prsnUserId;
    }

    public void setPrsnUserId(String prsnUserId) {
        this.prsnUserId = prsnUserId;
    }

    @Override
    public String toString() {
        return "AnalyticsRequest{" +
                "nrTraceId='" + nrTraceId + '\'' +
                ", amznTraceId='" + amznTraceId + '\'' +
                ", method='" + method + '\'' +
                ", endpoint='" + endpoint + '\'' +
                ", status='" + status + '\'' +
                ", responseTimeMs='" + responseTimeMs + '\'' +
                ", xAppId='" + xAppId + '\'' +
                ", xTraceId='" + xTraceId + '\'' +
                ", inputSize='" + inputSize + '\'' +
                ", outputSize='" + outputSize + '\'' +
                ", prsnUserId='" + prsnUserId + '\'' +
                '}';
    }
}

