package com.pearson.cloudwatchanalyzer.dto;

import java.util.LinkedHashMap;
import java.util.Map;

/** One merged aggregate row: flat {@link #cloudWatchRow} dimensions only. */
public class AggregateTriggerRow {

    private Map<String, String> cloudWatchRow = new LinkedHashMap<>();

    public Map<String, String> getCloudWatchRow() {
        return cloudWatchRow;
    }

    public void setCloudWatchRow(Map<String, String> cloudWatchRow) {
        this.cloudWatchRow = cloudWatchRow;
    }
}
