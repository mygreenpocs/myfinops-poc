package com.pearson.cloudwatchanalyzer.dto;

import com.pearson.cloudwatchanalyzer.LogGroupServiceExtractor;
import java.util.Map;
import java.util.Optional;

/**
 * One row from a CloudWatch Logs Insights {@code stats ... by source, patternUrl, status, @log} result.
 */
public class AggregateStatsRow {

    private final String source;
    private final String patternUrl;
    private final String status;
    private final long count;
    private final long totalOutputSize;
    /** Full log group name from Insights {@code @log} column (may be empty if query omits it). */
    private final String logGroupName;
    /** ECS service key parsed from {@link #logGroupName} and env (e.g. {@code usrsrh}). */
    private final String logGroupService;
    /**
     * Optional client domain / system name parsed from the log line ({@code systemName} / {@code sysName} column).
     * CIDR resolution and merge still use {@link #source} (typically the client IP).
     */
    private final String timeLoggerSystemName;

    public AggregateStatsRow(String source, String patternUrl, String status, long count, long totalOutputSize) {
        this(source, patternUrl, status, count, totalOutputSize, "", "", "");
    }

    public AggregateStatsRow(
            String source,
            String patternUrl,
            String status,
            long count,
            long totalOutputSize,
            String logGroupName,
            String logGroupService) {
        this(source, patternUrl, status, count, totalOutputSize, logGroupName, logGroupService, "");
    }

    public AggregateStatsRow(
            String source,
            String patternUrl,
            String status,
            long count,
            long totalOutputSize,
            String logGroupName,
            String logGroupService,
            String timeLoggerSystemName) {
        this.source = source;
        this.patternUrl = patternUrl;
        this.status = status;
        this.count = count;
        this.totalOutputSize = totalOutputSize;
        this.logGroupName = logGroupName != null ? logGroupName : "";
        this.logGroupService = logGroupService != null ? logGroupService : "";
        this.timeLoggerSystemName = timeLoggerSystemName != null ? timeLoggerSystemName.trim() : "";
    }

    public String getSource() {
        return source;
    }

    public String getPatternUrl() {
        return patternUrl;
    }

    public String getStatus() {
        return status;
    }

    public long getCount() {
        return count;
    }

    public long getTotalOutputSize() {
        return totalOutputSize;
    }

    public String getLogGroupName() {
        return logGroupName;
    }

    public String getLogGroupService() {
        return logGroupService;
    }

    public String getTimeLoggerSystemName() {
        return timeLoggerSystemName;
    }

    /**
     * Same as {@link #tryParse(Map, String)} with empty env (no service key extraction).
     */
    public static Optional<AggregateStatsRow> tryParse(Map<String, String> row) {
        return tryParse(row, "");
    }

    /**
     * @param ecsEnv {@link com.pearson.cloudwatchanalyzer.CloudWatchAnalyzerProperties#getEnv()} for parsing
     *     {@code logGroupService} from the {@code @log} field
     */
    public static Optional<AggregateStatsRow> tryParse(Map<String, String> row, String ecsEnv) {
        if (row == null || row.isEmpty()) {
            return Optional.empty();
        }
        String source = getIgnoreCase(row, "source");
        String patternUrl = getIgnoreCase(row, "patternUrl");
        String status = getIgnoreCase(row, "status");
        String countStr = getIgnoreCase(row, "count");
        String totalStr = getIgnoreCase(row, "totalOutputSize");
        if (isBlank(source) || isBlank(patternUrl) || isBlank(status) || isBlank(countStr) || isBlank(totalStr)) {
            return Optional.empty();
        }
        try {
            long count = parseLongFlexible(countStr);
            long total = parseLongFlexible(totalStr);
            String logGroupName = firstNonBlank(getIgnoreCase(row, "@log"), getIgnoreCase(row, "log"));
            if (logGroupName == null) {
                logGroupName = "";
            } else {
                logGroupName = logGroupName.trim();
            }
            String logGroupService = LogGroupServiceExtractor.extractServiceKey(logGroupName, ecsEnv);
            String tlsn = firstNonBlank(getIgnoreCase(row, "systemName"), getIgnoreCase(row, "sysName"));
            if (tlsn != null) {
                tlsn = tlsn.trim();
            } else {
                tlsn = "";
            }
            return Optional.of(
                    new AggregateStatsRow(
                            source.trim(),
                            patternUrl.trim(),
                            status.trim(),
                            count,
                            total,
                            logGroupName,
                            logGroupService,
                            tlsn));
        } catch (NumberFormatException ex) {
            return Optional.empty();
        }
    }

    private static String firstNonBlank(String a, String b) {
        if (a != null && !a.isBlank()) {
            return a;
        }
        if (b != null && !b.isBlank()) {
            return b;
        }
        return null;
    }

    private static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    private static String getIgnoreCase(Map<String, String> row, String key) {
        for (Map.Entry<String, String> e : row.entrySet()) {
            if (e.getKey() != null && e.getKey().equalsIgnoreCase(key)) {
                return e.getValue();
            }
        }
        return null;
    }

    static long parseLongFlexible(String raw) {
        if (raw == null) {
            throw new NumberFormatException("null");
        }
        String t = raw.trim().replace(",", "");
        if (t.isEmpty()) {
            throw new NumberFormatException("empty");
        }
        if (t.contains(".")) {
            return Math.round(Double.parseDouble(t));
        }
        return Long.parseLong(t);
    }
}
