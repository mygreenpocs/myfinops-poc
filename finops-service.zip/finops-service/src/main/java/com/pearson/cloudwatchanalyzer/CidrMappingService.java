package com.pearson.cloudwatchanalyzer;

import com.pearson.cloudwatchanalyzer.cidr.CidrMatcher;
import com.pearson.cloudwatchanalyzer.cidr.CidrRule;
import com.pearson.cloudwatchanalyzer.entity.CidrBlockMapping;
import com.pearson.cloudwatchanalyzer.repository.CidrBlockMappingRepository;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Loads CIDR rules for {@link CidrMatcher}: <strong>MongoDB</strong> when the collection has at least one document,
 * otherwise {@link CloudWatchAnalyzerProperties#getCidrBlocks()} (YAML) in map iteration order.
 *
 * <p>Epic <strong>D.2</strong>; persists via {@link CidrBlockMapping} / {@link CidrBlockMappingRepository} (Epic E.1).
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CidrMappingService {

    private final CidrBlockMappingRepository cidrBlockMappingRepository;
    private final CloudWatchAnalyzerProperties properties;

    /**
     * Ordered rules for matcher construction. Mongo wins when {@link CidrBlockMappingRepository#count()} &gt; 0.
     */
    public List<CidrRule> loadOrderedRules() {
        long mongoCount = cidrBlockMappingRepository.count();
        if (mongoCount > 0) {
            List<CidrRule> fromDb = rulesFromMongo();
            log.debug("CidrMappingService: using {} rule(s) from MongoDB cidrBlockMapping", fromDb.size());
            return fromDb;
        }
        List<CidrRule> fromYaml = rulesFromYaml(properties.getCidrBlocks());
        log.debug("CidrMappingService: Mongo empty; using {} rule(s) from cloudwatchanalyzer.cidr-blocks", fromYaml.size());
        return fromYaml;
    }

    /** Convenience: matcher backed by {@link #loadOrderedRules()}. */
    public CidrMatcher buildMatcher() {
        return CidrMatcher.fromRules(loadOrderedRules());
    }

    /**
     * Effective {@code cidrBlock → applicationName} map as used by the analyzer (Mongo rules when collection non-empty,
     * else YAML {@code cidr-blocks}). Order preserved; duplicate CIDR keys keep the last occurrence.
     */
    public Map<String, String> effectiveConfigMap() {
        Map<String, String> map = new LinkedHashMap<>();
        for (CidrRule r : loadOrderedRules()) {
            map.put(r.getCidrBlock(), r.getApplicationName());
        }
        return map;
    }

    private List<CidrRule> rulesFromMongo() {
        List<CidrBlockMapping> docs = cidrBlockMappingRepository.findAllByOrderBySortOrderAsc();
        List<CidrRule> rules = new ArrayList<>(docs.size());
        for (CidrBlockMapping doc : docs) {
            if (doc.getCidrBlock() == null || doc.getCidrBlock().isBlank()) {
                log.warn("Skipping CidrBlockMapping id={}: blank cidrBlock", doc.getId());
                continue;
            }
            if (doc.getApplicationName() == null || doc.getApplicationName().isBlank()) {
                log.warn("Skipping CidrBlockMapping id={}: blank applicationName", doc.getId());
                continue;
            }
            try {
                rules.add(new CidrRule(doc.getCidrBlock(), doc.getApplicationName(), doc.getSortOrder()));
            } catch (IllegalArgumentException ex) {
                log.warn("Skipping CidrBlockMapping id={}: {}", doc.getId(), ex.getMessage());
            }
        }
        return List.copyOf(rules);
    }

    private static List<CidrRule> rulesFromYaml(Map<String, String> cidrBlocks) {
        if (cidrBlocks == null || cidrBlocks.isEmpty()) {
            return List.of();
        }
        Map<String, String> ordered =
                cidrBlocks instanceof LinkedHashMap<String, String> lm ? lm : new LinkedHashMap<>(cidrBlocks);
        List<CidrRule> rules = new ArrayList<>();
        int order = 0;
        for (Map.Entry<String, String> e : ordered.entrySet()) {
            String app = e.getValue();
            if (app == null || app.isBlank()) {
                continue;
            }
            try {
                rules.add(new CidrRule(e.getKey(), app.trim(), order++));
            } catch (IllegalArgumentException ex) {
                log.warn("Skipping cidr-blocks entry {}: {}", e.getKey(), ex.getMessage());
            }
        }
        return List.copyOf(rules);
    }
}
