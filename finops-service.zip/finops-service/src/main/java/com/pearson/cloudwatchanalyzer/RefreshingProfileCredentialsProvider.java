package com.pearson.cloudwatchanalyzer;

import software.amazon.awssdk.auth.credentials.AwsCredentials;
import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider;
import software.amazon.awssdk.auth.credentials.ProfileCredentialsProvider;
import software.amazon.awssdk.profiles.ProfileFileSupplier;
import software.amazon.awssdk.utils.SdkAutoCloseable;

/**
 * AWS SDK {@link ProfileCredentialsProvider} only replaces its internal delegate when the parsed {@code ProfileFile}
 * instance changes. After {@code aws sso login}, the SSO token cache under {@code ~/.aws/sso/cache/} updates but
 * {@code ~/.aws/config} often does not, so {@link Object#equals} on {@code ProfileFile} stays true and stale credentials
 * remain until JVM restart.
 *
 * <p>This provider builds a short-lived {@link ProfileCredentialsProvider} on every {@link #resolveCredentials()} (and
 * closes it) so each CloudWatch API call re-reads shared config + SSO cache from disk.
 */
public final class RefreshingProfileCredentialsProvider implements AwsCredentialsProvider, SdkAutoCloseable {

    private final String profileName;

    public RefreshingProfileCredentialsProvider(String profileName) {
        if (profileName == null || profileName.isBlank()) {
            throw new IllegalArgumentException("profileName is required");
        }
        this.profileName = profileName.trim();
    }

    @Override
    public AwsCredentials resolveCredentials() {
        ProfileCredentialsProvider provider =
                ProfileCredentialsProvider.builder()
                        .profileName(profileName)
                        .profileFile(ProfileFileSupplier.defaultSupplier())
                        .build();
        try {
            return provider.resolveCredentials();
        } finally {
            provider.close();
        }
    }

    @Override
    public void close() {
        // nothing held across calls
    }
}
