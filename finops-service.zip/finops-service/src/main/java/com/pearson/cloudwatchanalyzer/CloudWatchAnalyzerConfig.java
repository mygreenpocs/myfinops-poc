package com.pearson.cloudwatchanalyzer;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
@EnableConfigurationProperties(CloudWatchAnalyzerProperties.class)
public class CloudWatchAnalyzerConfig {

    @Bean
    public RestTemplate cloudWatchAnalyzerRestTemplate() {
        return new RestTemplate();
    }
}
