package com.pearson.cloudwatchanalyzer.logging;

/** Truncates long strings for CloudWatch pipeline logs (Epic H.1). */
public final class CloudWatchLogSanitizer {

    private static final int DEFAULT_MAX_BODY_CHARS = 512;

    private CloudWatchLogSanitizer() {}

    /** Truncates long strings for log lines. */
    public static String truncateForLog(String s, int maxChars) {
        if (s == null) {
            return null;
        }
        if (maxChars <= 0 || s.length() <= maxChars) {
            return s;
        }
        return s.substring(0, maxChars) + "...(truncated,len=" + s.length() + ")";
    }

    public static String truncateForLog(String s) {
        return truncateForLog(s, DEFAULT_MAX_BODY_CHARS);
    }
}
