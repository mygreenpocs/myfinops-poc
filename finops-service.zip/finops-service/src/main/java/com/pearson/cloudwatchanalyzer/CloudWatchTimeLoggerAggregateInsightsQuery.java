package com.pearson.cloudwatchanalyzer;

/**
 * CloudWatch Logs Insights query for <strong>aggregated</strong> TimeLogger metrics (spec / Epic C).
 *
 * <p>Validate in the AWS console: Logs → Insights → paste {@link #QUERY} → select one ECS log group → Run
 * query. Column names in the result set should match {@code source}, {@code patternUrl}, {@code status},
 * optional {@code systemName} (client domain / sysname from the log line), {@code count}, {@code totalOutputSize}
 * (used by {@link com.pearson.cloudwatchanalyzer.dto.AggregateStatsRow}).
 *
 * <p>If {@code sum(outputSize)} fails because {@code outputSize} is non-numeric in your account, adjust the
 * query (e.g. cast) in this constant only.
 */
public final class CloudWatchTimeLoggerAggregateInsightsQuery {

    private CloudWatchTimeLoggerAggregateInsightsQuery() {}

    /**
     * Filters {@code TimeLoggerFilter}, parses dimensions, drops incomplete rows, then stats by source /
     * patternUrl / status.
     */
    public static final String QUERY =
            "fields @timestamp, @message\n"
                    + "| filter @message like /TimeLoggerFilter/\n"
                    + "| parse @message /status : (?<status>\\d+)/\n"
                    + "| parse @message /outputSize : (?<outputSize>\\d+)/\n"
                    + "| parse @message /patternUrl : (?<patternUrl>[^,]+)/\n"
                    + "| parse @message /source : (?<source>\\S+)/\n"
                    + "| parse @message /systemName : (?<systemName>[^\\s,]+)/\n"
                    + "| parse @message /method : (?<method>[a-zA-Z]+)/\n"
                    + "| filter source != \"\" and patternUrl != \"\" and outputSize != \"\"\n"
                    + "| stats count(*) as count, sum(outputSize) as totalOutputSize by source, patternUrl, method, status, systemName, @log";
}
