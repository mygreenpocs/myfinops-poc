package com.pearson.cloudwatchanalyzer;

import com.pearson.cloudwatchanalyzer.dto.AggregateStatsRow;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.cloudwatchlogs.CloudWatchLogsClient;
import software.amazon.awssdk.services.cloudwatchlogs.model.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class CloudWatchQueryService {

    private final CloudWatchLogsClient cloudWatchLogsClient;
    private final CloudWatchAnalyzerProperties analyzerProperties;

    /**
     * Execute a CloudWatch Logs Insights query
     *
     * @param logGroupName The log group to query
     * @param queryString  The CloudWatch Insights query string
     * @param startTime    Start time for the query (epoch millis)
     * @param endTime      End time for the query (epoch millis)
     * @return List of query results as maps
     */
    public List<Map<String, String>> executeQuery(String logGroupName, String queryString,
                                                   Long startTime, Long endTime) {
        log.info("Executing CloudWatch query on log group: {}", logGroupName);
        log.info("Query: {}", queryString);

        // Default to last 1 hour if times not specified
        long start = startTime != null ? startTime : Instant.now().minus(1, ChronoUnit.HOURS).getEpochSecond();
        long end = endTime != null ? endTime : Instant.now().getEpochSecond();

        // Start the query
        StartQueryRequest startQueryRequest = StartQueryRequest.builder()
                .logGroupName(logGroupName)
                .startTime(start)
                .endTime(end)
                .queryString(queryString)
                .build();

        StartQueryResponse startQueryResponse = cloudWatchLogsClient.startQuery(startQueryRequest);
        String queryId = startQueryResponse.queryId();
        log.info("Query started with ID: {}", queryId);

        // Poll for results
        return pollForResults(queryId);
    }

    /**
     * Execute a query across multiple log groups
     */
    public List<Map<String, String>> executeQueryMultipleGroups(List<String> logGroupNames, 
                                                                  String queryString,
                                                                  Long startTime, Long endTime) {
        log.debug(
                "event=cloudwatch_insights_start_multi logGroupCount={} logGroups={} querySnippet={}",
                logGroupNames.size(),
                logGroupNames,
                queryString != null && queryString.length() > 120
                        ? queryString.substring(0, 120) + "..."
                        : queryString);

        long start = startTime != null ? startTime : Instant.now().minus(1, ChronoUnit.HOURS).getEpochSecond();
        long end = endTime != null ? endTime : Instant.now().getEpochSecond();

        StartQueryRequest startQueryRequest = StartQueryRequest.builder()
                .logGroupNames(logGroupNames)
                .startTime(start)
                .endTime(end)
                .queryString(queryString)
                .build();

        StartQueryResponse startQueryResponse = cloudWatchLogsClient.startQuery(startQueryRequest);
        String queryId = startQueryResponse.queryId();
        log.debug("event=cloudwatch_insights_query_submitted queryId={}", queryId);

        return pollForResults(queryId);
    }

    /**
     * Runs {@link CloudWatchTimeLoggerAggregateInsightsQuery#QUERY} across the given log groups and returns
     * parsed {@link AggregateStatsRow} (rows that fail to parse are skipped).
     *
     * @param startTimeEpochSec start of window (epoch seconds)
     * @param endTimeEpochSec end of window (epoch seconds)
     */
    public List<AggregateStatsRow> executeAggregateTimeLoggerQuery(
            List<String> logGroupNames, Long startTimeEpochSec, Long endTimeEpochSec) {
        if (logGroupNames == null || logGroupNames.isEmpty()) {
            throw new IllegalArgumentException("logGroupNames must not be empty");
        }
        List<Map<String, String>> raw =
                executeQueryMultipleGroups(
                        logGroupNames,
                        CloudWatchTimeLoggerAggregateInsightsQuery.QUERY,
                        startTimeEpochSec,
                        endTimeEpochSec);
        List<AggregateStatsRow> out = new ArrayList<>();
        for (Map<String, String> row : raw) {
            AggregateStatsRow.tryParse(row, analyzerProperties.getEnv()).ifPresent(out::add);
        }
        int dropped = raw.size() - out.size();
        if (dropped > 0) {
            log.warn(
                    "event=cloudwatch_insights_aggregate_parse_skipped skippedRowCount={} reason=unparseable_aggregate_fields",
                    dropped);
        }
        log.info(
                "event=cloudwatch_insights_aggregate logGroupCount={} rawInsightsRows={} parsedAggregateRows={}",
                logGroupNames.size(),
                raw.size(),
                out.size());
        return out;
    }

    /**
     * Poll for query results until complete or timeout
     */
    private List<Map<String, String>> pollForResults(String queryId) {
        List<Map<String, String>> results = new ArrayList<>();
        int maxAttempts = 60; // Max 60 seconds
        int attempts = 0;

        while (attempts < maxAttempts) {
            GetQueryResultsRequest getResultsRequest = GetQueryResultsRequest.builder()
                    .queryId(queryId)
                    .build();

            GetQueryResultsResponse resultsResponse = cloudWatchLogsClient.getQueryResults(getResultsRequest);
            QueryStatus status = resultsResponse.status();

            log.debug("Query status: {}", status);

            if (status == QueryStatus.COMPLETE) {
                log.info("Query completed successfully");
                // Convert results to list of maps
                for (List<ResultField> row : resultsResponse.results()) {
                    Map<String, String> rowMap = new HashMap<>();
                    for (ResultField field : row) {
                        rowMap.put(field.field(), field.value());
                    }
                    results.add(rowMap);
                }
                log.info("Retrieved {} results", results.size());
                break;
            } else if (status == QueryStatus.FAILED || status == QueryStatus.CANCELLED) {
                log.error("Query failed with status: {}", status);
                throw new RuntimeException("CloudWatch query failed with status: " + status);
            }

            // Wait before polling again
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new RuntimeException("Query polling interrupted", e);
            }
            attempts++;
        }

        if (attempts >= maxAttempts) {
            log.warn("Query timed out after {} seconds", maxAttempts);
        }

        return results;
    }

    /**
     * List available log groups
     */
    public List<String> listLogGroups(String prefix) {
        log.info("Listing log groups with prefix: {}", prefix);
        
        DescribeLogGroupsRequest.Builder requestBuilder = DescribeLogGroupsRequest.builder();
        if (prefix != null && !prefix.isEmpty()) {
            requestBuilder.logGroupNamePrefix(prefix);
        }

        DescribeLogGroupsResponse response = cloudWatchLogsClient.describeLogGroups(requestBuilder.build());
        
        List<String> logGroups = response.logGroups().stream()
                .map(LogGroup::logGroupName)
                .toList();
        
        log.info("Found {} log groups", logGroups.size());
        return logGroups;
    }

    /**
     * Get log events directly from a log stream
     */
    public List<Map<String, Object>> getLogEvents(String logGroupName, String logStreamName, 
                                                    Long startTime, Long endTime, int limit) {
        log.info("Getting log events from {}/{}", logGroupName, logStreamName);

        GetLogEventsRequest.Builder requestBuilder = GetLogEventsRequest.builder()
                .logGroupName(logGroupName)
                .logStreamName(logStreamName)
                .limit(limit)
                .startFromHead(true);

        if (startTime != null) {
            requestBuilder.startTime(startTime);
        }
        if (endTime != null) {
            requestBuilder.endTime(endTime);
        }

        GetLogEventsResponse response = cloudWatchLogsClient.getLogEvents(requestBuilder.build());

        List<Map<String, Object>> events = new ArrayList<>();
        for (OutputLogEvent event : response.events()) {
            Map<String, Object> eventMap = new HashMap<>();
            eventMap.put("timestamp", event.timestamp());
            eventMap.put("message", event.message());
            eventMap.put("ingestionTime", event.ingestionTime());
            events.add(eventMap);
        }

        log.info("Retrieved {} log events", events.size());
        return events;
    }
}

