package com.pearson.cloudwatchanalyzer.repository;

import com.pearson.cloudwatchanalyzer.entity.CidrBlockMapping;
import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CidrBlockMappingRepository extends MongoRepository<CidrBlockMapping, String> {

    List<CidrBlockMapping> findAllByOrderBySortOrderAsc();
}
