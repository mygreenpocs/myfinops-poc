package com.pearson.cloudwatchanalyzer;

import com.pearson.cloudwatchanalyzer.dto.AggregateStatsRow;
import com.pearson.cloudwatchanalyzer.dto.AggregateTriggerRow;
import com.pearson.cloudwatchanalyzer.dto.ManualTriggerResponse;
import java.time.Duration;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

/**
 * Orchestrates the CloudWatch aggregate pipeline: resolve log groups → run Insights aggregate query → CIDR merge →
 * build per-row payloads for the trigger API. Used by {@link CloudWatchScheduler} and {@link CloudWatchManualTriggerController}.
 */
@Slf4j
@Service
@RequiredArgsConstructor
@ConditionalOnProperty(
        name = {"cloudwatchanalyzer.enabled", "cloudwatchanalyzer.aws.enabled"},
        havingValue = "true",
        matchIfMissing = true)
public class CloudWatchTriggerService {

    /** CloudWatch Logs Insights caps sources per StartQuery; stay within a safe margin. */
    public static final int MAX_LOG_GROUPS_PER_QUERY = 50;

    private final CloudWatchQueryService queryService;
    private final CloudWatchLogGroupDiscoveryService logGroupDiscoveryService;
    private final CloudWatchAnalyzerProperties properties;
    private final AggregateStatsMergeService aggregateStatsMergeService;
    private final CloudWatchAggregateRowBuilder aggregateRowBuilder;

    /** Clock skew allowed when validating {@code end} is not in the future (seconds). */
    private static final long FUTURE_END_TOLERANCE_SECONDS = 300;

    /**
     * Runs the aggregated CloudWatch Insights query for the configured window and returns merged rows with payloads.
     */
    public ManualTriggerResponse runOnce() {
        return runOnce(null, null, null, null);
    }

    /**
     * Same as {@link #runOnce()} but with an optional absolute range (Unix epoch seconds). When both
     * {@code startEpochSeconds} and {@code endEpochSeconds} are null, uses configured {@code query.window} ending at
     * now. When both are set, uses that range.
     *
     * @throws IllegalArgumentException if only one of the epoch params is set, or the range is invalid
     */
    public ManualTriggerResponse runOnce(Long startEpochSeconds, Long endEpochSeconds) {
        return runOnce(startEpochSeconds, endEpochSeconds, null, null);
    }

    /**
     * Optional {@code requestWindow}: sliding window ending at now (e.g. from {@code ?window=2d}). Mutually exclusive
     * with {@code startEpochSeconds}/{@code endEpochSeconds}.
     */
    public ManualTriggerResponse runOnce(Long startEpochSeconds, Long endEpochSeconds, Duration requestWindow) {
        return runOnce(startEpochSeconds, endEpochSeconds, requestWindow, null);
    }

    /**
     * Same as {@link #runOnce(Long, Long, Duration)} with optional per-request log group override (from JSON body).
     * When {@code requestOverrideLogGroups} is non-empty after trimming, it replaces discovery and YAML for this run.
     */
    public ManualTriggerResponse runOnce(
            Long startEpochSeconds, Long endEpochSeconds, Duration requestWindow, List<String> requestOverrideLogGroups) {
        if (!properties.isEnabled()) {
            throw new IllegalStateException("cloudwatchanalyzer.enabled is false");
        }
        List<String> logGroups = resolveLogGroupsForQuery(requestOverrideLogGroups);
        if (logGroups.isEmpty()) {
            throw new IllegalStateException(
                    "No log groups to query: set cloudwatchanalyzer.query.log-groups or enable "
                            + "use-log-group-discovery with env, region suffix, and log-group.services; "
                            + "or POST a JSON body {\"logGroups\":[\"/aws/ecs/...\"]} or {\"logGroupName\":\"/aws/ecs/...\"} "
                            + "to override for this request");
        }

        long now = System.currentTimeMillis() / 1000;
        long[] window = validateAndResolveWindow(startEpochSeconds, endEpochSeconds, requestWindow, now);
        long start = window[0];
        long end = window[1];

        log.info(
                "event=cloudwatch_pipeline_start logGroupCount={} useLogGroupDiscovery={} windowEpochStart={} windowEpochEnd={} spanSeconds={} env={} logRegionSuffix={}",
                logGroups.size(),
                properties.getQuery().isUseLogGroupDiscovery(),
                start,
                end,
                end - start,
                properties.getEnv(),
                properties.getRegion());
        log.debug("event=cloudwatch_pipeline_start_detail logGroups={}", logGroups);

        List<AggregateStatsRow> rawAggregates =
                queryService.executeAggregateTimeLoggerQuery(logGroups, start, end);
        List<AggregateStatsMergeService.MergedStatsRow> merged =
                aggregateStatsMergeService.mergeAggregates(rawAggregates);

        log.info(
                "event=cloudwatch_pipeline_merge_complete rawAggregateRows={} mergedRows={}",
                rawAggregates.size(),
                merged.size());

        ManualTriggerResponse response = new ManualTriggerResponse();
        response.setSuccess(true);
        response.setMessage("Completed CloudWatch aggregate query merge");
        response.setWindowStartEpochSeconds(start);
        response.setWindowEndEpochSeconds(end);
        response.setRowCount(merged.size());

        for (AggregateStatsMergeService.MergedStatsRow m : merged) {
            AggregateTriggerRow outcome = aggregateRowBuilder.buildMergedRow(m, start, end);
            response.getRows().add(outcome);
        }

        log.info("event=cloudwatch_pipeline_complete mergedRowCount={}", merged.size());
        return response;
    }

    /**
     * Resolves {@code [start, end]} for the Insights query: configured {@code query.window}, {@code requestWindow},
     * or explicit epoch range.
     */
    long[] validateAndResolveWindow(
            Long startEpochSeconds, Long endEpochSeconds, Duration requestWindow, long nowEpochSeconds) {
        boolean hasStart = startEpochSeconds != null;
        boolean hasEnd = endEpochSeconds != null;
        if (requestWindow != null && (hasStart || hasEnd)) {
            throw new IllegalArgumentException(
                    "Use either window=... (duration) or startEpochSeconds/endEpochSeconds, not both");
        }
        if (hasStart != hasEnd) {
            throw new IllegalArgumentException(
                    "Both startEpochSeconds and endEpochSeconds are required for a custom range (or omit both for the configured window)");
        }
        long start;
        long end;
        if (requestWindow != null) {
            if (requestWindow.isNegative() || requestWindow.isZero()) {
                throw new IllegalArgumentException("window must be a positive duration (e.g. 15m, 2d)");
            }
            long span = requestWindow.toSeconds();
            if (span <= 0) {
                throw new IllegalArgumentException(
                        "window must be at least 1 second; sub-second durations are not supported (value was "
                                + requestWindow
                                + ")");
            }
            end = nowEpochSeconds;
            start = end - span;
            enforceMaxSpan(span, "window query parameter");
        } else if (!hasStart) {
            long configured = properties.getQuery().getWindowSeconds();
            if (configured <= 0) {
                throw new IllegalStateException(
                        "cloudwatchanalyzer.query.window must be positive (e.g. 15m or legacy window-seconds)");
            }
            end = nowEpochSeconds;
            start = end - configured;
            enforceMaxSpan(end - start, "cloudwatchanalyzer.query.window");
        } else {
            start = startEpochSeconds;
            end = endEpochSeconds;
            if (end <= start) {
                throw new IllegalArgumentException("endEpochSeconds must be greater than startEpochSeconds");
            }
            if (end > nowEpochSeconds + FUTURE_END_TOLERANCE_SECONDS) {
                throw new IllegalArgumentException(
                        "endEpochSeconds must not be more than "
                                + FUTURE_END_TOLERANCE_SECONDS
                                + "s in the future (clock skew allowance)");
            }
            enforceMaxSpan(end - start, "requested time range");
        }
        return new long[] {start, end};
    }

    private void enforceMaxSpan(long spanSeconds, String label) {
        long max = properties.getQuery().getMaxWindowSeconds();
        if (max > 0 && spanSeconds > max) {
            throw new IllegalArgumentException(
                    label
                            + " ("
                            + spanSeconds
                            + "s) exceeds cloudwatchanalyzer.query.max-window ("
                            + max
                            + "s). Increase max-window or max-window-seconds if intentional.");
        }
    }

    /**
     * Resolves log groups from YAML + discovery (no request override).
     *
     * @see #resolveLogGroupsForQuery(List)
     */
    public List<String> resolveLogGroupsForQuery() {
        return resolveLogGroupsForQuery(null);
    }

    /**
     * When {@code requestOverrideLogGroups} is non-empty after sanitizing, returns that list (request-body override).
     * Otherwise same as discovery + static fallback documented on {@link #resolveLogGroupsForQuery()}.
     */
    public List<String> resolveLogGroupsForQuery(List<String> requestOverrideLogGroups) {
        if (requestOverrideLogGroups != null && !requestOverrideLogGroups.isEmpty()) {
            List<String> cleaned = sanitizeLogGroupNames(requestOverrideLogGroups);
            if (!cleaned.isEmpty()) {
                if (cleaned.size() > MAX_LOG_GROUPS_PER_QUERY) {
                    throw new IllegalArgumentException(
                            "logGroups in request body exceeds max "
                                    + MAX_LOG_GROUPS_PER_QUERY
                                    + " (CloudWatch Logs Insights limit per query)");
                }
                log.info(
                        "event=log_group_resolution outcome=request_body_override logGroupCount={}",
                        cleaned.size());
                return List.copyOf(cleaned);
            }
        }
        return resolveLogGroupsFromConfiguration();
    }

    /**
     * Resolves log groups for Insights: when {@code query.use-log-group-discovery} is true, runs
     * {@link CloudWatchLogGroupDiscoveryService#discoverLogGroups()}. If that returns empty, falls back to the static
     * {@code query.log-groups} list (same list used when discovery is off) so QA/STG still work when env/suffix naming
     * does not match AWS. When discovery returns at least one name, static entries are not merged (discovery wins).
     */
    private List<String> resolveLogGroupsFromConfiguration() {
        List<String> configured = staticLogGroupsFromConfig();
        if (!properties.getQuery().isUseLogGroupDiscovery()) {
            return configured;
        }
        List<String> discovered = logGroupDiscoveryService.discoverLogGroups();
        if (!discovered.isEmpty()) {
            return discovered;
        }
        if (!configured.isEmpty()) {
            log.warn(
                    "event=log_group_resolution outcome=fallback_static reason=discovery_empty "
                            + "staticLogGroupCount={} hint=Fix CLOUDWATCH_ENV / CLOUDWATCH_LOG_REGION_SUFFIX for discovery, "
                            + "or set query.log-groups for this env, or use-log-group-discovery false",
                    configured.size());
            return configured;
        }
        return List.of();
    }

    private static List<String> sanitizeLogGroupNames(List<String> raw) {
        return raw.stream()
                .filter(s -> s != null && !s.isBlank())
                .map(String::trim)
                .toList();
    }

    private List<String> staticLogGroupsFromConfig() {
        List<String> raw = properties.getQuery().getLogGroups();
        if (raw == null || raw.isEmpty()) {
            return List.of();
        }
        return List.copyOf(
                raw.stream().filter(s -> s != null && !s.isBlank()).map(String::trim).toList());
    }
}
