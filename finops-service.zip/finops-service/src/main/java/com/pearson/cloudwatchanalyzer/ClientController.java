package com.pearson.cloudwatchanalyzer;

import com.pearson.cloudwatchanalyzer.entity.Client;
import com.pearson.cloudwatchanalyzer.repository.ClientRepository;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Controller for client/tenant CRUD operations.
 */
@RestController
@RequestMapping("/clients")
@RequiredArgsConstructor
@Slf4j
public class ClientController {

    private final ClientRepository repository;

    @GetMapping
    public ResponseEntity<List<Client>> getAllClients() {
        log.info("GET all clients");
        return ResponseEntity.ok(repository.findAll());
    }

    @PostMapping
    public ResponseEntity<Client> createClient(@RequestBody Client client) {
        log.info("POST create client: {}", client);
        if (client.getName() == null || client.getName().isBlank()) {
            return ResponseEntity.badRequest().build();
        }
        Client saved = repository.save(client);
        return new ResponseEntity<>(saved, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Client> updateClient(@PathVariable String id, @RequestBody Client client) {
        log.info("PUT update client id: {}, body: {}", id, client);
        Optional<Client> existing = repository.findById(id);
        if (existing.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        Client toSave = existing.get();
        toSave.setName(client.getName());
        toSave.setServices(client.getServices());
        toSave.setAwsRegions(client.getAwsRegions());
        Client saved = repository.save(toSave);
        return ResponseEntity.ok(saved);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteClient(@PathVariable String id) {
        log.info("DELETE client id: {}", id);
        if (!repository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        repository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
