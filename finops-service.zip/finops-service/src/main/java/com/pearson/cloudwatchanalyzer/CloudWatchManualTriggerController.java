package com.pearson.cloudwatchanalyzer;

import com.pearson.cloudwatchanalyzer.dto.CloudWatchTriggerRequestBody;
import com.pearson.cloudwatchanalyzer.dto.ManualTriggerResponse;
import java.time.Duration;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Manually runs the same <strong>aggregated</strong> CloudWatch Insights query
 * ({@link com.pearson.cloudwatchanalyzer.CloudWatchTimeLoggerAggregateInsightsQuery}) and GAIME POST flow as
 * {@link CloudWatchScheduler} via {@link CloudWatchTriggerService}.
 * Useful for local verification with valid AWS credentials.
 *
 * <p>Spec alias: {@link CloudWatchSpecTriggerController} {@code POST /cloudwatch/trigger} (G.2).
 */
@RestController
@RequestMapping("/v1/cloudwatch")
@RequiredArgsConstructor
public class CloudWatchManualTriggerController {

    private final CloudWatchTriggerHttpCoordinator coordinator;

    /**
     * Optional {@code startEpochSeconds} and {@code endEpochSeconds} (Unix epoch seconds) for an absolute range
     * (both required together). Optional {@code window} is a Spring duration string (e.g. {@code 15m}, {@code 2d},
     * {@code PT1H}) for a sliding window ending at now — mutually exclusive with epoch params. Otherwise uses
     * configured {@code cloudwatchanalyzer.query.window}. Span is capped by {@code max-window} unless disabled
     * ({@code 0s} or legacy {@code max-window-seconds: 0}).
     *
     * <p>Optional JSON body overrides log groups for this request only (replaces discovery and YAML): {@code
     * {"logGroups":["/aws/ecs/..."]}}, or for a single group {@code {"logGroupName":"/aws/ecs/..."}}. Non-empty {@code
     * logGroups} takes precedence over {@code logGroupName}.
     */
    @PostMapping("/analytics/trigger")
    public ResponseEntity<ManualTriggerResponse> triggerAnalyticsPipeline(
            @RequestParam(required = false) Long startEpochSeconds,
            @RequestParam(required = false) Long endEpochSeconds,
            @RequestParam(required = false) String window,
            @RequestParam(required = false) String awsRegion,
            @RequestBody(required = false) CloudWatchTriggerRequestBody body) {
        var early = coordinator.preflightManualTrigger();
        if (early.isPresent()) {
            return early.get();
        }
        try {
            Duration requestWindow = parseOptionalWindowParameter(window);
            return coordinator.executePipeline(
                    startEpochSeconds, endEpochSeconds, requestWindow, awsRegion, logGroupsFromBody(body));
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().body(ManualTriggerResponse.failure(ex.getMessage()));
        }
    }

    static List<String> logGroupsFromBody(CloudWatchTriggerRequestBody body) {
        if (body == null) {
            return null;
        }
        List<String> groups = body.getLogGroups();
        if (groups != null && !groups.isEmpty()) {
            return groups;
        }
        String single = body.getLogGroupName();
        if (single != null && !single.isBlank()) {
            return List.of(single.trim());
        }
        return null;
    }

    /**
     * Parses {@code window} query values like {@code 15m}, {@code 2d}, {@code 1h}, or ISO-8601 {@code PT15M}.
     *
     * @return null when absent or blank
     */
    static Duration parseOptionalWindowParameter(String window) {
        if (window == null || window.isBlank()) {
            return null;
        }
        String trimmed = window.trim();
        try {
            return org.springframework.boot.convert.DurationStyle.SIMPLE.parse(trimmed);
        } catch (IllegalArgumentException ignored) {
            // Fall through
        }
        try {
            return Duration.parse(trimmed);
        } catch (Exception ex) {
            throw new IllegalArgumentException(
                    "Invalid window '"
                            + trimmed
                            + "': use Spring simple form (e.g. 15m, 2d, 1h) or ISO-8601 duration (e.g. PT15M)",
                    ex);
        }
    }
}
