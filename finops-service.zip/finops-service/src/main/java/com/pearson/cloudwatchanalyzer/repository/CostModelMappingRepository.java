package com.pearson.cloudwatchanalyzer.repository;

import com.pearson.cloudwatchanalyzer.entity.CostModelMapping;
import java.util.List;
import java.util.Optional;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

/**
 * MongoDB repository for client-specific cost model configurations.
 */
@Repository
public interface CostModelMappingRepository extends MongoRepository<CostModelMapping, String> {

    List<CostModelMapping> findByClientId(String clientId);

    Optional<CostModelMapping> findByClientIdAndIdentityKey(String clientId, String identityKey);
}
