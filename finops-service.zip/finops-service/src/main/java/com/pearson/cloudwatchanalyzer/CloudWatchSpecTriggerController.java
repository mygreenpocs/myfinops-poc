package com.pearson.cloudwatchanalyzer;

import com.pearson.cloudwatchanalyzer.dto.CloudWatchSpecTriggerResponse;
import com.pearson.cloudwatchanalyzer.dto.CloudWatchTriggerRequestBody;
import com.pearson.cloudwatchanalyzer.dto.ManualTriggerResponse;
import java.time.Duration;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Spec contract (Epic G.2): {@code POST /cloudwatch/trigger} with {@code payloads} and {@code rowDetails}. Query range:
 * prefer {@code startTimeSeconds}/{@code endTimeSeconds}; legacy {@code
 * startEpochSeconds}/{@code endEpochSeconds} accepted when spec pair is not used (mutually exclusive).
 */
@RestController
@RequestMapping("/cloudwatch")
@RequiredArgsConstructor
public class CloudWatchSpecTriggerController {

    private final CloudWatchTriggerHttpCoordinator coordinator;

    @PostMapping("/trigger")
    public ResponseEntity<CloudWatchSpecTriggerResponse> trigger(
            @RequestParam(required = false) Long startTimeSeconds,
            @RequestParam(required = false) Long endTimeSeconds,
            @RequestParam(required = false) Long startEpochSeconds,
            @RequestParam(required = false) Long endEpochSeconds,
            @RequestParam(required = false) String window,
            @RequestBody(required = false) CloudWatchTriggerRequestBody body) {
        return SpecTriggerSupport.execute(
                coordinator,
                startTimeSeconds,
                endTimeSeconds,
                startEpochSeconds,
                endEpochSeconds,
                window,
                CloudWatchManualTriggerController.logGroupsFromBody(body));
    }

    /** Shared logic for tests without standing up the full controller. */
    static final class SpecTriggerSupport {
        private SpecTriggerSupport() {}

        static ResponseEntity<CloudWatchSpecTriggerResponse> execute(
                CloudWatchTriggerHttpCoordinator coordinator,
                Long startTimeSeconds,
                Long endTimeSeconds,
                Long startEpochSeconds,
                Long endEpochSeconds,
                String window,
                List<String> requestOverrideLogGroups) {
            var early = coordinator.preflightManualTrigger();
            if (early.isPresent()) {
                return map(early.get());
            }
            try {
                Duration requestWindow = CloudWatchManualTriggerController.parseOptionalWindowParameter(window);
                Long[] epoch =
                        CloudWatchSpecEpochParams.resolve(
                                startTimeSeconds, endTimeSeconds, startEpochSeconds, endEpochSeconds);
                return map(
                        coordinator.executePipeline(epoch[0], epoch[1], requestWindow, requestOverrideLogGroups));
            } catch (IllegalArgumentException ex) {
                return ResponseEntity.badRequest()
                        .body(CloudWatchSpecTriggerResponse.from(ManualTriggerResponse.failure(ex.getMessage())));
            }
        }

        private static ResponseEntity<CloudWatchSpecTriggerResponse> map(
                ResponseEntity<ManualTriggerResponse> entity) {
            CloudWatchSpecTriggerResponse spec = CloudWatchSpecTriggerResponse.from(entity.getBody());
            return ResponseEntity.status(entity.getStatusCode()).headers(entity.getHeaders()).body(spec);
        }
    }
}
