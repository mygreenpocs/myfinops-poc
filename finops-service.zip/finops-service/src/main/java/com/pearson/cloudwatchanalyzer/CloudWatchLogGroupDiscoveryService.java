package com.pearson.cloudwatchanalyzer;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.cloudwatchlogs.CloudWatchLogsClient;
import software.amazon.awssdk.services.cloudwatchlogs.model.DescribeLogGroupsRequest;
import software.amazon.awssdk.services.cloudwatchlogs.model.DescribeLogGroupsResponse;
import software.amazon.awssdk.services.cloudwatchlogs.model.LogGroup;

/**
 * Resolves ECS log group names matching {@code /aws/ecs/{env}-{service}-svc-*-{region}} using
 * {@link CloudWatchLogsClient#describeLogGroups}.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CloudWatchLogGroupDiscoveryService {

    private final CloudWatchLogsClient cloudWatchLogsClient;
    private final CloudWatchAnalyzerProperties properties;

    /**
     * For each configured service name, lists log groups with prefix {@code /aws/ecs/{env}-{service}-svc-}
     * and keeps only names ending with {@code -{region}} (e.g. {@code -use1}).
     *
     * @return distinct names in discovery order (service order, then API order); never null
     */
    public List<String> discoverLogGroups() {
        String env = properties.getEnv() != null ? properties.getEnv().trim() : "";
        String regionSuffix = properties.getRegion() != null ? properties.getRegion().trim() : "";
        String requiredSuffix = regionSuffix.isEmpty() ? "" : "-" + regionSuffix;

        List<String> services = properties.getLogGroup().getServices();
        if (services == null || services.isEmpty()) {
            log.warn("No cloudwatchanalyzer.log-group.services configured; discovery returns empty list");
            return List.of();
        }

        Set<String> distinct = new LinkedHashSet<>();
        for (String service : services) {
            if (service == null || service.isBlank()) {
                continue;
            }
            String svc = service.trim();
            String prefix = String.format("/aws/ecs/%s-%s-svc-", env, svc);
            List<String> forService = listAllWithPrefix(prefix);
            for (String name : forService) {
                if (requiredSuffix.isEmpty() || name.endsWith(requiredSuffix)) {
                    distinct.add(name);
                } else {
                    log.debug("Skipping log group (suffix mismatch): {}", name);
                }
            }
        }

        log.info(
                "Discovered {} log group(s) for env={}, regionSuffix={}, services={}",
                distinct.size(),
                env,
                regionSuffix,
                services);
        return new ArrayList<>(distinct);
    }

    private List<String> listAllWithPrefix(String prefix) {
        List<String> names = new ArrayList<>();
        String nextToken = null;
        do {
            DescribeLogGroupsRequest.Builder b =
                    DescribeLogGroupsRequest.builder().logGroupNamePrefix(prefix).limit(50);
            if (nextToken != null) {
                b.nextToken(nextToken);
            }
            DescribeLogGroupsResponse response = cloudWatchLogsClient.describeLogGroups(b.build());
            for (LogGroup lg : response.logGroups()) {
                if (lg.logGroupName() != null) {
                    names.add(lg.logGroupName());
                }
            }
            nextToken = response.nextToken();
        } while (nextToken != null);
        return names;
    }
}
