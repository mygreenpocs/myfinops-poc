package com.pearson.cloudwatchanalyzer.dto;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Spec-shaped JSON for {@code POST /cloudwatch/trigger}: per-row dimension echoes from the pipeline (no external
 * analytics HTTP).
 */
public class CloudWatchSpecTriggerResponse {

    private boolean success;
    private String message;
    private String awsErrorCode;
    private String troubleshootingHint;
    private long windowStartEpochSeconds;
    private long windowEndEpochSeconds;
    private int rowCount;
    private final List<AggregateRowDetail> rowDetails = new ArrayList<>();

    public static CloudWatchSpecTriggerResponse from(ManualTriggerResponse source) {
        CloudWatchSpecTriggerResponse r = new CloudWatchSpecTriggerResponse();
        if (source == null) {
            r.success = false;
            r.message = "No response body";
            return r;
        }
        r.success = source.isSuccess();
        r.message = source.getMessage();
        r.awsErrorCode = source.getAwsErrorCode();
        r.troubleshootingHint = source.getTroubleshootingHint();
        r.windowStartEpochSeconds = source.getWindowStartEpochSeconds();
        r.windowEndEpochSeconds = source.getWindowEndEpochSeconds();
        r.rowCount = source.getRowCount();
        for (AggregateTriggerRow row : source.getRows()) {
            r.rowDetails.add(AggregateRowDetail.from(row));
        }
        return r;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getAwsErrorCode() {
        return awsErrorCode;
    }

    public void setAwsErrorCode(String awsErrorCode) {
        this.awsErrorCode = awsErrorCode;
    }

    public String getTroubleshootingHint() {
        return troubleshootingHint;
    }

    public void setTroubleshootingHint(String troubleshootingHint) {
        this.troubleshootingHint = troubleshootingHint;
    }

    public long getWindowStartEpochSeconds() {
        return windowStartEpochSeconds;
    }

    public void setWindowStartEpochSeconds(long windowStartEpochSeconds) {
        this.windowStartEpochSeconds = windowStartEpochSeconds;
    }

    public long getWindowEndEpochSeconds() {
        return windowEndEpochSeconds;
    }

    public void setWindowEndEpochSeconds(long windowEndEpochSeconds) {
        this.windowEndEpochSeconds = windowEndEpochSeconds;
    }

    public int getRowCount() {
        return rowCount;
    }

    public void setRowCount(int rowCount) {
        this.rowCount = rowCount;
    }

    public List<AggregateRowDetail> getRowDetails() {
        return rowDetails;
    }

    /** Per-row structured echo of merge/query dimensions (spec consumer). */
    public static class AggregateRowDetail {

        private CloudWatchDimensions cloudWatchDimensions = new CloudWatchDimensions();

        public static AggregateRowDetail from(AggregateTriggerRow g) {
            AggregateRowDetail s = new AggregateRowDetail();
            if (g.getCloudWatchRow() != null) {
                s.cloudWatchDimensions = CloudWatchDimensions.fromFlatMap(g.getCloudWatchRow());
            }
            return s;
        }

        public CloudWatchDimensions getCloudWatchDimensions() {
            return cloudWatchDimensions;
        }

        public void setCloudWatchDimensions(CloudWatchDimensions cloudWatchDimensions) {
            this.cloudWatchDimensions =
                    cloudWatchDimensions != null ? cloudWatchDimensions : new CloudWatchDimensions();
        }
    }

    /** Mirrors the simplified {@code cloudWatchRow} map from {@link AggregateTriggerRow}. */
    public static class CloudWatchDimensions {
        private String patternUrl;
        private String status;
        private String count;
        private String totalOutputSize;
        private String serviceName;
        private String logGroupName;
        private String systemName;
        private String clientIp;
        private String windowStart;
        private String windowEnd;

        static CloudWatchDimensions fromFlatMap(java.util.Map<String, String> m) {
            CloudWatchDimensions d = new CloudWatchDimensions();
            if (m == null) {
                return d;
            }
            d.patternUrl = m.get("patternUrl");
            d.status = m.get("status");
            d.count = m.get("count");
            d.totalOutputSize = m.get("totalOutputSize");
            d.serviceName = m.get("serviceName");
            d.logGroupName = m.get("logGroupName");
            d.systemName = m.get("systemName");
            d.clientIp = m.get("clientIp");
            d.windowStart = m.get("windowStart");
            d.windowEnd = m.get("windowEnd");
            return d;
        }

        public String getPatternUrl() {
            return patternUrl;
        }

        public void setPatternUrl(String patternUrl) {
            this.patternUrl = patternUrl;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getCount() {
            return count;
        }

        public void setCount(String count) {
            this.count = count;
        }

        public String getTotalOutputSize() {
            return totalOutputSize;
        }

        public void setTotalOutputSize(String totalOutputSize) {
            this.totalOutputSize = totalOutputSize;
        }

        public String getServiceName() {
            return serviceName;
        }

        public void setServiceName(String serviceName) {
            this.serviceName = serviceName;
        }

        public String getLogGroupName() {
            return logGroupName;
        }

        public void setLogGroupName(String logGroupName) {
            this.logGroupName = logGroupName;
        }

        public String getSystemName() {
            return systemName;
        }

        public void setSystemName(String systemName) {
            this.systemName = systemName;
        }

        public String getClientIp() {
            return clientIp;
        }

        public void setClientIp(String clientIp) {
            this.clientIp = clientIp;
        }

        public String getWindowStart() {
            return windowStart;
        }

        public void setWindowStart(String windowStart) {
            this.windowStart = windowStart;
        }

        public String getWindowEnd() {
            return windowEnd;
        }

        public void setWindowEnd(String windowEnd) {
            this.windowEnd = windowEnd;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }
            CloudWatchDimensions that = (CloudWatchDimensions) o;
            return Objects.equals(patternUrl, that.patternUrl)
                    && Objects.equals(status, that.status)
                    && Objects.equals(count, that.count)
                    && Objects.equals(totalOutputSize, that.totalOutputSize)
                    && Objects.equals(serviceName, that.serviceName)
                    && Objects.equals(logGroupName, that.logGroupName)
                    && Objects.equals(systemName, that.systemName)
                    && Objects.equals(clientIp, that.clientIp)
                    && Objects.equals(windowStart, that.windowStart)
                    && Objects.equals(windowEnd, that.windowEnd);
        }

        @Override
        public int hashCode() {
            return Objects.hash(
                    patternUrl,
                    status,
                    count,
                    totalOutputSize,
                    serviceName,
                    logGroupName,
                    systemName,
                    clientIp,
                    windowStart,
                    windowEnd);
        }
    }
}
