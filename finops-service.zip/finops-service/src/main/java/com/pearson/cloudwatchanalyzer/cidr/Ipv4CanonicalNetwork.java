package com.pearson.cloudwatchanalyzer.cidr;

import java.net.Inet4Address;

/**
 * Canonical IPv4 network strings for aggregation (e.g. unknown-IP bucketing in {@link
 * com.pearson.cloudwatchanalyzer.AggregateStatsMergeService}).
 */
public final class Ipv4CanonicalNetwork {

    private Ipv4CanonicalNetwork() {}

    /**
     * Returns the canonical network CIDR for {@code ipv4Host} at {@code prefixLength} (e.g. {@code 10.12.3.4} at 16 →
     * {@code 10.12.0.0/16}).
     *
     * @return {@code null} if {@code ipv4Host} is not a lone IPv4 address
     */
    public static String networkCidr(String ipv4Host, int prefixLength) {
        if (ipv4Host == null || ipv4Host.isBlank()) {
            return null;
        }
        if (prefixLength < 0 || prefixLength > 32) {
            throw new IllegalArgumentException("prefixLength must be 0..32: " + prefixLength);
        }
        try {
            Inet4Address ip = Ipv4Cidr.parseIpv4Only(ipv4Host);
            long ipL = Ipv4Cidr.ipv4ToUnsignedLong(ip);
            long mask = prefixLength == 0 ? 0L : (0xffffffffL << (32 - prefixLength)) & 0xffffffffL;
            long network = (ipL & mask) & 0xffffffffL;
            return formatDotted(network) + "/" + prefixLength;
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    private static String formatDotted(long network) {
        return ((network >>> 24) & 0xff)
                + "."
                + ((network >>> 16) & 0xff)
                + "."
                + ((network >>> 8) & 0xff)
                + "."
                + (network & 0xff);
    }
}
