package com.pearson.cloudwatchanalyzer;

import com.pearson.cloudwatchanalyzer.dto.ManualTriggerResponse;
import java.time.Duration;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import software.amazon.awssdk.awscore.exception.AwsServiceException;

/**
 * Shared HTTP handling for manual CloudWatch aggregate triggers ({@code /v1/cloudwatch/analytics/trigger} and spec
 * {@code /cloudwatch/trigger}).
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class CloudWatchTriggerHttpCoordinator {

    public static final String CREDENTIALS_HINT =
            "The Java process must use the same AWS identity as your CLI. If `aws s3 ls` works in CMD but this fails: "
                    + "(1) Start the app from that same CMD (same AWS_PROFILE / env vars), or "
                    + "(2) Set cloudwatchanalyzer.aws.profile in application-local.yml to your profile name, or "
                    + "(3) Add AWS_PROFILE (and SSO login if used) to your IDE Run Configuration. "
                    + "For AWS SSO: run `aws sso login` when the token expires — with a named profile, `RefreshingProfileCredentialsProvider` re-resolves credentials on each CloudWatch call (see `cloudwatchanalyzer.aws.refresh-credentials-each-request`, default true). "
                    + "Also note: S3 permissions are separate from CloudWatch Logs — you need logs:StartQuery, "
                    + "logs:GetQueryResults (and typically logs:DescribeLogGroups) on the configured log groups.";

    private final Optional<CloudWatchTriggerService> cloudWatchTriggerService;
    private final CloudWatchAnalyzerProperties properties;

    /**
     * @return non-empty when the caller should return immediately (503 preflight failures).
     */
    public Optional<ResponseEntity<ManualTriggerResponse>> preflightManualTrigger() {
        if (!properties.isEnabled()) {
            return Optional.of(
                    ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                            .body(ManualTriggerResponse.failure("cloudwatchanalyzer.enabled is false")));
        }
        if (!properties.getTrigger().isEnabled()) {
            ManualTriggerResponse body =
                    ManualTriggerResponse.failure(
                            "Manual CloudWatch trigger is disabled (cloudwatchanalyzer.trigger.enabled=false). "
                                    + "Set it to true to run the pipeline from this endpoint; CIDR mapping APIs are unaffected.");
            body.setTroubleshootingHint(
                    "For local dev, enable trigger in application-local.yml or env CLOUDWATCH_TRIGGER_ENABLED=true.");
            return Optional.of(ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(body));
        }
        if (cloudWatchTriggerService.isEmpty()) {
            log.debug("event=cloudwatch_trigger_preflight outcome=blocked reason=pipeline_bean_absent");
            ManualTriggerResponse body =
                    ManualTriggerResponse.failure(
                            "CloudWatch aggregate pipeline is not available: CloudWatchTriggerService is not registered. "
                                    + "Enable cloudwatchanalyzer.enabled and cloudwatchanalyzer.aws.enabled (both true). "
                                    + "CIDR mapping APIs are unaffected.");
            body.setTroubleshootingHint(
                    "If you turned off aws.enabled for local safety, set cloudwatchanalyzer.aws.enabled=true to use this endpoint.");
            return Optional.of(ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(body));
        }
        return Optional.empty();
    }

    public ResponseEntity<ManualTriggerResponse> executePipeline(
            Long startEpochSeconds, Long endEpochSeconds, Duration requestWindow, String awsRegion, List<String> requestOverrideLogGroups) {
        try {
            ManualTriggerResponse body =
                    cloudWatchTriggerService
                            .get()
                            .runOnce(startEpochSeconds, endEpochSeconds, requestWindow, awsRegion, requestOverrideLogGroups);
            log.info(
                    "event=cloudwatch_http_trigger_complete outcome=ok httpStatus=200 rowCount={}",
                    body.getRowCount());
            return ResponseEntity.ok(body);
        } catch (IllegalArgumentException ex) {
            log.warn("event=cloudwatch_http_trigger_rejected outcome=400 reason=validation message={}", ex.getMessage());
            return ResponseEntity.badRequest().body(ManualTriggerResponse.failure(ex.getMessage()));
        } catch (IllegalStateException ex) {
            log.warn("event=cloudwatch_http_trigger_rejected outcome=400 reason=state message={}", ex.getMessage());
            return ResponseEntity.badRequest().body(ManualTriggerResponse.failure(ex.getMessage()));
        } catch (Exception ex) {
            log.error("event=cloudwatch_http_trigger_failed outcome=500", ex);
            AwsServiceException aws = findAwsCause(ex);
            if (aws != null) {
                ManualTriggerResponse body = ManualTriggerResponse.failure(formatAwsMessage(aws));
                if (aws.awsErrorDetails() != null) {
                    body.setAwsErrorCode(aws.awsErrorDetails().errorCode());
                }
                body.setTroubleshootingHint(CREDENTIALS_HINT);
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(body);
            }
            ManualTriggerResponse body = ManualTriggerResponse.failure(ex.getMessage());
            body.setTroubleshootingHint(CREDENTIALS_HINT);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(body);
        }
    }

    private static AwsServiceException findAwsCause(Throwable ex) {
        Throwable t = ex;
        while (t != null) {
            if (t instanceof AwsServiceException ase) {
                return ase;
            }
            t = t.getCause();
        }
        return null;
    }

    private static String formatAwsMessage(AwsServiceException ex) {
        if (ex.awsErrorDetails() != null) {
            return ex.awsErrorDetails().errorCode() + ": " + ex.awsErrorDetails().errorMessage();
        }
        return ex.getClass().getSimpleName() + ": " + ex.getMessage();
    }
}
