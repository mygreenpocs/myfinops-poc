package com.pearson.cloudwatchanalyzer.dto;

public class AnalyticsResponse {
    private String id;
    private String nrTraceId;
    private String amznTraceId;
    private String method;
    private String endpoint;
    private Integer status;
    private Integer responseTimeMs;
    private Integer inputSize;
    private Integer outputSize;
    private String prsnUserId;
    private String createdAt;
    private String xappId;
    private String xtraceId;

    public AnalyticsResponse() {}

    public AnalyticsResponse(String id, String nrTraceId, String amznTraceId, String method, String endpoint, Integer status, Integer responseTimeMs, Integer inputSize, Integer outputSize, String prsnUserId, String createdAt, String xappId, String xtraceId) {
        this.id = id;
        this.nrTraceId = nrTraceId;
        this.amznTraceId = amznTraceId;
        this.method = method;
        this.endpoint = endpoint;
        this.status = status;
        this.responseTimeMs = responseTimeMs;
        this.inputSize = inputSize;
        this.outputSize = outputSize;
        this.prsnUserId = prsnUserId;
        this.createdAt = createdAt;
        this.xappId = xappId;
        this.xtraceId = xtraceId;
    }

    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getNrTraceId() { return nrTraceId; }
    public void setNrTraceId(String nrTraceId) { this.nrTraceId = nrTraceId; }

    public String getAmznTraceId() { return amznTraceId; }
    public void setAmznTraceId(String amznTraceId) { this.amznTraceId = amznTraceId; }

    public String getMethod() { return method; }
    public void setMethod(String method) { this.method = method; }

    public String getEndpoint() { return endpoint; }
    public void setEndpoint(String endpoint) { this.endpoint = endpoint; }

    public Integer getStatus() { return status; }
    public void setStatus(Integer status) { this.status = status; }

    public Integer getResponseTimeMs() { return responseTimeMs; }
    public void setResponseTimeMs(Integer responseTimeMs) { this.responseTimeMs = responseTimeMs; }

    public Integer getInputSize() { return inputSize; }
    public void setInputSize(Integer inputSize) { this.inputSize = inputSize; }

    public Integer getOutputSize() { return outputSize; }
    public void setOutputSize(Integer outputSize) { this.outputSize = outputSize; }

    public String getPrsnUserId() { return prsnUserId; }
    public void setPrsnUserId(String prsnUserId) { this.prsnUserId = prsnUserId; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }

    public String getXappId() { return xappId; }
    public void setXappId(String xappId) { this.xappId = xappId; }

    public String getXtraceId() { return xtraceId; }
    public void setXtraceId(String xtraceId) { this.xtraceId = xtraceId; }

    @Override
    public String toString() {
        return "AnalyticsResponse{" +
                "id='" + id + '\'' +
                ", nrTraceId='" + nrTraceId + '\'' +
                ", amznTraceId='" + amznTraceId + '\'' +
                ", method='" + method + '\'' +
                ", endpoint='" + endpoint + '\'' +
                ", status=" + status +
                ", responseTimeMs=" + responseTimeMs +
                ", inputSize=" + inputSize +
                ", outputSize=" + outputSize +
                ", prsnUserId='" + prsnUserId + '\'' +
                ", createdAt='" + createdAt + '\'' +
                ", xappId='" + xappId + '\'' +
                ", xtraceId='" + xtraceId + '\'' +
                '}';
    }
}
