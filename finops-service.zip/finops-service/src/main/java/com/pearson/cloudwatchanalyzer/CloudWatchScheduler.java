package com.pearson.cloudwatchanalyzer;

import com.pearson.cloudwatchanalyzer.dto.ManualTriggerResponse;
import jakarta.annotation.PostConstruct;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@ConditionalOnProperty(prefix = "cloudwatchanalyzer.scheduler", name = "enabled", havingValue = "true", matchIfMissing = true)
public class CloudWatchScheduler {

    private static final Logger logger = LoggerFactory.getLogger(CloudWatchScheduler.class);

    private final Optional<CloudWatchTriggerService> cloudWatchTriggerService;
    private final CloudWatchAnalyzerProperties properties;

    @PostConstruct
    public void init() {
        logger.info(
                "CloudWatchScheduler initialized (interval={}, env={}, logGroupRegionSuffix={}, useLogGroupDiscovery={}, staticLogGroups={})",
                properties.getScheduler().getInterval(),
                properties.getEnv(),
                properties.getRegion(),
                properties.getQuery().isUseLogGroupDiscovery(),
                properties.getQuery().getLogGroups());
    }

    @Scheduled(fixedDelayString = "${cloudwatchanalyzer.scheduler.interval}")
    public void runScheduledQuery() {
        if (!properties.isEnabled()) {
            logger.debug("Skipping scheduled CloudWatch run: cloudwatchanalyzer.enabled is false");
            return;
        }
        if (cloudWatchTriggerService.isEmpty()) {
            logger.debug(
                    "Skipping scheduled CloudWatch run: CloudWatchTriggerService not registered "
                            + "(cloudwatchanalyzer.enabled=false and/or cloudwatchanalyzer.aws.enabled=false)");
            return;
        }
        try {
            logger.info("event=cloudwatch_scheduled_run_start");
            ManualTriggerResponse result = cloudWatchTriggerService.get().runOnce();
            logger.info(
                    "event=cloudwatch_scheduled_run_complete outcome=ok rowCount={} windowEpochStart={} windowEpochEnd={}",
                    result.getRowCount(),
                    result.getWindowStartEpochSeconds(),
                    result.getWindowEndEpochSeconds());
        } catch (Exception e) {
            logger.error("event=cloudwatch_scheduled_run_failed outcome=error", e);
        }
    }
}
