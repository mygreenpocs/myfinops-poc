package com.pearson.cloudwatchanalyzer.cidr;

import com.google.common.net.InetAddresses;
import java.net.Inet4Address;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

/**
 * Resolves a {@code source} dimension from CloudWatch aggregate rows to a CIDR / application label for Epic F merge.
 *
 * <p>Rules are evaluated in ascending {@link CidrRule#getSortOrder()}; the first CIDR that contains the IPv4 address
 * wins (use tighter/more-specific blocks with lower {@code sortOrder} when ranges overlap).
 *
 * <p>Non-IPv4 values (hostnames, literals, blank, {@code NA}) → {@link CidrMatchResult.Kind#NON_IPV4}. Unmatched IPv4 →
 * {@link CidrMatchResult.Kind#UNKNOWN} ({@code applicationName} {@code other}).
 */
public final class CidrMatcher {

    private final List<RuleEntry> entries;

    private CidrMatcher(List<RuleEntry> entries) {
        this.entries = entries;
    }

    /**
     * @param rules copied and sorted by {@code sortOrder} ascending (stable for equal orders)
     */
    public static CidrMatcher fromRules(List<CidrRule> rules) {
        Objects.requireNonNull(rules, "rules");
        List<RuleEntry> list = new ArrayList<>(rules.size());
        for (CidrRule r : rules) {
            list.add(new RuleEntry(r, Ipv4Cidr.parse(r.getCidrBlock())));
        }
        list.sort(Comparator.comparingInt((RuleEntry e) -> e.rule.getSortOrder()).thenComparing(e -> e.rule.getCidrBlock()));
        return new CidrMatcher(List.copyOf(list));
    }

    public CidrMatchResult resolve(String source) {
        if (source == null || source.trim().isEmpty() || Ipv4Cidr.looksLikeNaSentinel(source)) {
            return CidrMatchResult.nonIpv4(source == null ? "" : source);
        }
        String trimmed = source.trim();
        final Inet4Address ip;
        try {
            ip = Ipv4Cidr.parseIpv4Only(trimmed);
        } catch (IllegalArgumentException ex) {
            return CidrMatchResult.nonIpv4(trimmed);
        }
        for (RuleEntry e : entries) {
            if (Ipv4Cidr.contains(e.parsed, ip)) {
                return CidrMatchResult.matched(e.rule.getCidrBlock(), e.rule.getApplicationName(), trimmed);
            }
        }
        return CidrMatchResult.unknown(trimmed);
    }

    private static final class RuleEntry {
        final CidrRule rule;
        final Ipv4Cidr.Parsed parsed;

        RuleEntry(CidrRule rule, Ipv4Cidr.Parsed parsed) {
            this.rule = rule;
            this.parsed = parsed;
        }
    }
}