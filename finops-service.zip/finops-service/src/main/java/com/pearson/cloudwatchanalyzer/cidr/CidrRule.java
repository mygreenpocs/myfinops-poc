package com.pearson.cloudwatchanalyzer.cidr;

import java.util.Objects;

/**
 * One CIDR → application mapping in {@link CidrMatcher} evaluation order (see {@link #sortOrder()}).
 *
 * <p>A bare IPv4 (no {@code /prefix}) is normalized to {@code /32} (single-host grouping).
 */
public final class CidrRule {

    private final String cidrBlock;
    private final String applicationName;
    private final int sortOrder;

    public CidrRule(String cidrBlock, String applicationName, int sortOrder) {
        Objects.requireNonNull(cidrBlock, "cidrBlock");
        this.applicationName = Objects.requireNonNull(applicationName, "applicationName").trim();
        this.sortOrder = sortOrder;
        if (this.applicationName.isEmpty()) {
            throw new IllegalArgumentException("applicationName must be non-blank");
        }
        this.cidrBlock = Ipv4Cidr.normalizeCidrWithDefaultPrefix(cidrBlock);
        Ipv4Cidr.validateCidrSyntax(this.cidrBlock);
    }

    public String getCidrBlock() {
        return cidrBlock;
    }

    public String getApplicationName() {
        return applicationName;
    }

    public int getSortOrder() {
        return sortOrder;
    }
}
