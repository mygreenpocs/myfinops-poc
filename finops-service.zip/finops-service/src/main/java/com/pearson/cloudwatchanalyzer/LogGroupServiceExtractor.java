package com.pearson.cloudwatchanalyzer;

/**
 * Derives the ECS **service key** (e.g. {@code usrsrh}) from a full log group name like
 * {@code /aws/ecs/{env}-{service}-svc-01-use1} using {@link CloudWatchAnalyzerProperties#getEnv()}.
 */
public final class LogGroupServiceExtractor {

    private LogGroupServiceExtractor() {}

    /**
     * @param logGroupName full log group from Insights {@code @log} (e.g. {@code /aws/ecs/gps-qa-usrsrh-svc-01-use1})
     * @param env ECS env segment from config (e.g. {@code gps-qa})
     * @return service key before {@code -svc-}, or empty string if not parseable
     */
    public static String extractServiceKey(String logGroupName, String env) {
        if (logGroupName == null || logGroupName.isBlank() || env == null || env.isBlank()) {
            return "";
        }
        String trimmed = logGroupName.trim();
        // Insights @log sometimes returns "accountId:/aws/ecs/..." — strip optional numeric prefix.
        int colon = trimmed.indexOf(':');
        if (colon > 0 && colon < trimmed.length() - 1) {
            String maybeAcct = trimmed.substring(0, colon);
            if (maybeAcct.chars().allMatch(Character::isDigit) && trimmed.charAt(colon + 1) == '/') {
                trimmed = trimmed.substring(colon + 1).trim();
            }
        }
        String prefix = "/aws/ecs/" + env.trim() + "-";
        if (!trimmed.startsWith(prefix)) {
            return "";
        }
        String afterPrefix = trimmed.substring(prefix.length());
        int svcMarker = afterPrefix.indexOf("-svc-");
        if (svcMarker <= 0) {
            return "";
        }
        return afterPrefix.substring(0, svcMarker);
    }
}
