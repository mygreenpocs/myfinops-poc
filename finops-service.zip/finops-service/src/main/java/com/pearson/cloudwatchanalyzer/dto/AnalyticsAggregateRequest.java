package com.pearson.cloudwatchanalyzer.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.time.Instant;

/**
 * Aggregate payload shape for one merged TimeLogger stats row (returned by the CloudWatch trigger API):
 * {@code stats ... by source, patternUrl, status, @log} (see {@code CloudWatchTimeLoggerAggregateInsightsQuery}).
 *
 * <p>Field names are camelCase for JSON. After CIDR merge (Epic F.1), {@code source} is the GAIME-facing dimension:
 * matched CIDR string, {@code other} for unknown IPv4, or the original non-IP source.
 *
 * <p>{@code logGroupName} is the raw Insights {@code @log} value when present.
 *
 * <p>Service / caller identity (JSON strings, omitted when empty via {@link JsonInclude.Include#NON_EMPTY}):
 * <ul>
 *   <li>{@code source} — GAIME network dimension (CIDR, {@code other}, or passthrough); never concatenated into other
 *       fields
 *   <li>{@code logGroupService} — ECS service key from Insights {@code @log} (e.g. {@code usrsrh})
 *   <li>{@code serviceName} — same as {@code logGroupService} when known (explicit “service” label for consumers)
 *   <li>{@code systemName} — separate from service: CIDR <strong>application</strong> mapping name when matched; for
 *       unknown IPv4 buckets often {@code other} (see {@code cidrBlock} for the network); for non-IPv4 the original
 *       source string
 *   <li>{@code cidrBlock} — matched CIDR from mapping, or canonical network for unknown IPv4 (e.g. {@code /16}; omitted
 *       when empty)
 * </ul>
 *
 * <p>{@code windowStart} / {@code windowEnd} are the CloudWatch Insights query window (ISO-8601 in JSON).
 */
public class AnalyticsAggregateRequest {

    private String source;
    private String patternUrl;
    private String status;
    private long count;
    private long totalOutputSize;
    /** Inclusive start of the Insights window for this trigger run (JSON: ISO-8601 instant). */
    private Instant windowStart;
    /** End of the Insights window for this trigger run (JSON: ISO-8601 instant). */
    private Instant windowEnd;
    /** Full log group name from Insights {@code @log}. */
    private String logGroupName;
    /** ECS service key for this row (e.g. {@code usrsrh}). */
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private String logGroupService;
    /** Same as {@link #logGroupService} when known (explicit service label). */
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private String serviceName;
    /**
     * Caller / mapping identity — not the ECS service. See {@link AnalyticsAggregateRequest} class Javadoc.
     */
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private String systemName;
    /** Matched rule CIDR, or canonical network for unknown IPv4 (prefix from config); omitted when blank. */
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private String cidrBlock;

    public AnalyticsAggregateRequest() {}

    public AnalyticsAggregateRequest(String source, String patternUrl, String status, long count, long totalOutputSize) {
        this.source = source;
        this.patternUrl = patternUrl;
        this.status = status;
        this.count = count;
        this.totalOutputSize = totalOutputSize;
    }

    /**
     * @param windowStartEpochSeconds Insights query window start (epoch seconds)
     * @param windowEndEpochSeconds Insights query window end (epoch seconds)
     * @param payloadSystemName {@code systemName} from {@link com.pearson.cloudwatchanalyzer.AggregateStatsMergeService}
     */
    public static AnalyticsAggregateRequest from(
            AggregateStatsRow row,
            long windowStartEpochSeconds,
            long windowEndEpochSeconds,
            String payloadSystemName) {
        return from(row, windowStartEpochSeconds, windowEndEpochSeconds, payloadSystemName, null);
    }

    /**
     * @param cidrBlockForPayload matched CIDR or unknown-IPv4 network CIDR; null/blank omitted from JSON
     */
    public static AnalyticsAggregateRequest from(
            AggregateStatsRow row,
            long windowStartEpochSeconds,
            long windowEndEpochSeconds,
            String payloadSystemName,
            String cidrBlockForPayload) {
        AnalyticsAggregateRequest r =
                new AnalyticsAggregateRequest(
                        row.getSource(), row.getPatternUrl(), row.getStatus(), row.getCount(), row.getTotalOutputSize());
        r.setWindowStart(Instant.ofEpochSecond(windowStartEpochSeconds));
        r.setWindowEnd(Instant.ofEpochSecond(windowEndEpochSeconds));
        r.setLogGroupName(row.getLogGroupName());
        String svc = row.getLogGroupService();
        if (svc != null && !svc.isBlank()) {
            String key = svc.trim();
            r.setLogGroupService(key);
            r.setServiceName(key);
        }
        if (payloadSystemName != null && !payloadSystemName.isBlank()) {
            r.setSystemName(payloadSystemName.trim());
        }
        if (cidrBlockForPayload != null && !cidrBlockForPayload.isBlank()) {
            r.setCidrBlock(cidrBlockForPayload.trim());
        }
        return r;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getPatternUrl() {
        return patternUrl;
    }

    public void setPatternUrl(String patternUrl) {
        this.patternUrl = patternUrl;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public long getCount() {
        return count;
    }

    public void setCount(long count) {
        this.count = count;
    }

    public long getTotalOutputSize() {
        return totalOutputSize;
    }

    public void setTotalOutputSize(long totalOutputSize) {
        this.totalOutputSize = totalOutputSize;
    }

    public Instant getWindowStart() {
        return windowStart;
    }

    public void setWindowStart(Instant windowStart) {
        this.windowStart = windowStart;
    }

    public Instant getWindowEnd() {
        return windowEnd;
    }

    public void setWindowEnd(Instant windowEnd) {
        this.windowEnd = windowEnd;
    }

    public String getLogGroupName() {
        return logGroupName;
    }

    public void setLogGroupName(String logGroupName) {
        this.logGroupName = logGroupName;
    }

    public String getLogGroupService() {
        return logGroupService;
    }

    public void setLogGroupService(String logGroupService) {
        this.logGroupService = logGroupService;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getSystemName() {
        return systemName;
    }

    public void setSystemName(String systemName) {
        this.systemName = systemName;
    }

    public String getCidrBlock() {
        return cidrBlock;
    }

    public void setCidrBlock(String cidrBlock) {
        this.cidrBlock = cidrBlock;
    }

    @Override
    public String toString() {
        return "AnalyticsAggregateRequest{"
                + "source='" + source + '\''
                + ", patternUrl='" + patternUrl + '\''
                + ", status='" + status + '\''
                + ", count=" + count
                + ", totalOutputSize=" + totalOutputSize
                + ", windowStart=" + windowStart
                + ", windowEnd=" + windowEnd
                + ", logGroupName='" + logGroupName + '\''
                + ", logGroupService='" + logGroupService + '\''
                + ", serviceName='" + serviceName + '\''
                + ", systemName='" + systemName + '\''
                + ", cidrBlock='" + cidrBlock + '\''
                + '}';
    }
}
