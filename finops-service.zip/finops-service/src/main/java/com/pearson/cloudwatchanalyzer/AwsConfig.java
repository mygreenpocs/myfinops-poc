package com.pearson.cloudwatchanalyzer;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.auth.credentials.ProfileCredentialsProvider;
import software.amazon.awssdk.profiles.ProfileFileSupplier;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.cloudwatchlogs.CloudWatchLogsClient;

@Slf4j
@Configuration
@RequiredArgsConstructor
public class AwsConfig {

    private final CloudWatchAnalyzerProperties properties;

    /**
     * Resolves the profile for CloudWatch: {@code cloudwatchanalyzer.aws.profile}, else {@code AWS_PROFILE} env at
     * <strong>client creation time</strong> (changing env still needs a restart; use {@code aws.profile} in yml for
     * fixed dev setup).
     */
    static String effectiveProfileName(CloudWatchAnalyzerProperties.Aws aws) {
        String p = aws.getProfile();
        if (p != null && !p.isBlank()) {
            return p.trim();
        }
        String fromEnv = System.getenv("AWS_PROFILE");
        if (fromEnv != null && !fromEnv.isBlank()) {
            return fromEnv.trim();
        }
        return null;
    }

    /**
     * CloudWatch Logs client. For named profiles, {@link RefreshingProfileCredentialsProvider} is used by default so
     * {@code aws sso login} updates the SSO token cache without a JVM restart — the stock
     * {@link ProfileCredentialsProvider} often keeps stale credentials because it only rebuilds when the
     * {@code ProfileFile} instance changes (config file unchanged after SSO refresh).
     */
    @Bean
    public CloudWatchLogsClient cloudWatchLogsClient() {
        CloudWatchAnalyzerProperties.Aws aws = properties.getAws();
        String regionId = aws.getRegion() != null && !aws.getRegion().isBlank() ? aws.getRegion().trim() : "ap-south-1";
        var builder = CloudWatchLogsClient.builder().region(Region.of(regionId));

        AwsCredentialsProvider credentialsProvider = getCredentialsProvider(aws);
        builder.credentialsProvider(credentialsProvider);

        return builder.build();
    }

    public static AwsCredentialsProvider getCredentialsProvider(CloudWatchAnalyzerProperties.Aws aws) {
        String profile = effectiveProfileName(aws);
        if (profile != null) {
            if (aws.isRefreshCredentialsEachRequest()) {
                log.info("Using RefreshingProfileCredentialsProvider for profile '{}'", profile);
                return new RefreshingProfileCredentialsProvider(profile);
            } else {
                log.info("Using static ProfileCredentialsProvider for profile '{}'", profile);
                return ProfileCredentialsProvider.builder()
                        .profileName(profile)
                        .profileFile(ProfileFileSupplier.defaultSupplier())
                        .build();
            }
        } else {
            log.info("Using DefaultCredentialsProvider (async credential refresh)");
            return DefaultCredentialsProvider.builder().asyncCredentialUpdateEnabled(true).build();
        }
    }

    // Replaced by getCredentialsProvider
}
