package com.pearson.cloudwatchanalyzer.cidr;

import java.util.Objects;
/**
 * Outcome of resolving a CloudWatch {@code source} string against {@link CidrMatcher} rules.
 *
 * <p><strong>Spec:</strong> IPv4 match → {@link Kind#MATCHED}; non-IP / sentinel → {@link Kind#NON_IPV4}
 * (pass-through for merge); no matching block → {@link Kind#UNKNOWN} ({@code applicationName} {@code other}).
 */
public final class CidrMatchResult {

    public enum Kind {
        MATCHED,
        /** Hostname, literal, blank, NA, non-IPv4 address — keep as-is for downstream merge. */
        NON_IPV4,
        /** IPv4 not contained in any configured CIDR. */
        UNKNOWN
    }

    private final Kind kind;
    /** Matched CIDR string when {@link Kind#MATCHED}; empty otherwise. */
    private final String cidrBlock;
    /** Application name when matched; original source when {@link Kind#NON_IPV4}; {@code other} when unknown. */
    private final String applicationName;
    /** Trimmed input {@code source} (never null; may be empty). */
    private final String originalSource;

    private CidrMatchResult(Kind kind, String cidrBlock, String applicationName, String originalSource) {
        this.kind = Objects.requireNonNull(kind);
        this.cidrBlock = cidrBlock != null ? cidrBlock : "";
        this.applicationName = Objects.requireNonNull(applicationName);
        this.originalSource = Objects.requireNonNull(originalSource);
    }

    public static CidrMatchResult matched(String cidrBlock, String applicationName, String originalSource) {
        return new CidrMatchResult(Kind.MATCHED, cidrBlock, applicationName, originalSource);
    }

    public static CidrMatchResult nonIpv4(String originalSource) {
        String s = originalSource == null ? "" : originalSource.trim();
        return new CidrMatchResult(Kind.NON_IPV4, "", s, s);
    }

    public static CidrMatchResult unknown(String originalSource) {
        String s = originalSource == null ? "" : originalSource.trim();
        return new CidrMatchResult(Kind.UNKNOWN, "", "other", s);
    }

    public Kind getKind() {
        return kind;
    }

    public String getCidrBlock() {
        return cidrBlock;
    }

    public String getApplicationName() {
        return applicationName;
    }

    public String getOriginalSource() {
        return originalSource;
    }
}
