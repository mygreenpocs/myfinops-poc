package com.pearson.cloudwatchanalyzer;

import com.pearson.cloudwatchanalyzer.entity.CostModelMapping;
import com.pearson.cloudwatchanalyzer.repository.CostModelMappingRepository;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller for managing client-specific cost model configurations.
 */
@RestController
@RequestMapping("/analytics/cost-model-mappings")
@RequiredArgsConstructor
@Slf4j
public class CostModelMappingController {

    private final CostModelMappingRepository repository;

    @GetMapping
    public ResponseEntity<List<CostModelMapping>> getMappings(@RequestParam(required = false) String clientId) {
        log.info("GET Cost Model Mappings for clientId: {}", clientId);
        if (clientId == null || clientId.isBlank()) {
            return ResponseEntity.ok(repository.findAll());
        }
        return ResponseEntity.ok(repository.findByClientId(clientId));
    }

    @PutMapping
    public ResponseEntity<CostModelMapping> saveMapping(@RequestBody CostModelMapping mapping) {
        log.info("PUT Cost Model Mapping: {}", mapping);
        if (mapping.getClientId() == null || mapping.getClientId().isBlank()) {
            return ResponseEntity.badRequest().build();
        }
        if (mapping.getIdentityKey() == null || mapping.getIdentityKey().isBlank()) {
            return ResponseEntity.badRequest().build();
        }

        Optional<CostModelMapping> existing = repository.findByClientIdAndIdentityKey(
                mapping.getClientId(), mapping.getIdentityKey());

        CostModelMapping toSave;
        if (existing.isPresent()) {
            toSave = existing.get();
            toSave.setCostModel(mapping.getCostModel());
            toSave.setCustomRates(mapping.getCustomRates());
        } else {
            toSave = mapping;
        }

        CostModelMapping saved = repository.save(toSave);
        return ResponseEntity.ok(saved);
    }
}
