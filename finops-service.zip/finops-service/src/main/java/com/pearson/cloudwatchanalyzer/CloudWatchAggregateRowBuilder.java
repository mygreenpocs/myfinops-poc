package com.pearson.cloudwatchanalyzer;

import com.pearson.cloudwatchanalyzer.dto.AggregateStatsRow;
import com.pearson.cloudwatchanalyzer.dto.AggregateTriggerRow;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.stereotype.Component;

/** Builds {@link AggregateTriggerRow} (echo map only) for manual/scheduled aggregate runs. */
@Component
public class CloudWatchAggregateRowBuilder {

    public AggregateTriggerRow buildMergedRow(
            AggregateStatsMergeService.MergedStatsRow merged,
            long windowStartEpochSeconds,
            long windowEndEpochSeconds) {
        AggregateTriggerRow row = new AggregateTriggerRow();
        row.setCloudWatchRow(toEchoMap(merged, windowStartEpochSeconds, windowEndEpochSeconds));
        return row;
    }

    private static Map<String, String> toEchoMap(
            AggregateStatsMergeService.MergedStatsRow merged,
            long windowStartEpochSeconds,
            long windowEndEpochSeconds) {
        Map<String, String> m = new LinkedHashMap<>();
        AggregateStatsRow stats = merged.statsRow();
        m.put("patternUrl", stats.getPatternUrl());
        m.put("status", stats.getStatus());
        m.put("method", stats.getMethod());
        m.put("count", Long.toString(stats.getCount()));
        m.put("totalOutputSize", Long.toString(stats.getTotalOutputSize()));
        String svcEcho = stats.getLogGroupService();
        m.put("serviceName", (svcEcho != null && !svcEcho.isBlank()) ? svcEcho.trim() : "");
        m.put("logGroupName", stats.getLogGroupName());
        m.put("systemName", echoSystemName(merged));
        m.put("clientIp", echoClientIp(merged));
        m.put("windowStart", Instant.ofEpochSecond(windowStartEpochSeconds).toString());
        m.put("windowEnd", Instant.ofEpochSecond(windowEndEpochSeconds).toString());
        return m;
    }

    /**
     * Prefer domain/sysname from the TimeLogger log line when present; otherwise CIDR application name, unknown-IPv4
     * network ({@link AggregateStatsMergeService.MergedStatsRow#finopsCidrBlock()}), or non-IPv4 passthrough.
     */
    private static String echoSystemName(AggregateStatsMergeService.MergedStatsRow merged) {
        String fromLog = merged.timeLoggerSystemName();
        if (fromLog != null && !fromLog.isBlank()) {
            return fromLog.trim();
        }
        if ("other".equals(merged.applicationName())) {
            String hostRoute = merged.finopsCidrBlock();
            return !hostRoute.isBlank() ? hostRoute : merged.payloadSystemName();
        }
        return merged.payloadSystemName();
    }

    /** Raw {@code source} from TimeLogger (typically client IP); empty when unknown. */
    private static String echoClientIp(AggregateStatsMergeService.MergedStatsRow merged) {
        String raw = merged.timeLoggerClientSource();
        return raw != null && !raw.isBlank() ? raw.trim() : "";
    }
}
