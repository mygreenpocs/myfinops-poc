package com.pearson.cloudwatchanalyzer.repository;

import com.pearson.cloudwatchanalyzer.entity.Client;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

/**
 * MongoDB repository for client/tenant entities.
 */
@Repository
public interface ClientRepository extends MongoRepository<Client, String> {
}
