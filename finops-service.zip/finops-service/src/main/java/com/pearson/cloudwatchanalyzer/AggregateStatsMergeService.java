package com.pearson.cloudwatchanalyzer;

import com.pearson.cloudwatchanalyzer.cidr.CidrMatchResult;
import com.pearson.cloudwatchanalyzer.cidr.CidrMatcher;
import com.pearson.cloudwatchanalyzer.cidr.Ipv4CanonicalNetwork;
import com.pearson.cloudwatchanalyzer.dto.AggregateStatsRow;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * Epic <strong>F.1</strong>: resolves each Insights {@code source} through {@link CidrMappingService} / {@link
 * CidrMatcher}, then merges rows by {@code (cidrBlock, applicationName, patternUrl, status, logGroupService,
 * logGroupName)} summing {@code count} and {@code totalOutputSize}. For unmatched IPv4, {@code cidrBlock} in the merge
 * key is the canonical network at {@link CloudWatchAnalyzerProperties#getUnknownIpv4AggregatePrefixLength()} (default
 * {@code 16}, e.g. {@code 10.12.0.0/16}) so rows aggregate within that network.
 *
 * <p>GAIME {@code source} field on merged rows: matched IPv4 → {@link CidrMatchResult#getCidrBlock()}; unknown IPv4 →
 * {@code other}; non-IPv4 → original source (as-is).
 *
 * <p><strong>FINOPS-style labels</strong> (see {@link com.pearson.cloudwatchanalyzer.dto.AnalyticsAggregateRequest}):
 * never concatenate mapping names with {@code source}. Optional {@link AggregateStatsRow#getTimeLoggerSystemName()}
 * from the log line is preserved for API echo; merge keys include it so distinct domains stay separate.
 */
@Service
@RequiredArgsConstructor
public class AggregateStatsMergeService {

    private static final int FINOPS_FALLBACK_UNKNOWN_PREFIX = 16;

    private final CidrMappingService cidrMappingService;
    private final CloudWatchAnalyzerProperties cloudWatchAnalyzerProperties;

    /**
     * One row after CIDR merge, ready for {@link com.pearson.cloudwatchanalyzer.dto.AnalyticsAggregateRequest} and
     * trigger echo metadata.
     *
     * @param payloadSystemName mapping / FINOPS label when no log-supplied {@link #timeLoggerSystemName()}
     * @param timeLoggerSystemName optional domain/sysname from Insights ({@code systemName}); may be blank
     * @param timeLoggerClientSource first raw {@link AggregateStatsRow#getSource()} seen in the merge bucket (client IP)
     */
    public record MergedStatsRow(
            AggregateStatsRow statsRow,
            String cidrBlock,
            String applicationName,
            String payloadSystemName,
            String timeLoggerSystemName,
            String timeLoggerClientSource) {
        public MergedStatsRow {
            Objects.requireNonNull(statsRow, "statsRow");
            cidrBlock = cidrBlock != null ? cidrBlock : "";
            applicationName = applicationName != null ? applicationName : "";
            payloadSystemName = payloadSystemName != null ? payloadSystemName : "";
            timeLoggerSystemName = timeLoggerSystemName != null ? timeLoggerSystemName : "";
            timeLoggerClientSource = timeLoggerClientSource != null ? timeLoggerClientSource : "";
        }

        /**
         * CIDR string for FINOPS {@link com.pearson.cloudwatchanalyzer.dto.AnalyticsAggregateRequest#getCidrBlock()}:
         * matched rule CIDR, or canonical network (e.g. {@code x.x.0.0/16}) for unknown-IPv4 ({@code other}) buckets.
         */
        public String finopsCidrBlock() {
            if (!cidrBlock.isBlank()) {
                return cidrBlock;
            }
            if (!"other".equals(applicationName)) {
                return "";
            }
            String ip = payloadSystemName.trim();
            if (ip.isEmpty()) {
                ip = timeLoggerClientSource.trim();
            }
            if (ip.isEmpty()) {
                return "";
            }
            String net = Ipv4CanonicalNetwork.networkCidr(ip, FINOPS_FALLBACK_UNKNOWN_PREFIX);
            return net != null ? net : "";
        }
    }

    private record MergeKey(
            String cidrBlock,
            String applicationName,
            String patternUrl,
            String method,
            String status,
            String logGroupService,
            String logGroupName,
            String timeLoggerSystemName) {}

    /**
     * @param rows raw aggregate rows from CloudWatch Insights (may be empty, not null)
     */
    public List<MergedStatsRow> mergeAggregates(List<AggregateStatsRow> rows) {
        Objects.requireNonNull(rows, "rows");
        if (rows.isEmpty()) {
            return List.of();
        }
        CidrMatcher matcher = cidrMappingService.buildMatcher();
        Map<MergeKey, long[]> sums = new LinkedHashMap<>();
        Map<MergeKey, String> aggregateSourceByKey = new LinkedHashMap<>();
        Map<MergeKey, String> firstUnknownOriginalByKey = new LinkedHashMap<>();
        Map<MergeKey, String> firstClientSourceByKey = new LinkedHashMap<>();

        int unknownPrefix = cloudWatchAnalyzerProperties.getUnknownIpv4AggregatePrefixLength();

        for (AggregateStatsRow row : rows) {
            CidrMatchResult r = matcher.resolve(row.getSource());
            String cidrForKey = cidrBlockForMergeKey(r, row, unknownPrefix);
            String tlsn = row.getTimeLoggerSystemName() != null ? row.getTimeLoggerSystemName().trim() : "";
            MergeKey key =
                    new MergeKey(
                            cidrForKey,
                            r.getApplicationName(),
                            row.getPatternUrl(),
                            row.getMethod(),
                            row.getStatus(),
                            row.getLogGroupService(),
                            row.getLogGroupName(),
                            tlsn);
            aggregateSourceByKey.putIfAbsent(key, aggregateSourceForPayload(r));
            firstClientSourceByKey.putIfAbsent(
                    key, row.getSource() != null ? row.getSource().trim() : "");
            if (r.getKind() == CidrMatchResult.Kind.UNKNOWN) {
                firstUnknownOriginalByKey.putIfAbsent(key, r.getOriginalSource());
            }
            sums.merge(
                    key,
                    new long[] {row.getCount(), row.getTotalOutputSize()},
                    (a, b) -> new long[] {a[0] + b[0], a[1] + b[1]});
        }

        List<MergedStatsRow> out = new ArrayList<>(sums.size());
        for (Map.Entry<MergeKey, long[]> e : sums.entrySet()) {
            MergeKey k = e.getKey();
            long[] v = e.getValue();
            String source = aggregateSourceByKey.get(k);
            AggregateStatsRow merged =
                    new AggregateStatsRow(
                            source, k.patternUrl(), k.method(), k.status(), v[0], v[1], k.logGroupName(), k.logGroupService());
            String payloadSystemName = payloadSystemNameFor(k, firstUnknownOriginalByKey);
            out.add(
                    new MergedStatsRow(
                            merged,
                            k.cidrBlock,
                            k.applicationName,
                            payloadSystemName,
                            k.timeLoggerSystemName,
                            firstClientSourceByKey.getOrDefault(k, "")));
        }
        return out;
    }

    private static String payloadSystemNameFor(MergeKey k, Map<MergeKey, String> firstUnknownOriginalByKey) {
        if (!k.cidrBlock().isBlank()) {
            return k.applicationName();
        }
        if ("other".equals(k.applicationName())) {
            return firstUnknownOriginalByKey.getOrDefault(k, "other");
        }
        return k.applicationName();
    }

    private static String aggregateSourceForPayload(CidrMatchResult r) {
        return switch (r.getKind()) {
            case MATCHED -> r.getCidrBlock();
            case UNKNOWN -> "other";
            case NON_IPV4 -> r.getOriginalSource();
        };
    }

    private static String cidrBlockForMergeKey(CidrMatchResult r, AggregateStatsRow row, int unknownPrefix) {
        if (r.getKind() != CidrMatchResult.Kind.UNKNOWN) {
            return r.getCidrBlock();
        }
        String net = Ipv4CanonicalNetwork.networkCidr(row.getSource(), unknownPrefix);
        return net != null ? net : "";
    }
}
