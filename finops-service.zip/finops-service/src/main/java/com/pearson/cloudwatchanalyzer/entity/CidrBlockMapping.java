package com.pearson.cloudwatchanalyzer.entity;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * MongoDB document for CIDR → application mappings used by {@link com.pearson.cloudwatchanalyzer.CidrMappingService}.
 *
 * <p>Collection name matches Epic E.1 spec: {@code cidrBlockMapping}.
 */
@Data
@Document(collection = "cidrBlockMapping")
public class CidrBlockMapping {

    @Id
    private String id;

    /** IPv4 CIDR or bare IPv4 (normalized to /32 when building {@link com.pearson.cloudwatchanalyzer.cidr.CidrRule}). */
    private String cidrBlock;

    private String applicationName;

    /** Lower values are evaluated first by {@link com.pearson.cloudwatchanalyzer.cidr.CidrMatcher}. */
    private int sortOrder;
}
