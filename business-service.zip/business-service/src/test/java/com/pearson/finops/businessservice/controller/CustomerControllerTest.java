package com.pearson.finops.businessservice.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pearson.finops.businessservice.exception.CustomerNotFoundException;
import com.pearson.finops.businessservice.model.Customer;
import com.pearson.finops.businessservice.service.CustomerService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.Collections;

import static org.hamcrest.Matchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(CustomerController.class)
public class CustomerControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CustomerService customerService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void testGetAllCustomers_Empty() throws Exception {
        Mockito.when(customerService.getAllCustomers()).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/api/customers"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(0)));
    }

    @Test
    public void testGetAllCustomers_WithData() throws Exception {
        Customer c1 = new Customer(1L, "Alice", "alice@example.com", "12345");
        Customer c2 = new Customer(2L, "Bob", "bob@example.com", "67890");

        Mockito.when(customerService.getAllCustomers()).thenReturn(Arrays.asList(c1, c2));

        mockMvc.perform(get("/api/customers"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].id", is(1)))
                .andExpect(jsonPath("$[0].name", is("Alice")))
                .andExpect(jsonPath("$[1].id", is(2)))
                .andExpect(jsonPath("$[1].name", is("Bob")));
    }

    @Test
    public void testGetCustomerById_Success() throws Exception {
        Customer customer = new Customer(1L, "Alice", "alice@example.com", "12345");
        Mockito.when(customerService.getCustomerById(1L)).thenReturn(customer);

        mockMvc.perform(get("/api/customers/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.name", is("Alice")));
    }

    @Test
    public void testGetCustomerById_NotFound() throws Exception {
        Mockito.when(customerService.getCustomerById(99L))
                .thenThrow(new CustomerNotFoundException("Customer with ID 99 not found"));

        mockMvc.perform(get("/api/customers/99"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status", is(404)))
                .andExpect(jsonPath("$.error", is("Not Found")))
                .andExpect(jsonPath("$.message", is("Customer with ID 99 not found")));
    }

    @Test
    public void testCreateCustomer() throws Exception {
        Customer input = new Customer(null, "Alice", "alice@example.com", "12345");
        Customer saved = new Customer(1L, "Alice", "alice@example.com", "12345");

        Mockito.when(customerService.createCustomer(any(Customer.class))).thenReturn(saved);

        mockMvc.perform(post("/api/customers")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(input)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.name", is("Alice")));
    }

    @Test
    public void testUpdateCustomer_Success() throws Exception {
        Customer input = new Customer(null, "Alice Updated", "alice@example.com", "12345");
        Customer updated = new Customer(1L, "Alice Updated", "alice@example.com", "12345");

        Mockito.when(customerService.updateCustomer(eq(1L), any(Customer.class))).thenReturn(updated);

        mockMvc.perform(put("/api/customers/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(input)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.name", is("Alice Updated")));
    }

    @Test
    public void testDeleteCustomer_Success() throws Exception {
        Mockito.doNothing().when(customerService).deleteCustomer(1L);

        mockMvc.perform(delete("/api/customers/1"))
                .andExpect(status().isNoContent());
    }
}
