package com.pearson.finops.businessservice.service;

import com.pearson.finops.businessservice.exception.CustomerNotFoundException;
import com.pearson.finops.businessservice.model.Customer;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class CustomerService {
    private final Map<Long, Customer> customerMap = new ConcurrentHashMap<>();
    private final AtomicLong idGenerator = new AtomicLong(1);

    public List<Customer> getAllCustomers() {
        return new ArrayList<>(customerMap.values());
    }

    public Customer getCustomerById(Long id) {
        Customer customer = customerMap.get(id);
        if (customer == null) {
            throw new CustomerNotFoundException("Customer with ID " + id + " not found");
        }
        return customer;
    }

    public Customer createCustomer(Customer customer) {
        Long id = idGenerator.getAndIncrement();
        customer.setId(id);
        customerMap.put(id, customer);
        return customer;
    }

    public Customer updateCustomer(Long id, Customer customerDetails) {
        if (!customerMap.containsKey(id)) {
            throw new CustomerNotFoundException("Customer with ID " + id + " not found");
        }
        customerDetails.setId(id);
        customerMap.put(id, customerDetails);
        return customerDetails;
    }

    public void deleteCustomer(Long id) {
        if (!customerMap.containsKey(id)) {
            throw new CustomerNotFoundException("Customer with ID " + id + " not found");
        }
        customerMap.remove(id);
    }
}
