package com.pearson.finops.businessservice.config;

import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.util.ContentCachingResponseWrapper;

import java.io.IOException;

@Component
public class RequestLoggingFilter implements Filter {
    private static final Logger log = LoggerFactory.getLogger(RequestLoggingFilter.class);

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        String path = httpRequest.getRequestURI();
        
        // Only log /api/customers requests
        if (!path.startsWith("/api/customers")) {
            chain.doFilter(request, response);
            return;
        }

        ContentCachingResponseWrapper responseWrapper = new ContentCachingResponseWrapper((HttpServletResponse) response);
        long startTime = System.currentTimeMillis();

        try {
            chain.doFilter(request, responseWrapper);
        } finally {
            long duration = System.currentTimeMillis() - startTime;
            int status = responseWrapper.getStatus();
            int outputSize = responseWrapper.getContentSize();
            String method = httpRequest.getMethod();
            String clientIp = httpRequest.getRemoteAddr();
            if (clientIp.equals("0:0:0:0:0:0:0:1")) {
                clientIp = "127.0.0.1";
            }
            
            // Format log exactly as expected by CloudWatch Logs Insights query:
            // TimeLoggerFilter status : [status], outputSize : [outputSize], patternUrl : [patternUrl], source : [source], systemName : local
            log.info("TimeLoggerFilter status : {}, outputSize : {}, patternUrl : {}, source : {}, systemName : local, method : {}, durationMs : {}",
                    status, outputSize, path, clientIp, method, duration);
            
            responseWrapper.copyBodyToResponse();
        }
    }
}
