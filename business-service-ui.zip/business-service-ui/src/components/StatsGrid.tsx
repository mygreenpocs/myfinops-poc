import React from 'react';
import { Users, CheckCircle, Server } from 'lucide-react';

interface StatsGridProps {
  totalCustomers: number;
  activeCustomers: number;
  isOffline: boolean;
}

export const StatsGrid: React.FC<StatsGridProps> = ({
  totalCustomers,
  activeCustomers,
  isOffline,
}) => {
  return (
    <section className="stats-grid">
      <div className="stat-card">
        <div className="stat-info">
          <span className="stat-label">Total Customers</span>
          <span className="stat-value">{totalCustomers}</span>
        </div>
        <div className="stat-icon blue">
          <Users size={24} />
        </div>
      </div>

      <div className="stat-card">
        <div className="stat-info">
          <span className="stat-label">Active Clients</span>
          <span className="stat-value">{activeCustomers}</span>
        </div>
        <div className="stat-icon green">
          <CheckCircle size={24} />
        </div>
      </div>

      <div className="stat-card">
        <div className="stat-info">
          <span className="stat-label">API Server Status</span>
          <span
            className="stat-value"
            style={{
              fontSize: '1.25rem',
              fontWeight: 600,
              color: isOffline ? 'var(--danger)' : 'var(--success)',
            }}
          >
            {isOffline ? 'OFFLINE' : 'ONLINE'}
          </span>
        </div>
        <div className="stat-icon purple">
          <Server size={24} style={{ color: isOffline ? 'var(--danger)' : 'var(--success)' }} />
        </div>
      </div>
    </section>
  );
};
