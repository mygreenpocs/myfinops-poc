import React from 'react';
import type { Customer } from '../types/customer';
import { Edit3, Trash2, Inbox } from 'lucide-react';

interface CustomerTableProps {
  customers: Customer[];
  onEdit: (customer: Customer) => void;
  onDelete: (id: number) => void;
}

export const CustomerTable: React.FC<CustomerTableProps> = ({
  customers,
  onEdit,
  onDelete,
}) => {
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .substring(0, 2)
      .toUpperCase() || 'C';
  };

  if (customers.length === 0) {
    return (
      <div className="empty-state" style={{ display: 'flex' }}>
        <Inbox size={64} />
        <h3>No Customers Registered</h3>
        <p>Get started by clicking the "Add Customer" button above.</p>
      </div>
    );
  }

  return (
    <div className="table-wrapper">
      <table className="customer-table">
        <thead>
          <tr>
            <th>Name / ID</th>
            <th>Email Address</th>
            <th>Phone Number</th>
            <th style={{ width: '100px' }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {customers.map((customer) => (
            <tr key={customer.id}>
              <td>
                <div className="customer-identity">
                  <div className="avatar-badge">{getInitials(customer.name)}</div>
                  <div>
                    <div style={{ fontWeight: 600 }}>{customer.name}</div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                      ID: {customer.id}
                    </div>
                  </div>
                </div>
              </td>
              <td>{customer.email}</td>
              <td>{customer.phone}</td>
              <td>
                <div className="action-buttons">
                  <button
                    className="btn-icon edit"
                    onClick={() => onEdit(customer)}
                    title="Edit Customer"
                  >
                    <Edit3 size={16} />
                  </button>
                  <button
                    className="btn-icon delete"
                    onClick={() => customer.id && onDelete(customer.id)}
                    title="Delete Customer"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
