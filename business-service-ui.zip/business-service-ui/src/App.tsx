import React, { useState, useEffect } from 'react';
import type { Customer } from './types/customer';
import { StatsGrid } from './components/StatsGrid';
import { CustomerTable } from './components/CustomerTable';
import { CustomerModal } from './components/CustomerModal';
import { 
  Grid, 
  Users, 
  Search, 
  Plus, 
  RefreshCw, 
  AlertTriangle,
  CheckCircle,
  XCircle,
  Info
} from 'lucide-react';

const API_BASE_URL = 'http://localhost:8082/api/customers';

interface ToastItem {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
}

function App() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [isOffline, setIsOffline] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'customers'>('dashboard');

  // Trigger Toast Notification
  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = Date.now().toString();
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  // Fetch all customers from API
  const fetchCustomers = async () => {
    setIsLoading(true);
    try {
      const response = await fetch(API_BASE_URL);
      if (!response.ok) {
        throw new Error(`Server returned status ${response.status}`);
      }
      const data = await response.json();
      setCustomers(data);
      setIsOffline(false);
    } catch (error) {
      console.error('Fetch Error:', error);
      setIsOffline(true);
      showToast('Backend server is offline. Failed to fetch customer records.', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchCustomers();
  }, []);

  // Handle Save (Create / Update)
  const handleSaveCustomer = async (customerData: Customer) => {
    try {
      let response;
      if (editingCustomer && editingCustomer.id) {
        response = await fetch(`${API_BASE_URL}/${editingCustomer.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(customerData)
        });
      } else {
        response = await fetch(API_BASE_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(customerData)
        });
      }

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.message || 'Operation failed');
      }

      showToast(
        editingCustomer ? 'Customer updated successfully!' : 'Customer registered successfully!',
        'success'
      );
      setIsModalOpen(false);
      setEditingCustomer(null);
      fetchCustomers();
    } catch (error: any) {
      console.error('Save Error:', error);
      showToast(error.message || 'Failed to save customer.', 'error');
    }
  };

  // Handle Delete
  const handleDeleteCustomer = async (id: number) => {
    if (!confirm('Are you sure you want to delete this customer record?')) {
      return;
    }

    try {
      const response = await fetch(`${API_BASE_URL}/${id}`, {
        method: 'DELETE'
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.message || 'Failed to delete customer');
      }

      showToast('Customer deleted successfully.', 'success');
      fetchCustomers();
    } catch (error: any) {
      console.error('Delete Error:', error);
      showToast(error.message || 'Failed to delete customer record.', 'error');
    }
  };

  const openAddModal = () => {
    setEditingCustomer(null);
    setIsModalOpen(true);
  };

  const openEditModal = (customer: Customer) => {
    setEditingCustomer(customer);
    setIsModalOpen(true);
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };

  // Filter customers by search input
  const filteredCustomers = customers.filter(customer => 
    customer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    customer.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    customer.phone.includes(searchQuery) ||
    (customer.id && customer.id.toString().includes(searchQuery))
  );

  // Compute active count (any customer with all fields filled)
  const activeCount = customers.filter(c => c.name && c.email && c.phone).length;

  return (
    <div className="app-container">
      {/* Sidebar Navigation */}
      <aside className="sidebar">
        <div className="sidebar-top">
          <div className="logo-container">
            <div className="logo-icon">
              <svg viewBox="0 0 24 24" style={{ width: '22px', height: '22px', fill: '#fff' }}>
                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
            <span className="logo-text">FinOps Core</span>
          </div>
          
          <nav>
            <ul className="nav-links">
              <li className={`nav-item ${activeTab === 'dashboard' ? 'active' : ''}`}>
                <button onClick={() => setActiveTab('dashboard')} type="button">
                  <Grid size={20} />
                  <span>Dashboard</span>
                </button>
              </li>
              <li className={`nav-item ${activeTab === 'customers' ? 'active' : ''}`}>
                <button onClick={() => setActiveTab('customers')} type="button">
                  <Users size={20} />
                  <span>Customers</span>
                </button>
              </li>
            </ul>
          </nav>
        </div>
        
        <div className="sidebar-footer">
          <p>FinOps Business React UI v1.0</p>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="main-content">
        {/* Header */}
        <header className="top-header">
          <div className="header-title">
            <h1>Business Service</h1>
            <p>Manage customer directory records and API integrations</p>
          </div>
          
          <div className="header-actions">
            <div className="search-box">
              <Search size={18} className="search-icon" />
              <input 
                type="text" 
                placeholder="Search customer records..."
                value={searchQuery}
                onChange={handleSearchChange}
              />
            </div>
            
            <button className="btn-primary" onClick={openAddModal}>
              <Plus size={16} />
              <span>Add Customer</span>
            </button>
          </div>
        </header>

        {/* Stats Overview */}
        <StatsGrid 
          totalCustomers={customers.length}
          activeCustomers={activeCount}
          isOffline={isOffline}
        />

        {/* Main Panel */}
        <section className="content-section">
          {/* Offline Notification Banner */}
          {isOffline && (
            <div className="offline-banner">
              <AlertTriangle size={20} />
              <span>Warning: Unable to connect to the backend REST service. Please start your Spring Boot application on port 8082.</span>
            </div>
          )}

          <div className="section-header">
            <h2 className="section-title">
              {activeTab === 'dashboard' ? 'Overview Records' : 'Customer List'}
            </h2>
            <button 
              className="refresh-btn" 
              onClick={fetchCustomers}
              disabled={isLoading}
            >
              {isLoading ? (
                <span className="spinner"></span>
              ) : (
                <RefreshCw size={14} />
              )}
              <span>{isLoading ? 'Syncing...' : 'Refresh'}</span>
            </button>
          </div>

          {/* Table Component */}
          <CustomerTable 
            customers={filteredCustomers}
            onEdit={openEditModal}
            onDelete={handleDeleteCustomer}
          />
        </section>
      </main>

      {/* Modal Form */}
      <CustomerModal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSaveCustomer}
        customer={editingCustomer}
      />

      {/* Toast Notification Container */}
      <div className="toast-container">
        {toasts.map((toast) => (
          <div key={toast.id} className={`toast ${toast.type}`}>
            {toast.type === 'success' && <CheckCircle size={18} />}
            {toast.type === 'error' && <XCircle size={18} />}
            {toast.type === 'info' && <Info size={18} />}
            <span className="toast-message">{toast.message}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
